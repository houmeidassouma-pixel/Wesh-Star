# Wesh Star — V41

Cette version change uniquement le nom public de la plateforme : « Wesh Star IA » devient « Wesh Star ».

Les fonctions d’intelligence artificielle restent présentes : génération d’images et de vidéos, voix, traduction, modèles, automatisations et moteur IA local. Aucun module fonctionnel n’a été supprimé pour ce changement de marque.

Le nom technique des anciens documents d’archive est conservé pour préserver l’historique du projet.
