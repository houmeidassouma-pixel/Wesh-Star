# Contenu de la livraison Wesh Star V38

Cette archive est basée sur le ZIP fourni le 29 octobre 2026 : `wesh-star-ia-v3-notifications-couts(2).zip`.

## Inclus
- Code source de la plateforme conservé depuis l'archive de base : application Next.js, composants, routes API, base SQL, workers et tests existants.
- `docs/PLAN_FONCTIONNEL_V38_SHOP_FINANCE_PUBLICITE.md` : consolidation des exigences Shop, expédition/suivi, retours, trésorerie, conseiller financier, commissions, publicité des marques, notifications, sécurité et critères de lancement.
- Mise à jour de `src/components/ShopAdminPanel.tsx` : recommandations de taux de commission pour le lancement (8 % point de départ, 8–12 % plage à tester), simulation illustrative sur 100 €, explication des coûts à surveiller et rappel qu'aucun taux n'est changé automatiquement.
- Mise à jour de `src/lib/costs.ts` : notification aux comptes administrateurs lorsqu'une nouvelle recommandation du conseiller de coûts est créée ; la validation reste manuelle.
- `tests/v38-shop-advisor.test.ts` : test de présence des recommandations et des limites clairement documentées.

## Fonctions déjà présentes dans la base de code (à valider en exécution)
- Shop : produits, stock, achat par solde boutique, écritures internes, commissions configurables, fonds bloqués, numéro de suivi manuel, confirmation de réception, litiges, avis, retraits et recharges.
- Conseiller coûts : coûts énergétiques estimés, amortissement, charges fixes, marge et recommandations à valider.
- Publicités : réglages admin, campagnes configurables et suivi d'événements publicitaires.
- Notifications : mécanismes push, workers et tests de base présents dans l'archive.
- Réseau social, création IA, comptes, rôles, LIVE/appels et fonctions d'administration : conservés depuis l'archive source, sans prétendre que tous les services externes sont configurés.

## Non certifié / reste à développer ou configurer
- API transporteur réelle : tarifs, achat d'étiquettes et mise à jour automatique du suivi.
- Portail autonome des marques : compte annonceur, facturation, paiement, approbation et rapprochement des campagnes.
- Flux complet de retour physique avec suivi retour et remboursements après versement au vendeur.
- Tests de paiement réel/webhooks, tests end-to-end sur PostgreSQL et GPU, test multi-appareils LIVE/appels et restauration de sauvegarde.

## Commandes de vérification
Depuis le dossier `p/` :
- `npm test`
- `npm run build` (après installation des dépendances et configuration d'environnement)
- `npm run db:migrate` (uniquement avec une base PostgreSQL de test et `DATABASE_URL` configurée)

Ne pas déployer publiquement sans configuration des secrets, revue de sécurité, tests des paiements et validation des règles applicables aux pays servis.
