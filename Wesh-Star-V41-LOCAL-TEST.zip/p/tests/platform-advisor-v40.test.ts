import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
test('V40 persists global advisor snapshots and recommendations in an idempotent migration', () => {
  const sql = fs.readFileSync(path.join(root, 'db/migrations/20261103_platform_advisor_v40.sql'), 'utf8');
  assert.match(sql, /create table if not exists public\.platform_advisor_snapshot/i);
  assert.match(sql, /create table if not exists public\.platform_advisor_recommendations/i);
  assert.match(sql, /on conflict\(id\) do nothing/i);
});
test('V40 advisor API is admin-only and records decisions without auto-applying financial changes', () => {
  const route = fs.readFileSync(path.join(root, 'src/app/api/admin/platform-advisor/route.ts'), 'utf8');
  assert.match(route, /access\.role !== "admin"/);
  assert.match(route, /platform_advisor\.metrics_saved/);
  assert.match(route, /platform_advisor\.\$\{status\}/);
  assert.match(route, /metricsMode: "admin-entered-until-automated"/);
});
