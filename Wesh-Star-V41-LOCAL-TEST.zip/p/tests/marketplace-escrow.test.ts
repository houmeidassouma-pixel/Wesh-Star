import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  DEFAULT_SHOP_SETTINGS, normalizeShopSettings, commissionPctFor, effectivePromoPct, computeFees, holdHoursFor, computeReleaseAt,
  isReleasable, isReleasableAfterBuyerConfirmation, isUnshippedPastDeadline, entriesForTopup, entriesForPurchase, entriesForRelease,
  entriesForRefund, entriesForPayoutRequest, entriesForPayoutPaid, entriesForPayoutRejected, feesAfterPartialRefund, sumEntries,
  canBuyerCancel, canShip, canOpenDispute, toMinor
} from "../src/lib/shop/fees.ts";
const read = (path: string) => readFileSync(new URL(path, import.meta.url), "utf8");
const S = DEFAULT_SHOP_SETTINGS;

test("commission: category beats country beats global; admin values are clamped", () => {
  const s = normalizeShopSettings({ commissionPct: 8, categoryCommissionPct: { Mode: 12 }, countryCommissionPct: { bj: 5 }, promoMinPct: 40, promoMaxPct: 2 });
  assert.equal(commissionPctFor(s, "mode", "BJ"), 12);
  assert.equal(commissionPctFor(s, "autre", "BJ"), 5);
  assert.equal(commissionPctFor(s, "autre", "FR"), 8);
  assert.ok(s.promoMinPct <= s.promoMaxPct);
  assert.equal(normalizeShopSettings({ commissionPct: 999 }).commissionPct, 50);
});

test("fees: seller net + commission + promo + fixed always equals the price, never negative", () => {
  for (const [price, pct, fixed, promo] of [[10000, 8, 50, 5], [999, 8, 0, 30], [100, 50, 5000, 50], [123457, 7.5, 100, 12.5]] as const) {
    const f = computeFees(price, pct, fixed, promo);
    assert.equal(f.net + f.commission + f.promo + f.fixed, price);
    assert.ok(f.net >= 0 && f.commission >= 0 && f.promo >= 0 && f.fixed >= 0);
  }
  assert.deepEqual(computeFees(10000, 8, 0, 0), { commission: 800, fixed: 0, promo: 0, net: 9200 });
  assert.throws(() => computeFees(0, 8, 0, 0));
});

test("promotion: only applied when the seller enabled it, bounded by the admin limits", () => {
  assert.equal(effectivePromoPct(S, false, 10), 0);
  assert.equal(effectivePromoPct(S, true, 100), S.promoMaxPct);
  assert.equal(effectivePromoPct(S, true, 0), 0);
});

test("hold: default 48 h, longer for new sellers, released only after the hold and after shipping", () => {
  assert.equal(holdHoursFor(S, 10), 48);
  assert.equal(holdHoursFor(S, 0), S.newSellerHoldHours);
  const paid = new Date("2026-10-24T10:00:00Z");
  const releaseAt = computeReleaseAt(paid, 48);
  const o = { status: "shipped", release_at: releaseAt, shipped_at: new Date("2026-10-25T10:00:00Z") };
  assert.equal(isReleasable(o, new Date("2026-10-26T09:59:00Z"), S), false);
  assert.equal(isReleasable(o, new Date("2026-10-26T10:01:00Z"), S), true);
  assert.equal(isReleasable({ ...o, shipped_at: null, status: "paid" }, new Date("2026-11-30T00:00:00Z"), S), false, "no shipping => no release");
  assert.equal(isReleasable({ ...o, status: "disputed" }, new Date("2026-11-30T00:00:00Z"), S), false, "dispute blocks the money");
  assert.equal(isReleasableAfterBuyerConfirmation(o), true);
  assert.equal(isUnshippedPastDeadline({ status: "paid", release_at: releaseAt, shipped_at: null, ship_by: new Date("2026-10-31T10:00:00Z") }, new Date("2026-10-31T10:00:01Z")), true);
});

test("ledger: every operation is balanced (sum = 0) and the whole order lifecycle returns to zero", () => {
  const price = 10000, f = computeFees(price, 8, 50, 5);
  const topup = entriesForTopup({ userId: "buyer", currency: "EUR", amount: 20000, reference: "R1" });
  const pay = entriesForPurchase({ id: "o1", buyerId: "buyer", currency: "EUR", total: price });
  const rel = entriesForRelease({ id: "o1", sellerId: "seller", currency: "EUR", escrowAmount: price, fees: f });
  for (const e of [topup, pay, rel]) assert.equal(sumEntries(e), 0);
  const all = [...topup, ...pay, ...rel];
  const bal = (acc: string, user: string | null) => all.filter((e) => e.account === acc && e.userId === user).reduce((a, e) => a + e.amount, 0);
  assert.equal(bal("escrow", null), 0, "escrow empty after release");
  assert.equal(bal("available", "buyer"), 20000 - price);
  assert.equal(bal("available", "seller"), f.net);
  assert.equal(bal("platform", null), f.commission + f.fixed + f.promo);
  assert.equal(new Set(all.map((e) => e.idemKey)).size, all.length, "idempotency keys are unique");
});

test("refund and partial refund: money goes back from escrow, fees are recomputed on the remainder", () => {
  const refund = entriesForRefund({ id: "o2", buyerId: "b", currency: "XOF", amount: 3000, step: "dispute" });
  assert.equal(sumEntries(refund), 0);
  const p = feesAfterPartialRefund({ subtotal: 10000, refunded: 3000, commissionPct: 10, fixedFee: 0, promoPct: 0 });
  assert.equal(p.remainder, 7000);
  assert.equal(p.fees.commission + p.fees.net, 7000);
  assert.equal(feesAfterPartialRefund({ subtotal: 10000, refunded: 10000, commissionPct: 10, fixedFee: 0, promoPct: 0 }).fees.net, 0);
  assert.throws(() => feesAfterPartialRefund({ subtotal: 100, refunded: 200, commissionPct: 1, fixedFee: 0, promoPct: 0 }));
});

test("payouts: request holds the money, paid sends it out, rejected gives it back", () => {
  const args = { id: "p1", userId: "s", currency: "EUR", amount: 5000 };
  for (const e of [entriesForPayoutRequest(args), entriesForPayoutPaid(args), entriesForPayoutRejected(args)]) assert.equal(sumEntries(e), 0);
  const hold = entriesForPayoutRequest(args).find((e) => e.account === "payout_hold")!;
  assert.equal(hold.amount, 5000);
  assert.equal(entriesForPayoutRejected(args).find((e) => e.account === "available")!.amount, 5000);
});

test("permissions: only the right party can ship, cancel or dispute", () => {
  const o = { status: "paid", buyer_id: "b", seller_id: "s", shipped_at: null };
  assert.equal(canShip(o, "s"), true); assert.equal(canShip(o, "b"), false);
  assert.equal(canBuyerCancel(o, "b"), true); assert.equal(canBuyerCancel({ ...o, shipped_at: "x" }, "b"), false);
  assert.equal(canOpenDispute(o, "b"), true); assert.equal(canOpenDispute(o, "s"), false);
  assert.equal(canOpenDispute({ ...o, status: "completed" }, "b"), false);
});

test("amounts: FCFA must be whole numbers, minor units are integers", () => {
  assert.equal(toMinor(10.5, "EUR"), 1050);
  assert.throws(() => toMinor(10.5, "XOF"));
  assert.throws(() => toMinor(-1, "EUR"));
});

test("escrow engine locks rows, checks balance, and never trusts the browser for Flutterwave top-ups", () => {
  const escrow = read("../src/lib/shop/escrow.ts");
  assert.match(escrow, /for update/);
  assert.match(escrow, /on conflict \(idem_key\) do nothing/);
  assert.match(escrow, /AMOUNT_MISMATCH/);
  assert.match(escrow, /processDueOrders/);
  const fw = read("../src/lib/payments/flutterwave.ts");
  assert.match(fw, /confirmTopup/);
  assert.match(fw, /FW_PREFIX\.shop/);
  assert.match(read("../docker-compose.yml"), /worker\/shop-release/);
});

test("marketplace admin: money settings are admin-only, disputes can be handled by moderators", () => {
  const admin = read("../src/app/api/admin/shop/route.ts");
  assert.match(admin, /adminOnly = \[[^\]]*"save_settings"[^\]]*"settle_payout"/);
  assert.match(admin, /resolve_dispute/);
  assert.match(admin, /access\.role === "admin" \? payouts\.rows : \[\]/);
});

test("images are paid: credit charge before the GPU, refund on failure, prompt moderated, trials configurable", () => {
  const route = read("../src/app/api/video-edit/generate-asset/route.ts");
  const status = read("../src/app/api/video-edit/generate-asset/status/route.ts");
  const billing = read("../src/lib/billing.ts");
  const trial = read("../src/lib/free-trial.ts");
  assert.match(route, /chargeImage/);
  assert.match(route, /moderateText/);
  assert.ok(route.indexOf("chargeImage") < route.indexOf("/v1/assets/generate"), "charge happens before the GPU call");
  assert.match(route, /refundImage/);
  assert.match(status, /refundImage\(id, access\.user\.id\)/);
  assert.match(billing, /consume_free_image_trial/);
  assert.match(billing, /consume_generation_time_quota/);
  assert.match(billing, /refunded=true/);
  assert.match(trial, /consume_free_trial_limited/);
  const mig = read("../db/migrations/20261030_marketplace_escrow_billing.sql");
  assert.match(mig, /free_trial_video_uses int not null default 2/);
  assert.match(mig, /image_cost_seconds/);
});

test("private calls: only the callee accepts, blocked pairs cannot call, room token only for participants", () => {
  const signal = read("../src/app/api/calls/signal/route.ts");
  const start = read("../src/app/api/calls/start/route.ts");
  const token = read("../src/app/api/calls/token/route.ts");
  assert.match(signal, /c\.callee_id !== uid/);
  assert.match(start, /isBlockedPair/);
  assert.match(start, /CALLS_NOT_ALLOWED_FOR_PLAN/);
  assert.match(token, /caller_id=\$2 or callee_id=\$2/);
  assert.match(token, /c\.status === "accepted"/);
  assert.match(read("../db/migrations/20261031_calls_blocks.sql"), /create table if not exists public\.user_blocks/);
  assert.match(read("../src/app/api/messages/send/route.ts"), /isBlockedPair/);
});

test("voice messages: real audio only, signed playback URL, blocked pairs refused", () => {
  const route = read("../src/app/api/messages/voice/route.ts");
  assert.match(route, /sniff\(buf\)/);
  assert.match(route, /isBlockedPair/);
  assert.match(route, /MAX_BYTES/);
  const list = read("../src/app/api/messages/route.ts");
  assert.match(list, /createSignedVideoUrl/);
  assert.doesNotMatch(list, /audio_path:/, "internal storage path is never sent to the browser");
  assert.match(read("../db/migrations/20261101_voice_messages.sql"), /audio_seconds/);
  assert.match(read("../src/components/PrivateMessagesPanel.tsx"), /MediaRecorder/);
});

test("branding: app name, colors and install invitation come from admin settings via a dynamic manifest", () => {
  const manifest = read("../src/app/manifest.webmanifest/route.ts");
  assert.match(manifest, /site\.appName/);
  assert.match(manifest, /theme_color: site\.appThemeColor/);
  assert.match(read("../src/lib/settings.ts"), /installPromptEnabled/);
  assert.match(read("../src/components/SettingsForm.tsx"), /installButtonLabel/);
  assert.match(read("../src/app/layout.tsx"), /InstallPrompt/);
});
