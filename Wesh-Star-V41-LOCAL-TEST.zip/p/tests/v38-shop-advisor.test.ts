import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
const read = (p: string) => readFileSync(new URL(p, import.meta.url), "utf8");

test("V38 includes an admin Shop financial advisor with a human-approved commission recommendation", () => {
  const panel = read("../src/components/ShopAdminPanel.tsx");
  const spec = read("../docs/PLAN_FONCTIONNEL_V38_SHOP_FINANCE_PUBLICITE.md");
  assert.match(panel, /Conseiller financier — Wesh Star Shop/);
  assert.match(panel, /Valider|ne modifie jamais les commissions automatiquement/);
  assert.match(panel, /8–12 %/);
  const costs = read("../src/lib/costs.ts");
  assert.match(costs, /notifyUser/);
  assert.match(costs, /financial_advice/);
  assert.match(spec, /portail annonceur autonome/i);
  assert.match(spec, /transporteur automatique/);
  assert.match(spec, /Aucune recommandation.*sans validation explicite/s);
});
