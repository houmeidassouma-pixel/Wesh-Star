import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createDecipheriv, createECDH, createPublicKey, hkdfSync, randomBytes, verify } from "node:crypto";
import { encryptPayload, vapidAuthorization, generateVapidKeys } from "../src/lib/webpush.ts";
import { buildRecommendations, computeReport, DEFAULT_COST_SETTINGS, kwhFor, normalizeCostSettings, scalePrice } from "../src/lib/costs-core.ts";
const read = (p: string) => readFileSync(new URL(p, import.meta.url), "utf8");
const b64u = (b: Buffer) => b.toString("base64url");

test("web push: message chiffré (RFC 8291) que seul le navigateur destinataire peut relire", () => {
  const ua = createECDH("prime256v1"); ua.generateKeys();
  const auth = randomBytes(16);
  const message = "Ta vidéo est prête — é à ü 🎬";
  const body = encryptPayload(Buffer.from(message), b64u(ua.getPublicKey()), b64u(auth));
  const salt = body.subarray(0, 16);
  assert.equal(body.readUInt32BE(16), 4096);
  const idlen = body[20]; assert.equal(idlen, 65);
  const asPublic = body.subarray(21, 21 + idlen), ct = body.subarray(21 + idlen);
  const secret = ua.computeSecret(asPublic);
  const ikm = Buffer.from(hkdfSync("sha256", secret, auth, Buffer.concat([Buffer.from("WebPush: info\0"), ua.getPublicKey(), asPublic]), 32));
  const cek = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: aes128gcm\0"), 16));
  const nonce = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: nonce\0"), 12));
  const d = createDecipheriv("aes-128-gcm", cek, nonce); d.setAuthTag(ct.subarray(ct.length - 16));
  const plain = Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()]);
  assert.equal(plain[plain.length - 1], 2, "délimiteur de fin de bloc");
  assert.equal(plain.subarray(0, -1).toString("utf8"), message);
  // un autre navigateur ne peut pas le lire
  const other = createECDH("prime256v1"); other.generateKeys();
  const wrong = Buffer.from(hkdfSync("sha256", other.computeSecret(asPublic), auth, Buffer.concat([Buffer.from("WebPush: info\0"), other.getPublicKey(), asPublic]), 32));
  const cek2 = Buffer.from(hkdfSync("sha256", wrong, salt, Buffer.from("Content-Encoding: aes128gcm\0"), 16));
  const d2 = createDecipheriv("aes-128-gcm", cek2, nonce); d2.setAuthTag(ct.subarray(ct.length - 16));
  assert.throws(() => Buffer.concat([d2.update(ct.subarray(0, ct.length - 16)), d2.final()]));
});

test("VAPID : la signature ES256 est valide avec la clé publique du serveur", () => {
  const keys = generateVapidKeys();
  const header = vapidAuthorization("https://fcm.googleapis.com/fcm/send/abc", { ...keys, subject: "mailto:a@b.c" });
  const m = /^vapid t=([^,]+), k=(.+)$/.exec(header)!;
  assert.equal(m[2], keys.publicKey);
  const [h, p, sig] = m[1].split(".");
  assert.equal(JSON.parse(Buffer.from(p, "base64url").toString()).aud, "https://fcm.googleapis.com");
  const pub = Buffer.from(keys.publicKey, "base64url");
  const key = createPublicKey({ key: { kty: "EC", crv: "P-256", x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)) } as any, format: "jwk" });
  assert.equal(verify("sha256", Buffer.from(`${h}.${p}`), { key, dsaEncoding: "ieee-p1363" }, Buffer.from(sig, "base64url")), true);
});

test("coûts : énergie, amortissement, charges fixes et marge calculés correctement", () => {
  const s = { ...DEFAULT_COST_SETTINGS, electricityEurPerKwh: 0.2, gpuWatts: 400, systemWatts: 100, overheadPct: 0, hardwareCostEur: 3600, hardwareLifetimeMonths: 36, fixedMonthlyEur: 50 };
  assert.ok(Math.abs(kwhFor(3600, s) - 0.5) < 1e-9, "1 h à 500 W = 0,5 kWh");
  const r = computeReport({ settings: s, days: 30, videoSeconds: 600, videoEnergyEur: 4, imageCount: 0, revenueEur: 300 });
  assert.equal(r.hardwareEur, 100); assert.equal(r.fixedEur, 50);
  assert.equal(r.totalCostEur, 154); assert.equal(r.netEur, 146);
  assert.ok(Math.abs(r.marginPct! - (146 / 300) * 100) < 1e-9);
  assert.ok(r.costPerVideoMinuteEur! > 0 && r.breakEvenVideoMinutesPerMonth! > 0);
  const empty = computeReport({ settings: s, days: 30, videoSeconds: 0, videoEnergyEur: 0, imageCount: 0, revenueEur: 0 });
  assert.equal(empty.costPerVideoMinuteEur, null); assert.equal(empty.marginPct, null);
});

test("conseiller : propose une hausse de prix quand la marge est sous l'objectif, rien sinon ; jamais appliqué seul", () => {
  const s = { ...DEFAULT_COST_SETTINGS, targetMarginPct: 40 };
  const low = computeReport({ settings: s, days: 30, videoSeconds: 6000, videoEnergyEur: 30, imageCount: 100, revenueEur: 200 });
  const recs = buildRecommendations(low, s, 5);
  const price = recs.find((r) => r.kind === "scale_tier_prices")!;
  assert.ok(price && (price.action as any).pct >= 1);
  // après application du pourcentage, la marge atteint bien l'objectif
  const pct = (price.action as any).pct;
  const after = computeReport({ settings: s, days: 30, videoSeconds: 6000, videoEnergyEur: 30, imageCount: 100, revenueEur: 200 * (1 + pct / 100) });
  assert.ok(after.marginPct! >= 40 - 0.5);
  // coûts trop élevés pour une seule hausse : le plafond est indiqué honnêtement dans la proposition
  const capped = buildRecommendations(computeReport({ settings: s, days: 30, videoSeconds: 6000, videoEnergyEur: 30, imageCount: 100, revenueEur: 100 }), s, 5).find((r) => r.kind === "scale_tier_prices")!;
  assert.equal((capped.action as any).pct, 100);
  assert.match(capped.details, /trop pour une seule hausse/);
  const healthy = computeReport({ settings: s, days: 30, videoSeconds: 600, videoEnergyEur: 1, imageCount: 0, revenueEur: 1000 });
  assert.equal(buildRecommendations(healthy, s, 5).length, 0);
  assert.equal(buildRecommendations(computeReport({ settings: s, days: 30, videoSeconds: 0, videoEnergyEur: 0, imageCount: 0, revenueEur: 0 }), s, 5)[0].kind, "no_revenue");
  assert.equal(scalePrice(10, 12), 11.5); assert.equal(scalePrice(0, 10), 0);
  assert.equal(normalizeCostSettings({ target_margin_pct: 999 }).targetMarginPct, 40, "valeur hors limites ignorée");
});

test("notifications : déclencheurs SQL, file Push, service worker et cron branchés", () => {
  const mig = read("../db/migrations/20261102_notifications_costs.sql");
  for (const t of ["notify_generation", "notify_publication", "notify_coins", "notify_low_balance", "cost_generation"]) assert.match(mig, new RegExp("create trigger " + t));
  assert.match(mig, /on conflict \(dedupe_key\) do nothing/);
  assert.match(read("../src/lib/notify.ts"), /skip locked/);
  const sw = read("../public/sw.js");
  assert.match(sw, /addEventListener\('push'/); assert.match(sw, /notificationclick/);
  for (const f of ["../docker-compose.yml", "../docker-compose.self-hosted.yml"]) { const c = read(f); assert.match(c, /worker\/notifications/); assert.match(c, /worker\/costs/); }
  assert.match(read("../src/app/api/worker/notifications/route.ts"), /isCronAuthorized/);
  assert.match(read("../src/app/api/admin/costs/route.ts"), /access\.role !== "admin"/);
  const costs = read("../src/lib/costs.ts");
  assert.match(costs, /status !== "pending"/);
});

test("autopilot : réservé à l'admin et aux modérateurs ayant la permission (vérifié côté serveur)", () => {
  const social = read("../src/app/api/moderator/autopilot/route.ts");
  assert.match(social, /autopilot/);
});
