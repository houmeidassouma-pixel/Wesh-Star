import test from 'node:test';
import assert from 'node:assert/strict';
import { buildPlatformRecommendations } from '../src/lib/platform-advisor.ts';
test('global advisor flags shop operations, ads and negative studio margin',()=>{
 const r=buildPlatformRecommendations({shop:{orders30d:20,lateShipments:6,openDisputes:3,refundRatePct:7,grossMerchandiseEur:1000,platformCommissionEur:80},ads:{pendingCampaigns:2,impressions:1000,clicks:20},studio:{revenueEur:50,energyEur:30,hardwareEur:20,fixedCostShareEur:10}});
 const ids=r.map(x=>x.id); assert.ok(ids.includes('shop-late-shipping')); assert.ok(ids.includes('shop-disputes')); assert.ok(ids.includes('shop-commission-review')); assert.ok(ids.includes('ads-pending')); assert.ok(ids.includes('studio-negative-margin')); assert.ok(r.every(x=>x.requiresApproval));
});
test('advisor does not invent alerts for empty metrics',()=>assert.deepEqual(buildPlatformRecommendations({}),[]));
test('cash reserve alert triggers when obligations exceed cash',()=>assert.ok(buildPlatformRecommendations({finance:{cashAvailableEur:10,refundsDueEur:20}}).some(x=>x.id==='cash-reserve')));
