-- Messages vocaux dans les messages privés : le fichier audio est sur le stockage du serveur, jamais dans la base.
alter table public.private_messages add column if not exists kind text not null default 'text';
alter table public.private_messages add column if not exists audio_path text;
alter table public.private_messages add column if not exists audio_seconds int;
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'private_messages_kind_check') then
    alter table public.private_messages add constraint private_messages_kind_check check (kind in ('text','voice'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'private_messages_audio_seconds_check') then
    alter table public.private_messages add constraint private_messages_audio_seconds_check check (audio_seconds is null or audio_seconds between 1 and 180);
  end if;
end $$;
