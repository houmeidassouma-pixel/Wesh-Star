-- Notifications automatiques (dans l'appli + Web Push) et module de coûts / rentabilité. Tout tourne en arrière-plan.
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null,
  title text not null,
  body text not null default '',
  url text not null default '/',
  dedupe_key text unique,
  read_at timestamptz,
  push_status text not null default 'pending' check (push_status in ('pending','sending','sent','skipped','failed')),
  push_attempts int not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists idx_notifications_user on public.notifications(user_id, created_at desc);
create index if not exists idx_notifications_push on public.notifications(push_status, created_at) where push_status in ('pending','sending');

create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  endpoint text not null unique,
  p256dh text not null,
  auth text not null,
  user_agent text,
  created_at timestamptz not null default now(),
  last_success_at timestamptz
);
create index if not exists idx_push_subscriptions_user on public.push_subscriptions(user_id);

alter table public.billing_config add column if not exists low_balance_seconds int not null default 60;

create or replace function public.notify_user(p_user uuid, p_kind text, p_title text, p_body text, p_url text, p_dedupe text)
returns void language plpgsql as $$
begin
  if p_user is null then return; end if;
  insert into public.notifications (user_id, kind, title, body, url, dedupe_key)
  values (p_user, p_kind, left(p_title, 120), left(p_body, 300), p_url, p_dedupe)
  on conflict (dedupe_key) do nothing;
end $$;

-- 1) Rendu vidéo terminé ou échoué
create or replace function public.trg_notify_generation() returns trigger language plpgsql as $$
begin
  if new.status = 'done' and old.status is distinct from 'done' then
    perform public.notify_user(new.user_id, 'video_done', 'Ta vidéo est prête', 'Le rendu est terminé : ouvre « Mes vidéos » pour la voir et la publier.', '/videos', 'gen:' || new.id || ':done');
  elsif new.status = 'failed' and old.status is distinct from 'failed' then
    perform public.notify_user(new.user_id, 'video_failed', 'Le rendu a échoué', 'Ta vidéo n''a pas pu être générée. Si un crédit avait été utilisé, il est rendu automatiquement.', '/videos', 'gen:' || new.id || ':failed');
  end if;
  return new;
end $$;
drop trigger if exists notify_generation on public.generations;
create trigger notify_generation after update of status on public.generations for each row execute function public.trg_notify_generation();

-- 2) Publications automatiques (succès / échec) : prévenir le propriétaire et les administrateurs
create or replace function public.trg_notify_publication() returns trigger language plpgsql as $$
declare t text; b text; k text; r record;
begin
  if new.status = 'published' and old.status is distinct from 'published' then
    k := 'publication_ok'; t := 'Publication réussie'; b := 'La vidéo a été publiée sur ' || new.platform || '.';
  elsif new.status = 'failed' and old.status is distinct from 'failed' then
    k := 'publication_failed'; t := 'Publication échouée'; b := 'La publication sur ' || new.platform || ' a échoué : ' || left(coalesce(new.error, 'erreur inconnue'), 150);
  else return new; end if;
  for r in select id from public.profiles where id = new.user_id or role = 'admin' loop
    perform public.notify_user(r.id, k, t, b, '/videos', 'pub:' || new.id || ':' || new.status || ':' || r.id);
  end loop;
  return new;
end $$;
drop trigger if exists notify_publication on public.social_publications;
create trigger notify_publication after update of status on public.social_publications for each row execute function public.trg_notify_publication();

-- 3) Cadeaux et pièces reçus
create or replace function public.trg_notify_coins() returns trigger language plpgsql as $$
begin
  if new.user_id is not null and new.delta > 0 and new.kind in ('gift_received', 'chest_received') then
    perform public.notify_user(new.user_id, new.kind,
      case when new.kind = 'gift_received' then 'Tu as reçu un cadeau' else 'Tu as reçu une part de coffre' end,
      'Tu as reçu ' || new.delta || ' pièce(s).', '/coins', 'coins:' || new.id);
  end if;
  return new;
end $$;
drop trigger if exists notify_coins on public.coin_ledger;
create trigger notify_coins after insert on public.coin_ledger for each row execute function public.trg_notify_coins();

-- 4) Solde bas : une alerte par jour au maximum, quand les crédits passent sous le seuil réglé par l'admin
create or replace function public.trg_notify_low_balance() returns trigger language plpgsql as $$
declare th int;
begin
  select low_balance_seconds into th from public.billing_config where id = true;
  th := coalesce(th, 60);
  if th > 0 and new.hour_credits_seconds < th and old.hour_credits_seconds >= th then
    perform public.notify_user(new.id, 'low_balance', 'Crédits bientôt épuisés', 'Il te reste moins de ' || th || ' secondes de crédit. Recharge pour continuer à générer.', '/billing', 'low:' || new.id || ':' || to_char(now(), 'YYYY-MM-DD'));
  end if;
  return new;
end $$;
drop trigger if exists notify_low_balance on public.profiles;
create trigger notify_low_balance after update of hour_credits_seconds on public.profiles for each row execute function public.trg_notify_low_balance();

-- Module de coûts : réglages (réglés par l'admin), coût réel de chaque rendu, propositions à valider
create table if not exists public.cost_settings (
  id boolean primary key default true check (id),
  electricity_eur_per_kwh numeric not null default 0.25 check (electricity_eur_per_kwh >= 0),
  gpu_watts numeric not null default 350 check (gpu_watts >= 0),
  system_watts numeric not null default 120 check (system_watts >= 0),
  gpu_seconds_per_video_second numeric not null default 90 check (gpu_seconds_per_video_second >= 0),
  gpu_seconds_per_image numeric not null default 8 check (gpu_seconds_per_image >= 0),
  overhead_pct numeric not null default 15 check (overhead_pct between 0 and 500),
  hardware_cost_eur numeric not null default 2500 check (hardware_cost_eur >= 0),
  hardware_lifetime_months int not null default 36 check (hardware_lifetime_months between 1 and 240),
  fixed_monthly_eur numeric not null default 40 check (fixed_monthly_eur >= 0),
  manual_monthly_revenue_eur numeric not null default 0 check (manual_monthly_revenue_eur >= 0),
  target_margin_pct numeric not null default 40 check (target_margin_pct between 0 and 95),
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles(id) on delete set null
);
insert into public.cost_settings (id) values (true) on conflict (id) do nothing;

create table if not exists public.job_costs (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('video','image')),
  ref_id text not null,
  video_seconds numeric not null default 0,
  gpu_seconds numeric not null default 0,
  kwh numeric not null default 0,
  energy_eur numeric not null default 0,
  created_at timestamptz not null default now(),
  unique (kind, ref_id)
);
create index if not exists idx_job_costs_created on public.job_costs(created_at);

-- Chaque vidéo terminée enregistre son énergie estimée (temps GPU configuré × puissance × prix du kWh)
create or replace function public.trg_cost_generation() returns trigger language plpgsql as $$
declare c record; gpu_s numeric; kwh numeric;
begin
  if new.status = 'done' and old.status is distinct from 'done' then
    select * into c from public.cost_settings where id = true;
    gpu_s := new.target_seconds * c.gpu_seconds_per_video_second;
    kwh := (gpu_s / 3600.0) * ((c.gpu_watts + c.system_watts) / 1000.0) * (1 + c.overhead_pct / 100.0);
    insert into public.job_costs (kind, ref_id, video_seconds, gpu_seconds, kwh, energy_eur)
    values ('video', new.id::text, new.target_seconds, gpu_s, kwh, kwh * c.electricity_eur_per_kwh) on conflict do nothing;
  end if;
  return new;
end $$;
drop trigger if exists cost_generation on public.generations;
create trigger cost_generation after update of status on public.generations for each row execute function public.trg_cost_generation();

create table if not exists public.cost_recommendations (
  id uuid primary key default gen_random_uuid(),
  kind text not null,
  title text not null,
  details text not null,
  action jsonb not null default '{}',
  status text not null default 'pending' check (status in ('pending','applied','dismissed')),
  created_at timestamptz not null default now(),
  decided_at timestamptz,
  decided_by uuid references public.profiles(id) on delete set null
);
create index if not exists idx_cost_recommendations_status on public.cost_recommendations(status, created_at desc);
