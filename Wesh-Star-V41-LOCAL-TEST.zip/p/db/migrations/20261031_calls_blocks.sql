-- Appels privés fonctionnels (LiveKit) : blocage entre utilisateurs, accès aux appels réglable, statut « manqué ».
create table if not exists public.user_blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);
create index if not exists idx_user_blocks_blocked on public.user_blocks(blocked_id);

create table if not exists public.call_reports (
  id uuid primary key default gen_random_uuid(),
  call_id uuid not null references public.communication_calls(id) on delete cascade,
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null check (char_length(reason) between 3 and 500),
  created_at timestamptz not null default now(),
  unique (call_id, reporter_id)
);

-- Accès aux appels : tous, abonnés payants uniquement, ou comptes vérifiés (badge) uniquement. Réglé dans l'admin.
create table if not exists public.communication_settings (
  id boolean primary key default true check (id),
  calls_enabled boolean not null default true,
  calls_access text not null default 'all' check (calls_access in ('all','subscribers','verified')),
  updated_at timestamptz not null default now()
);
insert into public.communication_settings (id) values (true) on conflict (id) do nothing;
