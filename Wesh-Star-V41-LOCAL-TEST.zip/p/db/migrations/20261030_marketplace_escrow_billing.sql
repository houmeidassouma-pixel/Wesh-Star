-- Wesh Star Shop: vraie place de marché avec séquestre, commissions, promotion,
-- litiges, retraits vendeurs + crédits d'images et essais gratuits réglables.
-- Toutes les instructions sont idempotentes (migrate.js peut les rejouer).

alter table public.profiles add column if not exists shop_seller_verified boolean not null default false;
alter table public.profiles add column if not exists free_trial_image_uses int not null default 0;

-- ---------- Réglages boutique (une seule ligne, modifiable depuis l'admin) ----------
create table if not exists public.shop_settings (
  id boolean primary key default true check (id),
  escrow_enabled boolean not null default true,
  commission_pct numeric(5,2) not null default 8 check (commission_pct between 0 and 50),
  category_commission_pct jsonb not null default '{}'::jsonb,
  country_commission_pct jsonb not null default '{}'::jsonb,
  fixed_fee_minor jsonb not null default '{}'::jsonb,
  hold_hours int not null default 48 check (hold_hours between 0 and 720),
  post_ship_hold_hours int not null default 0 check (post_ship_hold_hours between 0 and 720),
  new_seller_hold_hours int not null default 168 check (new_seller_hold_hours between 0 and 1440),
  new_seller_orders_threshold int not null default 3 check (new_seller_orders_threshold between 0 and 1000),
  ship_deadline_days int not null default 7 check (ship_deadline_days between 1 and 60),
  release_requires_shipping boolean not null default true,
  promo_min_pct numeric(5,2) not null default 1 check (promo_min_pct between 0 and 50),
  promo_max_pct numeric(5,2) not null default 30 check (promo_max_pct between 0 and 50),
  payout_requires_verification boolean not null default true,
  min_payout_minor jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid
);
insert into public.shop_settings (id) values (true) on conflict (id) do nothing;

-- ---------- Produits : promotion par pourcentage choisi par le vendeur ----------
alter table public.shop_products add column if not exists promo_enabled boolean not null default false;
alter table public.shop_products add column if not exists promo_pct numeric(5,2) not null default 0;
alter table public.shop_products drop constraint if exists shop_products_promo_pct_check;
alter table public.shop_products add constraint shop_products_promo_pct_check check (promo_pct between 0 and 50);
create index if not exists idx_shop_products_promo on public.shop_products(promo_enabled, promo_pct desc) where status = 'active';

-- ---------- Grand livre boutique (double entrée : la somme par devise vaut toujours 0) ----------
-- Comptes : available (solde utilisable/retirable d'un utilisateur), escrow (fonds bloqués d'une commande),
-- platform (revenus de la plateforme), payout_hold (retrait demandé, en attente), external (argent réel hors site).
create table if not exists public.shop_ledger (
  id bigserial primary key,
  account text not null check (account in ('available','escrow','platform','payout_hold','external')),
  user_id uuid,
  currency text not null check (currency in ('EUR','XOF','USD','GBP')),
  amount_minor bigint not null,
  kind text not null,
  order_id uuid,
  ref_id uuid,
  idem_key text not null unique,
  note text not null default '',
  created_at timestamptz not null default now(),
  check ((account in ('available','payout_hold') and user_id is not null) or (account in ('escrow','platform','external') and user_id is null))
);
create index if not exists idx_shop_ledger_user on public.shop_ledger(user_id, currency, account);
create index if not exists idx_shop_ledger_order on public.shop_ledger(order_id);

-- ---------- Commandes payées (le site encaisse, garde en séquestre, libère ensuite) ----------
create table if not exists public.shop_orders (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.shop_products(id) on delete restrict,
  buyer_id uuid not null,
  seller_id uuid not null,
  quantity int not null check (quantity between 1 and 100000),
  unit_price_minor bigint not null check (unit_price_minor > 0),
  currency text not null check (currency in ('EUR','XOF','USD','GBP')),
  subtotal_minor bigint not null check (subtotal_minor > 0),
  commission_pct numeric(5,2) not null default 0,
  commission_minor bigint not null default 0 check (commission_minor >= 0),
  fixed_fee_minor bigint not null default 0 check (fixed_fee_minor >= 0),
  promo_pct numeric(5,2) not null default 0,
  promo_minor bigint not null default 0 check (promo_minor >= 0),
  seller_net_minor bigint not null check (seller_net_minor >= 0),
  refunded_minor bigint not null default 0 check (refunded_minor >= 0),
  shipping_country char(2) not null,
  buyer_message text not null default '' check (char_length(buyer_message) <= 1000),
  status text not null default 'paid' check (status in ('paid','shipped','delivered','completed','cancelled','refunded','disputed')),
  paid_at timestamptz not null default now(),
  ship_by timestamptz not null,
  release_at timestamptz not null,
  shipped_at timestamptz,
  tracking_carrier text,
  tracking_number text,
  delivered_at timestamptz,
  released_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (buyer_id <> seller_id),
  check (refunded_minor <= subtotal_minor)
);
create index if not exists idx_shop_orders2_buyer on public.shop_orders(buyer_id, created_at desc);
create index if not exists idx_shop_orders2_seller on public.shop_orders(seller_id, created_at desc);
create index if not exists idx_shop_orders2_due on public.shop_orders(status, release_at);

-- ---------- Litiges ----------
create table if not exists public.shop_disputes (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.shop_orders(id) on delete cascade,
  opened_by uuid not null,
  reason text not null check (reason in ('not_received','not_as_described','damaged','other')),
  details text not null default '' check (char_length(details) <= 2000),
  status text not null default 'open' check (status in ('open','seller_responded','resolved')),
  resolution text check (resolution in ('refund_buyer','pay_seller','partial_refund')),
  refund_minor bigint not null default 0 check (refund_minor >= 0),
  resolution_note text not null default '',
  resolved_by uuid,
  resolved_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.shop_dispute_messages (
  id bigserial primary key,
  dispute_id uuid not null references public.shop_disputes(id) on delete cascade,
  author_id uuid not null,
  author_role text not null check (author_role in ('buyer','seller','admin')),
  body text not null check (char_length(body) between 1 and 2000),
  image_url text,
  created_at timestamptz not null default now()
);
create index if not exists idx_shop_dispute_messages on public.shop_dispute_messages(dispute_id, created_at);

-- ---------- Recharges du solde boutique et retraits vendeurs ----------
create table if not exists public.shop_topups (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  currency text not null check (currency in ('EUR','XOF','USD','GBP')),
  amount_minor bigint not null check (amount_minor > 0),
  method text not null check (method in ('flutterwave','manual')),
  reference text not null unique,
  status text not null default 'pending' check (status in ('pending','confirmed','rejected')),
  provider_tx text,
  created_at timestamptz not null default now(),
  confirmed_at timestamptz,
  confirmed_by uuid
);
create index if not exists idx_shop_topups_user on public.shop_topups(user_id, created_at desc);
create index if not exists idx_shop_topups_status on public.shop_topups(status, created_at);

create table if not exists public.shop_payouts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  currency text not null check (currency in ('EUR','XOF','USD','GBP')),
  amount_minor bigint not null check (amount_minor > 0),
  method text not null check (method in ('mobile_money','bank','paypal')),
  details text not null check (char_length(details) between 3 and 500),
  status text not null default 'requested' check (status in ('requested','paid','rejected')),
  admin_note text not null default '',
  created_at timestamptz not null default now(),
  processed_at timestamptz,
  processed_by uuid
);
create index if not exists idx_shop_payouts_user on public.shop_payouts(user_id, created_at desc);
create index if not exists idx_shop_payouts_status on public.shop_payouts(status, created_at);

-- ---------- Avis et signalements ----------
create table if not exists public.shop_reviews (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.shop_orders(id) on delete cascade,
  buyer_id uuid not null,
  seller_id uuid not null,
  rating int not null check (rating between 1 and 5),
  comment text not null default '' check (char_length(comment) <= 1000),
  created_at timestamptz not null default now()
);
create index if not exists idx_shop_reviews_seller on public.shop_reviews(seller_id);

create table if not exists public.shop_reports (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.shop_products(id) on delete cascade,
  reporter_id uuid not null,
  reason text not null check (char_length(reason) between 3 and 500),
  status text not null default 'open' check (status in ('open','dismissed','actioned')),
  created_at timestamptz not null default now(),
  unique (product_id, reporter_id)
);

-- ---------- Crédits d'images et essais gratuits réglables ----------
create table if not exists public.billing_config (
  id boolean primary key default true check (id),
  free_trial_video_uses int not null default 2 check (free_trial_video_uses between 0 and 1000),
  free_trial_image_uses int not null default 0 check (free_trial_image_uses between 0 and 1000),
  image_cost_seconds int not null default 5 check (image_cost_seconds between 1 and 3600),
  updated_at timestamptz not null default now(),
  updated_by uuid
);
insert into public.billing_config (id) values (true) on conflict (id) do nothing;

create table if not exists public.image_charges (
  job_id text primary key,
  user_id uuid not null,
  source text not null check (source in ('trial','plan','credits','free_staff')),
  seconds int not null default 0,
  month text,
  day text,
  refunded boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_image_charges_user on public.image_charges(user_id, created_at desc);

create or replace function public.consume_free_trial_limited(p_user_id uuid, p_max int)
returns boolean language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set free_trial_uses = free_trial_uses + 1
   where id = p_user_id and free_trial_uses < greatest(0, p_max);
  return found;
end; $$;

create or replace function public.consume_free_image_trial(p_user_id uuid, p_max int)
returns boolean language plpgsql security definer set search_path = public as $$
begin
  update public.profiles set free_trial_image_uses = free_trial_image_uses + 1
   where id = p_user_id and free_trial_image_uses < greatest(0, p_max);
  return found;
end; $$;

create or replace function public.refund_free_image_trial(p_user_id uuid)
returns void language sql security definer set search_path = public as $$
  update public.profiles set free_trial_image_uses = greatest(0, free_trial_image_uses - 1) where id = p_user_id;
$$;
