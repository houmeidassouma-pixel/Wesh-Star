-- V40: persistent global advisor snapshots and auditable recommendations.
-- This stores operator-entered metrics until trusted per-module aggregations are wired.
create table if not exists public.platform_advisor_snapshot (
  id boolean primary key default true check (id=true),
  metrics jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid null
);
insert into public.platform_advisor_snapshot(id,metrics) values(true,'{}'::jsonb) on conflict(id) do nothing;

create table if not exists public.platform_advisor_recommendations (
  id text primary key,
  priority text not null check (priority in ('urgent','high','normal')),
  area text not null check (area in ('shop','ads','studio','live','finance')),
  title text not null,
  reason text not null,
  proposed_action text not null,
  impact text not null,
  status text not null default 'pending' check (status in ('pending','approved','dismissed')),
  created_at timestamptz not null default now(),
  decided_at timestamptz null,
  decided_by uuid null
);
create index if not exists platform_advisor_recommendations_status_created_idx on public.platform_advisor_recommendations(status, created_at desc);
