"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Room } from "livekit-client";

type Call = { id: string; caller_id: string; callee_id: string; call_type: "audio" | "video"; status: string; other_label: string; incoming: boolean };

async function post(url: string, body: unknown) {
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || "ERROR"), d);
  return d;
}
const ERR: Record<string, string> = {
  COMMUNICATIONS_DISABLED: "Les appels sont désactivés pour le moment.", CALLS_NOT_ALLOWED_FOR_PLAN: "Les appels ne sont pas disponibles pour ton compte.", USER_BLOCKED: "Appel impossible : un des deux comptes a bloqué l'autre.",
  CALL_ALREADY_ACTIVE: "Un appel est déjà en cours.", RATE_LIMIT: "Trop d'appels : réessaie dans une minute.", LIVE_STREAM_NOT_CONFIGURED: "Le serveur d'appels n'est pas configuré."
};

// Gestionnaire d'appels privés : sonnerie entrante, appel sortant, salle audio/vidéo LiveKit, raccrocher, signaler.
// Le bouton d'appel d'un contact déclenche l'évènement « wesh:start-call ».
export default function CallManager() {
  const [calls, setCalls] = useState<Call[]>([]);
  const [missed, setMissed] = useState<{ id: string; other_label: string }[]>([]);
  const [disabled, setDisabled] = useState(false);
  const [active, setActive] = useState<Call | null>(null);
  const [connected, setConnected] = useState(false);
  const [mic, setMic] = useState(true); const [cam, setCam] = useState(true);
  const [error, setError] = useState("");
  const roomRef = useRef<Room | null>(null);
  const mediaRef = useRef<HTMLDivElement>(null);
  const localRef = useRef<HTMLDivElement>(null);
  const activeId = useRef<string>("");

  const leave = useCallback(async (notify: boolean) => {
    const id = activeId.current; activeId.current = "";
    try { await roomRef.current?.disconnect(); } catch { /* déjà déconnecté */ }
    roomRef.current = null; mediaRef.current?.replaceChildren(); localRef.current?.replaceChildren();
    setActive(null); setConnected(false); setMic(true); setCam(true);
    if (notify && id) await post("/api/calls/signal", { callId: id, signalType: "ended" }).catch(() => undefined);
  }, []);

  const join = useCallback(async (call: Call) => {
    activeId.current = call.id; setActive(call); setError("");
    try {
      const t = await post("/api/calls/token", { callId: call.id });
      const lk = await import("livekit-client");
      const room = new lk.Room({ adaptiveStream: true, dynacast: true }); roomRef.current = room;
      const attach = (track: any, local: boolean) => {
        const el = track.attach() as HTMLElement;
        if (el instanceof HTMLVideoElement) { el.autoplay = true; el.playsInline = true; el.style.width = "100%"; el.style.borderRadius = "12px"; el.style.background = "#09090b"; }
        (local ? localRef.current : mediaRef.current)?.appendChild(el);
      };
      room.on(lk.RoomEvent.TrackSubscribed, (track) => attach(track, false));
      room.on(lk.RoomEvent.TrackUnsubscribed, (track) => track.detach().forEach((el: HTMLElement) => el.remove()));
      room.on(lk.RoomEvent.ParticipantDisconnected, () => { void leave(false); });
      await room.connect(t.url, t.token);
      if (activeId.current !== call.id) { await room.disconnect(); return; }
      await room.localParticipant.setMicrophoneEnabled(true).catch(() => setMic(false));
      if (call.call_type === "video") {
        await room.localParticipant.setCameraEnabled(true).catch(() => setCam(false));
        room.localParticipant.videoTrackPublications.forEach((p) => { if (p.track) attach(p.track, true); });
      } else setCam(false);
      setConnected(true);
    } catch (e: any) { setError(ERR[e?.message] || e?.message || "Connexion à l'appel impossible."); }
  }, [leave]);

  // Sonnerie simple par WebAudio tant qu'un appel entrant sonne.
  const ringing = calls.find((c) => c.incoming && c.status === "ringing" && c.id !== active?.id);
  useEffect(() => {
    if (!ringing) return;
    let ctx: AudioContext | null = null;
    try { ctx = new (window.AudioContext || (window as any).webkitAudioContext)(); } catch { return; }
    const beep = () => { if (!ctx) return; const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = 880; g.gain.value = 0.05; o.connect(g); g.connect(ctx.destination); o.start(); o.stop(ctx.currentTime + 0.35); };
    beep(); const t = setInterval(beep, 2000);
    return () => { clearInterval(t); void ctx?.close(); };
  }, [ringing?.id]);

  // Interrogation régulière des appels (toutes les 3 s, onglet visible).
  useEffect(() => {
    let stop = false;
    const tick = async () => {
      if (document.hidden || disabled) return;
      try {
        const r = await fetch("/api/calls/incoming", { cache: "no-store" });
        if (r.status === 503 || r.status === 401) { if (r.status === 503) setDisabled(true); return; }
        const d = await r.json();
        if (stop) return;
        setCalls(d.calls || []); setMissed(d.missed || []);
        // Appel terminé de l'autre côté (raccroché, refusé, manqué) : on quitte la salle.
        if (activeId.current && !(d.calls || []).some((c: Call) => c.id === activeId.current)) void leave(false);
      } catch { /* réseau instable : on réessaie */ }
    };
    void tick(); const t = setInterval(tick, 3000);
    return () => { stop = true; clearInterval(t); };
  }, [disabled, leave]);

  useEffect(() => {
    const onStart = async (ev: Event) => {
      const d = (ev as CustomEvent).detail || {};
      if (activeId.current) return setError("Un appel est déjà en cours.");
      try {
        const r = await post("/api/calls/start", { calleeId: d.calleeId, callType: d.callType });
        await join({ ...r.call, other_label: d.label || "Contact", incoming: false });
      } catch (e: any) { setError(ERR[e?.message] || e?.message || "Appel impossible."); }
    };
    window.addEventListener("wesh:start-call", onStart);
    return () => window.removeEventListener("wesh:start-call", onStart);
  }, [join]);
  useEffect(() => () => { void roomRef.current?.disconnect(); }, []);

  const accept = async (c: Call) => { try { await post("/api/calls/signal", { callId: c.id, signalType: "accepted" }); await join(c); } catch (e: any) { setError(ERR[e?.message] || "Impossible de répondre."); } };
  const decline = async (c: Call) => { await post("/api/calls/signal", { callId: c.id, signalType: "declined" }).catch(() => undefined); setCalls((x) => x.filter((y) => y.id !== c.id)); };
  const toggleMic = async () => { const n = !mic; await roomRef.current?.localParticipant.setMicrophoneEnabled(n); setMic(n); };
  const toggleCam = async () => { const n = !cam; await roomRef.current?.localParticipant.setCameraEnabled(n); setCam(n); };
  const report = async () => { const reason = window.prompt("Pourquoi signaler cet appel ?"); if (reason && active) await post("/api/calls/report", { callId: active.id, reason }).then(() => setError("Signalement envoyé.")).catch(() => setError("Signalement impossible.")); };

  if (disabled && !active) return null;
  return <>
    {ringing && <div role="alertdialog" aria-label="Appel entrant" className="fixed inset-x-3 bottom-4 z-50 mx-auto max-w-sm rounded-2xl border border-emerald-500/40 bg-zinc-950 p-4 shadow-2xl">
      <p className="text-sm text-zinc-400">Appel {ringing.call_type === "video" ? "vidéo" : "audio"} entrant</p>
      <p className="text-lg font-bold">{ringing.other_label}</p>
      <div className="mt-3 flex gap-2"><button className="btn btn-primary flex-1" onClick={() => void accept(ringing)}>Répondre</button><button className="btn btn-danger flex-1" onClick={() => void decline(ringing)}>Refuser</button></div>
    </div>}
    {active && <div role="dialog" aria-label="Appel en cours" className="fixed inset-0 z-50 flex flex-col bg-zinc-950/95 p-4">
      <div className="flex items-center justify-between"><div><p className="text-lg font-bold">{active.other_label}</p><p className="text-xs text-zinc-400">{connected ? (active.incoming || calls.find((c) => c.id === active.id)?.status === "accepted" ? "En ligne" : "Sonnerie…") : "Connexion…"}</p></div><button className="text-xs text-zinc-400 underline" onClick={() => void report()}>Signaler</button></div>
      <div className="relative mt-3 flex flex-1 items-center justify-center overflow-hidden rounded-2xl bg-zinc-900"><div ref={mediaRef} className="w-full max-w-2xl" /><div ref={localRef} className="absolute bottom-3 right-3 w-28 overflow-hidden rounded-lg" /></div>
      {error && <p role="alert" className="mt-2 text-sm text-red-300">{error}</p>}
      <div className="mt-3 flex justify-center gap-3"><button className="btn btn-secondary" onClick={() => void toggleMic()}>{mic ? "Couper le micro" : "Activer le micro"}</button>{active.call_type === "video" && <button className="btn btn-secondary" onClick={() => void toggleCam()}>{cam ? "Couper la caméra" : "Activer la caméra"}</button>}<button className="btn btn-danger" onClick={() => void leave(true)}>Raccrocher</button></div>
    </div>}
    {!active && !ringing && (error || missed.length > 0) && <div className="fixed inset-x-3 bottom-4 z-40 mx-auto max-w-sm rounded-xl border border-zinc-700 bg-zinc-950 p-3 text-sm">
      {error && <p role="alert">{error}</p>}
      {!error && missed.length > 0 && <p>Appel manqué de {missed[0].other_label}{missed.length > 1 ? ` (+${missed.length - 1})` : ""}</p>}
      <button className="mt-1 text-xs text-zinc-400 underline" onClick={() => { setError(""); setMissed([]); }}>Fermer</button>
    </div>}
  </>;
}
