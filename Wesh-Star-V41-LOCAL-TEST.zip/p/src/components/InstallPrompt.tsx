"use client";
import { useEffect, useState } from "react";

type Props = { title: string; text: string; button: string; name: string };

// Invitation à installer l'application. Android/Chrome : bouton natif ; iPhone : explication « Partager → Sur l'écran d'accueil ».
export default function InstallPrompt({ title, text, button, name }: Props) {
  const [evt, setEvt] = useState<any>(null);
  const [ios, setIos] = useState(false);
  const [hidden, setHidden] = useState(true);
  useEffect(() => {
    const standalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as any).standalone === true;
    let dismissed = false; try { dismissed = Date.now() - Number(localStorage.getItem("wesh-install-dismissed") || 0) < 14 * 86400_000; } catch { /* stockage indisponible */ }
    if (standalone || dismissed) return;
    const onPrompt = (e: Event) => { e.preventDefault(); setEvt(e); setHidden(false); };
    window.addEventListener("beforeinstallprompt", onPrompt);
    const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent) && !/crios|fxios/i.test(navigator.userAgent);
    if (isIos) { setIos(true); setHidden(false); }
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);
  const close = () => { setHidden(true); try { localStorage.setItem("wesh-install-dismissed", String(Date.now())); } catch { /* ignoré */ } };
  const install = async () => { if (!evt) return; await evt.prompt(); try { await evt.userChoice; } catch { /* ignoré */ } setEvt(null); close(); };
  if (hidden || (!evt && !ios)) return null;
  return <div role="dialog" aria-label={title} className="fixed inset-x-3 bottom-3 z-40 mx-auto max-w-md rounded-2xl border border-zinc-700 bg-zinc-950/95 p-4 shadow-2xl">
    <p className="font-bold">{title}</p>
    <p className="mt-1 text-sm text-zinc-400">{ios && !evt ? `Sur iPhone : touche Partager puis « Sur l'écran d'accueil » pour ajouter ${name}.` : text}</p>
    <div className="mt-3 flex gap-2">{evt && <button className="btn btn-primary btn-sm" onClick={() => void install()}>{button}</button>}<button className="btn btn-secondary btn-sm" onClick={close}>Plus tard</button></div>
  </div>;
}
