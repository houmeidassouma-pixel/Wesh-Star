"use client";
import { useEffect, useState } from "react";

const money = (minor: number, currency: string) => new Intl.NumberFormat(undefined, { style: "currency", currency, maximumFractionDigits: currency === "XOF" ? 0 : 2 }).format(minor / 100);
async function api(method: string, body?: unknown) {
  const r = await fetch("/api/admin/shop", { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body), cache: "no-store" });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || "Erreur");
  return d;
}

// Panneau admin : commissions, blocage des fonds, promotion, litiges, retraits vendeurs, recharges, crédits d'images et essais gratuits.
export default function ShopAdminPanel() {
  const [data, setData] = useState<any>(null);
  const [s, setS] = useState<any>(null);
  const [b, setB] = useState<any>(null);
  const [json, setJson] = useState({ category: "{}", country: "{}", fixed: "{}", minPayout: "{}" });
  const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  const [refund, setRefund] = useState<Record<string, string>>({}); const [note, setNote] = useState<Record<string, string>>({});
  const [verifyId, setVerifyId] = useState("");
  const [calls, setCalls] = useState<any>(null);

  const load = async () => {
    try {
      const d = await api("GET");
      setData(d); setS(d.settings); setB(d.billing);
      setJson({ category: JSON.stringify(d.settings.categoryCommissionPct), country: JSON.stringify(d.settings.countryCommissionPct), fixed: JSON.stringify(d.settings.fixedFeeMinor), minPayout: JSON.stringify(d.settings.minPayoutMinor) });
    } catch (e: any) { setMsg(e.message); }
  };
  useEffect(() => { void load(); fetch("/api/admin/communication", { cache: "no-store" }).then((r) => (r.ok ? r.json() : null)).then(setCalls).catch(() => undefined); }, []);
  const run = async (fn: () => Promise<string | void>) => { setBusy(true); setMsg(""); try { const m = await fn(); if (m) setMsg(m); await load(); } catch (e: any) { setMsg(e.message || "Erreur"); } finally { setBusy(false); } };
  const parse = (t: string) => { try { return JSON.parse(t || "{}"); } catch { throw new Error("JSON invalide dans un des champs de commission."); } };
  if (!data || !s || !b) return <section className="card p-5" id="shop-admin"><h2 className="text-xl font-bold">Wesh Star Shop — administration</h2><p className="mt-2 text-sm text-zinc-500">{msg || "Chargement…"}</p></section>;
  const num = (k: string, step = "1") => <input className="input w-28" type="number" step={step} value={s[k]} onChange={(e) => setS({ ...s, [k]: Number(e.target.value) })} />;

  return <section className="card space-y-6 p-5" id="shop-admin">
    <div><h2 className="text-xl font-bold">Wesh Star Shop — administration</h2><p className="text-sm text-zinc-400">Place de marché avec séquestre local. Les montants sont en unité mineure pour les frais fixes (ex. 100 = 1,00 €).</p></div>
    {msg && <p role="status" className="rounded-xl border border-zinc-800 p-3 text-sm text-zinc-300">{msg}</p>}

    <div className="grid gap-3 sm:grid-cols-2">
      <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Mes commissions encaissées</p>{data.platformEarnings.length ? data.platformEarnings.map((x: any) => <p key={x.currency} className="font-bold">{money(x.total, x.currency)}</p>) : <p className="text-sm text-zinc-500">Aucune pour l'instant.</p>}</div>
      <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Argent en séquestre (clients)</p>{data.escrowHeld.length ? data.escrowHeld.map((x: any) => <p key={x.currency} className="font-bold">{money(x.total, x.currency)}</p>) : <p className="text-sm text-zinc-500">Aucun.</p>}</div>
    </div>

    <div className="space-y-4 rounded-2xl border border-violet-500/30 bg-violet-500/5 p-4" id="shop-financial-advisor">
      <div><h3 className="text-lg font-bold">Conseiller financier — Wesh Star Shop</h3><p className="text-sm text-zinc-400">Recommandations indicatives à partir du taux configuré. Le conseiller ne modifie jamais les commissions automatiquement.</p></div>
      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Taux actuel</p><p className="text-2xl font-extrabold">{Number(s.commissionPct).toFixed(1)} %</p></div>
        <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Taux de départ conseillé</p><p className="text-2xl font-extrabold">8 %</p><p className="text-xs text-zinc-500">Pour lancer la marketplace et tester l'adoption.</p></div>
        <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Plage à tester ensuite</p><p className="text-2xl font-extrabold">8–12 %</p><p className="text-xs text-zinc-500">Seulement si la valeur apportée et les coûts le justifient.</p></div>
      </div>
      <div className="space-y-2 text-sm text-zinc-300">
        {Number(s.commissionPct) < 8 ? <p className="rounded-lg border border-amber-500/30 p-3">💡 <b>Proposition :</b> tester 8 % comme taux général, puis comparer les ventes et les abandons de panier avant toute hausse.</p> : Number(s.commissionPct) <= 12 ? <p className="rounded-lg border border-emerald-500/30 p-3">✓ Le taux actuel se trouve dans la plage de départ conseillée. Mesure les coûts de paiement, le support et les remboursements avant de le modifier.</p> : <p className="rounded-lg border border-amber-500/30 p-3">⚠️ Le taux actuel dépasse 12 %. Vérifie que les services supplémentaires justifient ce niveau et que les vendeurs restent compétitifs.</p>}
        <p><b>Règle pratique :</b> 8 % pour commencer ; envisager 10 % après mesure des coûts ; 12 % seulement si Wesh Star finance réellement davantage de protection, d'assistance ou d'acquisition. Ce n'est pas une garantie de rentabilité : la devise, les frais de paiement, les remboursements et les taxes doivent être pris en compte.</p>
        <p><b>Exemple sur une vente de 100 € :</b> la commission brute serait de {(100 * Number(s.commissionPct || 0) / 100).toFixed(2)} €, avant frais fixes, frais du prestataire de paiement, remboursements et charges. Le net vendeur doit rester clairement affiché avant l'achat.</p>
        <p><b>Alertes à surveiller :</b> commandes non expédiées après le délai, litiges ouverts, retraits en attente, remboursements et hausse des frais. Le tableau admin existant affiche déjà commandes, commissions, fonds bloqués et litiges ; les alertes automatiques détaillées restent à relier à ces événements.</p>
      </div>
    </div>

    <div className="space-y-3"><h3 className="font-bold">Réglages des ventes</h3>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={s.escrowEnabled} onChange={(e) => setS({ ...s, escrowEnabled: e.target.checked })} />Paiements de la boutique activés</label>
      <div className="flex flex-wrap items-center gap-3 text-sm">
        <label>Commission globale (%) {num("commissionPct", "0.5")}</label>
        <label>Blocage de l'argent (heures) {num("holdHours")}</label>
        <label>Nouveau vendeur (heures) {num("newSellerHoldHours")}</label>
        <label>Ventes pour ne plus être « nouveau » {num("newSellerOrdersThreshold")}</label>
        <label>Délai d'expédition (jours) {num("shipDeadlineDays")}</label>
        <label>Blocage après expédition (h) {num("postShipHoldHours")}</label>
        <label>Promotion min (%) {num("promoMinPct", "0.5")}</label>
        <label>Promotion max (%) {num("promoMaxPct", "0.5")}</label>
      </div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={s.releaseRequiresShipping} onChange={(e) => setS({ ...s, releaseRequiresShipping: e.target.checked })} />Ne libérer l'argent qu'après expédition (numéro de suivi)</label>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={s.payoutRequiresVerification} onChange={(e) => setS({ ...s, payoutRequiresVerification: e.target.checked })} />Vendeur vérifié obligatoire avant retrait</label>
      <div className="grid gap-2 text-xs text-zinc-400">
        <label>Commission par catégorie (JSON, ex. {`{"mode":10}`})<input className="input w-full" value={json.category} onChange={(e) => setJson({ ...json, category: e.target.value })} /></label>
        <label>Commission par pays du vendeur (JSON, ex. {`{"BJ":6}`})<input className="input w-full" value={json.country} onChange={(e) => setJson({ ...json, country: e.target.value })} /></label>
        <label>Frais fixes par devise en unité mineure (ex. {`{"EUR":50,"XOF":10000}`})<input className="input w-full" value={json.fixed} onChange={(e) => setJson({ ...json, fixed: e.target.value })} /></label>
        <label>Retrait minimum par devise en unité mineure<input className="input w-full" value={json.minPayout} onChange={(e) => setJson({ ...json, minPayout: e.target.value })} /></label>
      </div>
      <button className="btn btn-primary" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "save_settings", settings: { ...s, categoryCommissionPct: parse(json.category), countryCommissionPct: parse(json.country), fixedFeeMinor: parse(json.fixed), minPayoutMinor: parse(json.minPayout) } }); return "Réglages enregistrés."; })}>Enregistrer les réglages</button>
    </div>

    <div className="space-y-3"><h3 className="font-bold">Essais gratuits et crédits d'images</h3>
      <div className="flex flex-wrap items-center gap-3 text-sm">
        <label>Essais vidéo gratuits (0 = tout payant) <input className="input w-24" type="number" min={0} value={b.freeTrialVideoUses} onChange={(e) => setB({ ...b, freeTrialVideoUses: Number(e.target.value) })} /></label>
        <label>Essais image gratuits <input className="input w-24" type="number" min={0} value={b.freeTrialImageUses} onChange={(e) => setB({ ...b, freeTrialImageUses: Number(e.target.value) })} /></label>
        <label>Alerte « solde bas » sous (secondes, 0 = désactivée) <input className="input w-24" type="number" min={0} value={b.lowBalanceSeconds ?? 60} onChange={(e) => setB({ ...b, lowBalanceSeconds: Number(e.target.value) })} /></label>
        <label>Coût d'une image (secondes de crédit) <input className="input w-24" type="number" min={1} value={b.imageCostSeconds} onChange={(e) => setB({ ...b, imageCostSeconds: Number(e.target.value) })} /></label>
      </div>
      <button className="btn btn-primary" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "save_billing", billing: b }); return "Facturation enregistrée."; })}>Enregistrer</button>
    </div>

    {calls && <div className="space-y-2"><h3 className="font-bold">Appels privés audio/vidéo</h3>
      <p className="text-xs text-zinc-400">Interrupteur serveur (COMMUNICATIONS_ENABLED) : {calls.serverEnabled ? "activé" : "DÉSACTIVÉ — passe-le à true dans .env après avoir testé"} · LiveKit : {calls.livekitConfigured ? "configuré" : "NON configuré"} · signalements d'appels : {calls.reports}</p>
      <div className="flex flex-wrap items-center gap-3 text-sm"><label className="flex items-center gap-2"><input type="checkbox" checked={calls.callsEnabled} onChange={(e) => setCalls({ ...calls, callsEnabled: e.target.checked })} />Appels autorisés</label>
        <label>Qui peut appeler <select className="input w-44" value={calls.callsAccess} onChange={(e) => setCalls({ ...calls, callsAccess: e.target.value })}><option value="all">Tout le monde</option><option value="subscribers">Abonnés payants</option><option value="verified">Comptes vérifiés</option></select></label>
        <button className="btn btn-primary btn-sm" disabled={busy} onClick={() => void run(async () => { await fetch("/api/admin/communication", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ callsEnabled: calls.callsEnabled, callsAccess: calls.callsAccess }) }); return "Réglages d'appels enregistrés."; })}>Enregistrer</button></div></div>}

    <div className="space-y-2"><h3 className="font-bold">Litiges ouverts ({data.disputes.length})</h3>
      {data.disputes.length === 0 && <p className="text-sm text-zinc-500">Aucun litige.</p>}
      {data.disputes.map((d: any) => <div key={d.id} className="space-y-2 rounded-xl border border-zinc-800 p-3 text-sm">
        <p><b>{d.title}</b> — {money(d.subtotal_minor, d.currency)} · acheteur {d.buyer} · vendeur {d.seller}</p>
        <p className="text-zinc-400">Motif : {d.reason}. {d.details}</p>
        <input className="input w-full" placeholder="Note / message visible par les deux parties" value={note[d.order_id] || ""} onChange={(e) => setNote({ ...note, [d.order_id]: e.target.value })} />
        <div className="flex flex-wrap items-center gap-2">
          <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "resolve_dispute", orderId: d.order_id, resolution: "refund_buyer", note: note[d.order_id] }); return "Acheteur remboursé."; })}>Rembourser l'acheteur</button>
          <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "resolve_dispute", orderId: d.order_id, resolution: "pay_seller", note: note[d.order_id] }); return "Vendeur payé."; })}>Payer le vendeur</button>
          <input className="input w-28" type="number" step="0.01" placeholder="Montant" value={refund[d.order_id] || ""} onChange={(e) => setRefund({ ...refund, [d.order_id]: e.target.value })} />
          <button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "resolve_dispute", orderId: d.order_id, resolution: "partial_refund", refundAmount: Number(refund[d.order_id]), note: note[d.order_id] }); return "Remboursement partiel fait."; })}>Remboursement partiel</button>
        </div></div>)}
    </div>

    <div className="space-y-2"><h3 className="font-bold">Retraits vendeurs ({data.payouts.length})</h3>
      {data.payouts.map((p: any) => <div key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-zinc-800 p-3 text-sm">
        <div><p><b>{money(p.amount_minor, p.currency)}</b> — {p.user_label} {p.verified ? "✓ vérifié" : "(non vérifié)"}</p><p className="text-xs text-zinc-400">{p.method} : {p.details}</p></div>
        <div className="flex gap-2"><button className="btn btn-primary btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "settle_payout", payoutId: p.id, outcome: "paid" }); return "Retrait marqué payé (après ton virement réel)."; })}>Payé</button>
          <button className="btn btn-danger btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "settle_payout", payoutId: p.id, outcome: "rejected", note: window.prompt("Raison du refus") || "" }); return "Retrait refusé, fonds rendus."; })}>Refuser</button></div></div>)}
      <div className="flex gap-2 text-sm"><input className="input w-full" placeholder="ID utilisateur à vérifier comme vendeur" value={verifyId} onChange={(e) => setVerifyId(e.target.value)} /><button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "verify_seller", userId: verifyId, verified: true }); return "Vendeur vérifié."; })}>Vérifier</button></div>
    </div>

    <div className="space-y-2"><h3 className="font-bold">Recharges manuelles à confirmer ({data.topups.length})</h3>
      {data.topups.map((t: any) => <div key={t.reference} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-zinc-800 p-3 text-sm">
        <p><b>{money(t.amount_minor, t.currency)}</b> — {t.user_label} · {t.reference}</p>
        <div className="flex gap-2"><button className="btn btn-primary btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "confirm_topup", reference: t.reference }); return "Recharge confirmée."; })}>Confirmer (argent reçu)</button><button className="btn btn-danger btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "reject_topup", reference: t.reference }); return "Recharge refusée."; })}>Refuser</button></div></div>)}
    </div>

    <div className="space-y-2"><h3 className="font-bold">Annonces signalées ({data.reports.length})</h3>
      {data.reports.map((r: any) => <div key={r.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-zinc-800 p-3 text-sm"><p><b>{r.title}</b> — {r.reason}</p>
        <div className="flex gap-2"><button className="btn btn-danger btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "report_status", reportId: r.id, status: "actioned", pauseProduct: true }); return "Annonce mise en pause."; })}>Mettre en pause</button><button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "report_status", reportId: r.id, status: "dismissed" }); })}>Ignorer</button></div></div>)}
    </div>

    <div className="space-y-2"><h3 className="font-bold">Dernières commandes</h3><div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead className="text-zinc-500"><tr><th>Produit</th><th>Statut</th><th>Total</th><th>Commission</th><th>Promo</th><th>Net vendeur</th></tr></thead><tbody>
      {data.orders.map((o: any) => <tr key={o.id} className="border-t border-zinc-800"><td>{o.title}</td><td>{o.status}</td><td>{money(o.subtotal_minor, o.currency)}</td><td>{money(o.commission_minor + o.fixed_fee_minor, o.currency)}</td><td>{money(o.promo_minor, o.currency)}</td><td>{money(o.seller_net_minor, o.currency)}</td></tr>)}</tbody></table></div></div>
  </section>;
}
