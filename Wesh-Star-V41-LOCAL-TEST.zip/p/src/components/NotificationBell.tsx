"use client";
import { useCallback, useEffect, useState } from "react";

type N = { id: string; kind: string; title: string; body: string; url: string; read_at: string | null; created_at: string };
const b64ToUint8 = (s: string) => { const pad = "=".repeat((4 - (s.length % 4)) % 4); const raw = atob((s + pad).replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from(raw, (c) => c.charCodeAt(0)); };

// Cloche de notifications (dans l'appli) + activation des notifications Push sur ce téléphone/navigateur.
export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<N[]>([]);
  const [unread, setUnread] = useState(0);
  const [pushState, setPushState] = useState<"unknown" | "unsupported" | "off" | "on" | "denied" | "unavailable">("unknown");
  const [msg, setMsg] = useState("");

  const load = useCallback(async () => {
    try { const r = await fetch("/api/notifications", { cache: "no-store" }); if (!r.ok) return; const d = await r.json(); setItems(d.notifications || []); setUnread(d.unread || 0); } catch { /* réseau */ }
  }, []);
  useEffect(() => { void load(); const t = setInterval(() => { if (!document.hidden) void load(); }, 30_000); return () => clearInterval(t); }, [load]);
  useEffect(() => {
    (async () => {
      if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) return setPushState("unsupported");
      if (Notification.permission === "denied") return setPushState("denied");
      const reg = await navigator.serviceWorker.ready.catch(() => null);
      const sub = await reg?.pushManager.getSubscription();
      setPushState(sub ? "on" : "off");
    })();
  }, []);

  const enablePush = async () => {
    setMsg("");
    try {
      const k = await (await fetch("/api/push/subscribe", { cache: "no-store" })).json();
      if (!k.enabled || !k.publicKey) { setPushState("unavailable"); return setMsg("Les notifications Push ne sont pas encore configurées sur ce serveur."); }
      const perm = await Notification.requestPermission();
      if (perm !== "granted") { setPushState("denied"); return; }
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToUint8(k.publicKey) });
      const r = await fetch("/api/push/subscribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(sub.toJSON()) });
      if (!r.ok) throw new Error("subscribe");
      setPushState("on"); setMsg("Notifications activées sur cet appareil.");
    } catch { setMsg("Activation impossible sur cet appareil."); }
  };
  const disablePush = async () => {
    const reg = await navigator.serviceWorker.ready; const sub = await reg.pushManager.getSubscription();
    if (sub) { await fetch("/api/push/subscribe", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ endpoint: sub.endpoint }) }); await sub.unsubscribe(); }
    setPushState("off");
  };
  const readAll = async () => { await fetch("/api/notifications", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ all: true }) }); await load(); };
  const openItem = async (n: N) => { if (!n.read_at) await fetch("/api/notifications", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: n.id }) }); window.location.href = n.url || "/"; };

  return <div className="fixed right-3 top-3 z-30">
    <button aria-label={`Notifications${unread ? `, ${unread} non lues` : ""}`} onClick={() => { setOpen(!open); if (!open) void load(); }} className="relative rounded-full border border-zinc-700 bg-zinc-950/90 px-3 py-2 text-lg shadow">🔔{unread > 0 && <span className="absolute -right-1 -top-1 rounded-full bg-red-600 px-1.5 text-[10px] font-bold text-white">{unread > 9 ? "9+" : unread}</span>}</button>
    {open && <div role="dialog" aria-label="Notifications" className="mt-2 w-80 max-w-[90vw] rounded-2xl border border-zinc-700 bg-zinc-950 p-3 shadow-2xl">
      <div className="flex items-center justify-between"><p className="font-bold">Notifications</p>{unread > 0 && <button className="text-xs text-zinc-400 underline" onClick={() => void readAll()}>Tout marquer comme lu</button>}</div>
      <div className="mt-2 max-h-80 space-y-2 overflow-y-auto">{items.length === 0 ? <p className="py-4 text-center text-sm text-zinc-500">Rien pour le moment.</p> : items.map((n) => <button key={n.id} onClick={() => void openItem(n)} className={`block w-full rounded-xl border p-2 text-left text-sm ${n.read_at ? "border-zinc-800 text-zinc-400" : "border-emerald-500/40"}`}><span className="font-semibold">{n.title}</span><span className="block text-xs text-zinc-400">{n.body}</span><span className="block text-[10px] text-zinc-600">{new Date(n.created_at).toLocaleString()}</span></button>)}</div>
      <div className="mt-3 border-t border-zinc-800 pt-2 text-xs">
        {pushState === "off" && <button className="btn btn-secondary btn-sm" onClick={() => void enablePush()}>Activer les notifications sur ce téléphone</button>}
        {pushState === "on" && <button className="text-zinc-400 underline" onClick={() => void disablePush()}>Désactiver les notifications sur cet appareil</button>}
        {pushState === "denied" && <p className="text-zinc-500">Notifications bloquées : autorise-les dans les réglages du navigateur.</p>}
        {pushState === "unsupported" && <p className="text-zinc-500">Ce navigateur ne gère pas les notifications Push (sur iPhone : installe d'abord l'appli sur l'écran d'accueil).</p>}
        {msg && <p role="status" className="mt-1 text-zinc-300">{msg}</p>}
      </div>
    </div>}
  </div>;
}
