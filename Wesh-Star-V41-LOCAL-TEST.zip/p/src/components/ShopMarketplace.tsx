"use client";
import { useCallback, useEffect, useState, type FormEvent } from "react";

type Product = { id: string; seller_id: string; title: string; description: string; category: string; image_url: string | null; price_minor: number; currency: string; country_code: string; stock_quantity: number; shipping_countries: string[]; status?: string; seller_label?: string; sponsored?: boolean; promo_enabled?: boolean; promo_pct?: number };
type Order = { id: string; buyer_id: string; seller_id: string; quantity: number; currency: string; subtotal_minor: number; commission_minor: number; fixed_fee_minor: number; promo_minor: number; seller_net_minor: number; refunded_minor: number; status: string; title: string; other_party: string; role: "buyer" | "seller"; paid_at: string; ship_by: string; release_at: string; tracking_carrier?: string; tracking_number?: string; dispute_id?: string; dispute_status?: string; dispute_resolution?: string; review_rating?: number | null; messages: { author_role: string; body: string; image_url?: string | null }[] };
type Bal = { currency: string; available: number; payoutHold: number; pendingSales: number };
type Rules = { holdHours: number; newSellerHoldHours: number; payoutRequiresVerification: boolean; flutterwave: boolean };
type ShopRules = { commissionPct: number; holdHours: number; newSellerHoldHours: number; promoMinPct: number; promoMaxPct: number; shipDeadlineDays: number; escrowEnabled: boolean };

const CURRENCIES = ["EUR", "XOF", "USD", "GBP"];
const money = (minor: number, currency: string) => new Intl.NumberFormat(undefined, { style: "currency", currency, maximumFractionDigits: currency === "XOF" ? 0 : 2 }).format(minor / 100);
const STATUS: Record<string, string> = { paid: "Payée — argent bloqué", shipped: "Expédiée", delivered: "Livrée", completed: "Terminée", cancelled: "Annulée (remboursée)", refunded: "Remboursée", disputed: "En litige" };
const ERR: Record<string, string> = {
  INSUFFICIENT_FUNDS: "Solde insuffisant : recharge ton solde boutique.", INSUFFICIENT_STOCK: "Stock insuffisant.", CANNOT_BUY_OWN_PRODUCT: "Tu ne peux pas acheter ton propre produit.",
  SELLER_DOES_NOT_SHIP_TO_COUNTRY: "Le vendeur n'expédie pas vers ce pays.", SELLER_NOT_VERIFIED: "Ton compte vendeur doit être vérifié par l'admin avant le premier retrait.",
  BELOW_MIN_PAYOUT: "Montant inférieur au minimum de retrait.", INVALID_PROMO_PCT: "Pourcentage de promotion hors des limites autorisées.", CONTENT_NOT_ALLOWED: "Ce texte n'est pas autorisé.",
  SHOP_PAYMENTS_DISABLED: "Les paiements de la boutique sont désactivés pour le moment.", RATE_LIMIT: "Trop d'actions : réessaie dans une minute.", TRACKING_REQUIRED: "Indique le transporteur et le numéro de suivi."
};
const say = (e: any) => ERR[e?.message] || e?.message || "Erreur.";
async function api(url: string, method: string, body?: unknown) {
  const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body), cache: "no-store" });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(d.error || "ERROR"), d);
  return d;
}

export default function ShopMarketplace() {
  const [tab, setTab] = useState<"shop" | "mine" | "orders" | "wallet">("shop");
  const [products, setProducts] = useState<Product[]>([]);
  const [own, setOwn] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [bal, setBal] = useState<Bal[]>([]);
  const [rules, setRules] = useState<Rules | null>(null);
  const [shop, setShop] = useState<ShopRules | null>(null);
  const [verified, setVerified] = useState(false);
  const [q, setQ] = useState(""); const [country, setCountry] = useState("");
  const [msg, setMsg] = useState(""); const [busy, setBusy] = useState("");
  const [ship, setShip] = useState<Record<string, string>>({}); const [qty, setQty] = useState<Record<string, string>>({});
  const [note, setNote] = useState<Record<string, string>>({}); const [track, setTrack] = useState<Record<string, string>>({});
  const [form, setForm] = useState({ title: "", description: "", category: "other", imageUrl: "", price: "", currency: "EUR", countryCode: "DE", stockQuantity: "1", shippingCountries: "DE,FR,BE,BJ,CI,SN,NG", promoEnabled: false, promoPct: "5" });
  const [top, setTop] = useState({ currency: "XOF", amount: "" });
  const [pay, setPay] = useState({ currency: "XOF", amount: "", method: "mobile_money", details: "" });

  const load = useCallback(async () => {
    try {
      const params = new URLSearchParams(); if (q.trim()) params.set("q", q.trim()); if (country.trim()) params.set("country", country.trim().toUpperCase());
      const [p, o, w, s] = await Promise.all([api("/api/shop/products?" + params, "GET"), api("/api/shop/purchases", "GET"), api("/api/shop/wallet", "GET"), api("/api/shop/settings", "GET")]);
      setProducts(p.products || []); setOwn(p.ownProducts || []); setOrders(o.orders || []);
      setBal(w.balances || []); setRules(w.rules); setVerified(!!w.sellerVerified); setShop(s);
    } catch (e: any) { setMsg(say(e)); }
  }, [q, country]);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => { if (typeof window !== "undefined" && new URLSearchParams(window.location.search).get("topup") === "success") { setMsg("Recharge confirmée : ton solde est à jour."); setTab("wallet"); } }, []);

  const run = async (key: string, fn: () => Promise<string | void>) => { setBusy(key); setMsg(""); try { const m = await fn(); if (m) setMsg(m); await load(); } catch (e: any) { setMsg(say(e)); } finally { setBusy(""); } };
  const publish = (e: FormEvent) => { e.preventDefault(); void run("publish", async () => {
    await api("/api/shop/products", "POST", { ...form, price: Number(form.price), stockQuantity: Number(form.stockQuantity), promoPct: Number(form.promoPct), shippingCountries: form.shippingCountries.split(/[ ,;]+/).filter(Boolean).map((x) => x.toUpperCase()) });
    setForm({ ...form, title: "", description: "", price: "" }); setTab("mine"); return "Produit publié.";
  }); };
  const buy = (p: Product) => run("buy" + p.id, async () => {
    await api("/api/shop/purchases", "POST", { productId: p.id, quantity: Number(qty[p.id] || 1), shippingCountry: (ship[p.id] || "").toUpperCase(), message: note[p.id] || "" });
    setTab("orders"); return "Achat payé. L'argent est bloqué en séquestre jusqu'à la livraison (ou " + (shop?.holdHours ?? 48) + " h).";
  });
  const act = (id: string, action: string, extra: Record<string, unknown> = {}, done = "Fait.") => run(id + action, async () => { await api("/api/shop/purchases", "PATCH", { id, action, ...extra }); return done; });
  const sel = "input w-full";

  const sponsored = (p: Product) => p.sponsored ? <span className="badge badge-yellow">Sponsorisé</span> : null;
  return <div className="space-y-5">
    <section className="card space-y-3 p-5">
      <div className="flex flex-wrap gap-2">{([["shop", "Boutique"], ["mine", "Mes annonces"], ["orders", "Commandes"], ["wallet", "Mon solde"]] as const).map(([k, l]) => <button key={k} className={tab === k ? "btn btn-primary btn-sm" : "btn btn-secondary btn-sm"} onClick={() => setTab(k)}>{l}</button>)}</div>
      {shop && <p className="text-xs text-zinc-400">Paiement sécurisé par Wesh Star : l'argent est bloqué en séquestre {shop.holdHours} h ({Math.round(shop.newSellerHoldHours / 24)} j pour les nouveaux vendeurs) puis versé au vendeur. Remboursement possible en cas de litige. Commission de la plateforme : {shop.commissionPct} %.</p>}
      {msg && <p role="status" className="rounded-xl border border-zinc-800 p-3 text-sm text-zinc-300">{msg}</p>}
    </section>

    {tab === "shop" && <section className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-[1fr_120px_auto]"><input className={sel} placeholder="Rechercher un produit…" value={q} onChange={(e) => setQ(e.target.value)} /><input className={sel} placeholder="Pays" maxLength={2} value={country} onChange={(e) => setCountry(e.target.value.toUpperCase())} /><button className="btn btn-secondary" onClick={() => void load()}>Rechercher</button></div>
      {products.length === 0 ? <div className="card p-8 text-center text-sm text-zinc-400">Aucun produit pour cette recherche.</div> :
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{products.map((p) => <article key={p.id} className="card space-y-2 p-4">
          {p.image_url && <img src={p.image_url} alt={p.title} className="h-40 w-full rounded-lg object-cover" />}
          <div className="flex items-start justify-between gap-2"><h3 className="font-bold">{p.title}</h3>{sponsored(p)}</div>
          <p className="text-sm text-zinc-400 line-clamp-3">{p.description}</p>
          <p className="text-lg font-extrabold">{money(p.price_minor, p.currency)}</p>
          <p className="text-xs text-zinc-500">{p.seller_label} · expédié depuis {p.country_code} · stock {p.stock_quantity}</p>
          <div className="grid grid-cols-[70px_1fr] gap-2"><input className={sel} type="number" min={1} max={p.stock_quantity} placeholder="Qté" value={qty[p.id] || "1"} onChange={(e) => setQty({ ...qty, [p.id]: e.target.value })} /><input className={sel} placeholder="Pays de livraison (ex. BJ)" maxLength={2} value={ship[p.id] || ""} onChange={(e) => setShip({ ...ship, [p.id]: e.target.value.toUpperCase() })} /></div>
          <input className={sel} placeholder="Message au vendeur (optionnel)" value={note[p.id] || ""} onChange={(e) => setNote({ ...note, [p.id]: e.target.value })} />
          <button className="btn btn-primary w-full" disabled={busy === "buy" + p.id} onClick={() => void buy(p)}>Acheter · {money(p.price_minor * Number(qty[p.id] || 1), p.currency)}</button>
          <button className="text-xs text-zinc-500 underline" onClick={() => void run("rep" + p.id, async () => { const reason = window.prompt("Pourquoi signaler cette annonce ?"); if (!reason) return; await api("/api/shop/reports", "POST", { productId: p.id, reason }); return "Signalement envoyé."; })}>Signaler</button>
        </article>)}</div>}
    </section>}

    {tab === "mine" && <section className="space-y-4">
      <form onSubmit={publish} className="card space-y-3 p-5">
        <h2 className="text-lg font-bold">Publier un produit</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          <input className={sel} placeholder="Nom" required minLength={3} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <input className={sel} placeholder="Catégorie" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
          <input className={sel} placeholder="Prix" type="number" step="0.01" min="0.01" required value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
          <select className={sel} value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</select>
          <input className={sel} placeholder="Pays d'expédition (ex. BJ)" maxLength={2} required value={form.countryCode} onChange={(e) => setForm({ ...form, countryCode: e.target.value.toUpperCase() })} />
          <input className={sel} placeholder="Stock" type="number" min={1} value={form.stockQuantity} onChange={(e) => setForm({ ...form, stockQuantity: e.target.value })} />
        </div>
        <textarea className={sel} placeholder="Description" required minLength={5} rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <input className={sel} placeholder="Lien de l'image (https://…)" value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} />
        <input className={sel} placeholder="Pays livrés (ex. BJ,CI,SN)" value={form.shippingCountries} onChange={(e) => setForm({ ...form, shippingCountries: e.target.value })} />
        {shop && <label className="flex flex-wrap items-center gap-2 text-sm"><input type="checkbox" checked={form.promoEnabled} onChange={(e) => setForm({ ...form, promoEnabled: e.target.checked })} />Faire promouvoir ce produit par Wesh Star (mis en avant, marqué « Sponsorisé »). Part reversée à la plateforme à chaque vente :
          <input className="input w-20" type="number" step="0.5" min={shop.promoMinPct} max={shop.promoMaxPct} value={form.promoPct} disabled={!form.promoEnabled} onChange={(e) => setForm({ ...form, promoPct: e.target.value })} /> % <span className="text-xs text-zinc-500">({shop.promoMinPct}–{shop.promoMaxPct} %)</span></label>}
        <p className="text-xs text-zinc-500">Commission de la plateforme : {shop?.commissionPct ?? "—"} % du prix, déduite avant le versement. Ne vends que ce que tu as le droit de vendre.</p>
        <button className="btn btn-primary" disabled={busy === "publish"}>Publier</button>
      </form>
      <div className="card p-5"><h2 className="text-lg font-bold">Mes annonces</h2>{own.length === 0 ? <p className="mt-2 text-sm text-zinc-500">Aucune annonce.</p> : <div className="mt-3 divide-y divide-zinc-800">{own.map((p) => <div key={p.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
        <div><p className="font-semibold">{p.title}</p><p className="text-xs text-zinc-500">{money(p.price_minor, p.currency)} · stock {p.stock_quantity} · {p.status}{p.promo_enabled ? ` · promotion ${p.promo_pct} %` : ""}</p></div>
        <div className="flex flex-wrap gap-2">
          <button className="btn btn-secondary btn-sm" onClick={() => void run(p.id, async () => { await api("/api/shop/products", "PATCH", { id: p.id, action: p.status === "active" ? "pause" : "activate" }); })}>{p.status === "active" ? "Pause" : "Réactiver"}</button>
          <button className="btn btn-secondary btn-sm" onClick={() => void run(p.id + "pr", async () => { const on = !p.promo_enabled; const pct = on ? Number(window.prompt(`Pourcentage pour Wesh Star (${shop?.promoMinPct}–${shop?.promoMaxPct} %)`, "5")) : 0; await api("/api/shop/products", "PATCH", { id: p.id, action: "promo", promoEnabled: on, promoPct: pct }); return on ? "Promotion activée." : "Promotion désactivée."; })}>{p.promo_enabled ? "Arrêter la promo" : "Promouvoir"}</button>
        </div></div>)}</div>}</div>
    </section>}

    {tab === "orders" && <section className="space-y-3">
      {orders.length === 0 ? <div className="card p-8 text-center text-sm text-zinc-400">Aucune commande.</div> : orders.map((o) => <article key={o.id} className="card space-y-2 p-4">
        <div className="flex flex-wrap items-start justify-between gap-2"><div><h3 className="font-bold">{o.title} × {o.quantity}</h3><p className="text-xs text-zinc-500">{o.role === "buyer" ? "Vendeur" : "Acheteur"} : {o.other_party}</p></div><span className="badge badge-violet">{STATUS[o.status] || o.status}</span></div>
        <p className="text-sm">{o.role === "buyer" ? `Payé : ${money(o.subtotal_minor, o.currency)}` : `Tu recevras : ${money(o.seller_net_minor, o.currency)} (commission ${money(o.commission_minor + o.fixed_fee_minor + o.promo_minor, o.currency)})`}{o.refunded_minor > 0 ? ` · remboursé ${money(o.refunded_minor, o.currency)}` : ""}</p>
        {["paid", "shipped", "delivered"].includes(o.status) && <p className="text-xs text-zinc-500">Argent bloqué jusqu'au {new Date(o.release_at).toLocaleString()}{o.status === "paid" ? ` · à expédier avant le ${new Date(o.ship_by).toLocaleDateString()}` : ""}</p>}
        {o.tracking_number && <p className="text-xs text-zinc-400">Suivi : {o.tracking_carrier} {o.tracking_number}</p>}
        <div className="flex flex-wrap gap-2">
          {o.role === "seller" && o.status === "paid" && <><input className="input w-32" placeholder="Transporteur" value={track[o.id + "c"] || ""} onChange={(e) => setTrack({ ...track, [o.id + "c"]: e.target.value })} /><input className="input w-40" placeholder="N° de suivi" value={track[o.id + "n"] || ""} onChange={(e) => setTrack({ ...track, [o.id + "n"]: e.target.value })} /><button className="btn btn-primary btn-sm" onClick={() => void act(o.id, "ship", { carrier: track[o.id + "c"], tracking: track[o.id + "n"] }, "Expédition enregistrée.")}>Marquer expédiée</button></>}
          {o.role === "buyer" && ["shipped", "delivered"].includes(o.status) && <button className="btn btn-primary btn-sm" onClick={() => void act(o.id, "confirm_received", {}, "Réception confirmée : le vendeur est payé.")}>J'ai bien reçu</button>}
          {o.role === "buyer" && ["paid", "shipped", "delivered"].includes(o.status) && !o.dispute_id && <button className="btn btn-secondary btn-sm" onClick={() => { const reason = window.prompt("Motif : not_received, not_as_described, damaged ou other", "not_received"); if (!reason) return; const details = window.prompt("Explique le problème :") || ""; void act(o.id, "open_dispute", { reason, details }, "Litige ouvert : l'argent reste bloqué."); }}>Ouvrir un litige</button>}
          {((o.role === "buyer" && o.status === "paid" && !o.tracking_number) || (o.role === "seller" && ["paid", "shipped"].includes(o.status))) && <button className="btn btn-danger btn-sm" onClick={() => void act(o.id, "cancel", {}, "Commande annulée et remboursée.")}>Annuler et rembourser</button>}
          {o.role === "buyer" && o.status === "completed" && !o.review_rating && <button className="btn btn-secondary btn-sm" onClick={() => { const r = Number(window.prompt("Note de 1 à 5", "5")); if (!r) return; void act(o.id, "review", { rating: r, comment: window.prompt("Commentaire (optionnel)") || "" }, "Merci pour ton avis."); }}>Noter le vendeur</button>}
        </div>
        {o.dispute_id && <div className="rounded-xl border border-amber-500/30 p-3 text-sm"><p className="font-semibold">Litige : {o.dispute_status === "resolved" ? `résolu (${o.dispute_resolution})` : "en cours — l'équipe Wesh Star tranchera"}</p>
          {o.messages.map((m, i) => <p key={i} className="mt-1 text-zinc-300"><b>{m.author_role === "admin" ? "Wesh Star" : m.author_role === "buyer" ? "Acheteur" : "Vendeur"} :</b> {m.body}{m.image_url && <> · <a className="underline" href={m.image_url} target="_blank" rel="noreferrer">photo</a></>}</p>)}
          {o.dispute_status !== "resolved" && <div className="mt-2 flex gap-2"><input className={sel} placeholder="Ton message" value={note[o.id + "d"] || ""} onChange={(e) => setNote({ ...note, [o.id + "d"]: e.target.value })} /><button className="btn btn-secondary btn-sm" onClick={() => void act(o.id, "dispute_message", { body: note[o.id + "d"] || "" }, "Message envoyé.")}>Envoyer</button></div>}</div>}
      </article>)}
    </section>}

    {tab === "wallet" && <section className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">{bal.map((b) => <div key={b.currency} className="card p-4"><p className="text-xs text-zinc-500">{b.currency}</p><p className="text-2xl font-extrabold">{money(b.available, b.currency)}</p><p className="text-xs text-zinc-400">Ventes en attente de déblocage : {money(b.pendingSales, b.currency)} · retraits en cours : {money(b.payoutHold, b.currency)}</p></div>)}</div>
      <div className="card space-y-3 p-5"><h2 className="font-bold">Recharger mon solde</h2>
        <div className="flex flex-wrap gap-2"><select className="input w-28" value={top.currency} onChange={(e) => setTop({ ...top, currency: e.target.value })}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</select><input className="input w-36" type="number" min="1" placeholder="Montant" value={top.amount} onChange={(e) => setTop({ ...top, amount: e.target.value })} />
          {rules?.flutterwave && ["XOF", "EUR"].includes(top.currency) && <button className="btn btn-primary" disabled={busy === "fw"} onClick={() => void run("fw", async () => { const d = await api("/api/payments/flutterwave/create", "POST", { kind: "shop_topup", currency: top.currency, amount: Number(top.amount) }); window.location.href = d.checkoutUrl; })}>Payer (Mobile Money / carte)</button>}
          <button className="btn btn-secondary" disabled={busy === "man"} onClick={() => void run("man", async () => { const d = await api("/api/shop/wallet", "POST", { action: "topup_manual", currency: top.currency, amount: Number(top.amount) }); return `Demande ${d.topup.reference} créée : paie selon les instructions de l'admin, puis il confirmera ta recharge.`; })}>Recharge manuelle</button></div></div>
      <div className="card space-y-3 p-5"><h2 className="font-bold">Retirer mes gains</h2>
        {rules?.payoutRequiresVerification && !verified && <p className="text-xs text-amber-300">Ton compte vendeur doit être vérifié par l'admin avant le premier retrait.</p>}
        <div className="flex flex-wrap gap-2"><select className="input w-28" value={pay.currency} onChange={(e) => setPay({ ...pay, currency: e.target.value })}>{CURRENCIES.map((c) => <option key={c}>{c}</option>)}</select><input className="input w-36" type="number" min="1" placeholder="Montant" value={pay.amount} onChange={(e) => setPay({ ...pay, amount: e.target.value })} />
          <select className="input w-40" value={pay.method} onChange={(e) => setPay({ ...pay, method: e.target.value })}><option value="mobile_money">Mobile Money</option><option value="bank">Virement bancaire</option><option value="paypal">PayPal</option></select></div>
        <input className={sel} placeholder="Numéro Mobile Money / IBAN / e-mail PayPal" value={pay.details} onChange={(e) => setPay({ ...pay, details: e.target.value })} />
        <button className="btn btn-primary" disabled={busy === "pay"} onClick={() => void run("pay", async () => { await api("/api/shop/wallet", "POST", { action: "payout", ...pay, amount: Number(pay.amount) }); return "Demande de retrait envoyée : l'admin la traitera."; })}>Demander le retrait</button></div>
    </section>}
    <p className="text-xs text-zinc-500">Ne partage pas de coordonnées bancaires dans les messages. Les règles locales (taxes, douanes, retours) restent à la charge du vendeur.</p>
  </div>;
}
