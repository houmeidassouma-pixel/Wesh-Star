"use client";
import { useEffect, useState } from "react";

const eur = (n: number | null | undefined) => (n === null || n === undefined ? "—" : n.toLocaleString(undefined, { style: "currency", currency: "EUR", maximumFractionDigits: 2 }));
async function api(method: string, body?: unknown, qs = "") {
  const r = await fetch("/api/admin/costs" + qs, { method, headers: { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body), cache: "no-store" });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || "Erreur");
  return d;
}
const FIELDS: [string, string, string][] = [
  ["electricityEurPerKwh", "Prix du kWh (€)", "0.01"], ["gpuWatts", "Puissance du GPU (W)", "1"], ["systemWatts", "Puissance du reste de la machine (W)", "1"],
  ["gpuSecondsPerVideoSecond", "Secondes de GPU par seconde de vidéo", "1"], ["gpuSecondsPerImage", "Secondes de GPU par image", "1"], ["overheadPct", "Surcoût CPU/texte/voix (%)", "1"],
  ["hardwareCostEur", "Prix du matériel (€)", "1"], ["hardwareLifetimeMonths", "Durée d'amortissement (mois)", "1"], ["fixedMonthlyEur", "Charges fixes par mois (internet, hébergement… €)", "1"],
  ["manualMonthlyRevenueEur", "Revenu mensuel des abonnements non suivi (€/mois)", "1"], ["targetMarginPct", "Marge nette visée (%)", "1"]
];

// Conseiller financier : coût de revient réel, marge nette, seuil de rentabilité et propositions à valider par l'admin.
export default function CostAdvisorPanel() {
  const [d, setD] = useState<any>(null); const [s, setS] = useState<any>(null); const [days, setDays] = useState(30);
  const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  const load = async (dd = days) => { try { const x = await api("GET", undefined, "?days=" + dd); setD(x); setS(x.settings); } catch (e: any) { setMsg(e.message); } };
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const run = async (fn: () => Promise<string | void>) => { setBusy(true); setMsg(""); try { const m = await fn(); if (m) setMsg(m); await load(); } catch (e: any) { setMsg(e.message || "Erreur"); } finally { setBusy(false); } };
  if (!d || !s) return <section className="card p-5" id="cost-advisor"><h2 className="text-xl font-bold">Coûts et rentabilité</h2><p className="mt-2 text-sm text-zinc-500">{msg || "Chargement…"}</p></section>;
  const r = d.report;
  return <section className="card space-y-5 p-5" id="cost-advisor">
    <div><h2 className="text-xl font-bold">Coûts et rentabilité</h2><p className="text-sm text-zinc-400">Estimation de ce que coûte réellement chaque génération (électricité, usure du matériel, charges fixes) comparée à ce que tu encaisses. Les temps GPU sont des estimations que tu règles ci-dessous.</p></div>
    {msg && <p role="status" className="rounded-xl border border-zinc-800 p-3 text-sm text-zinc-300">{msg}</p>}
    <div className="flex items-center gap-2 text-sm">Période :{[7, 30, 90].map((n) => <button key={n} className={days === n ? "btn btn-primary btn-sm" : "btn btn-secondary btn-sm"} onClick={() => { setDays(n); void load(n); }}>{n} jours</button>)}</div>
    <div className="grid gap-3 sm:grid-cols-3">
      <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Revenu</p><p className="text-lg font-bold">{eur(r.revenueEur)}</p></div>
      <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Coûts (élec. {eur(r.energyEur)} · matériel {eur(r.hardwareEur)} · fixes {eur(r.fixedEur)})</p><p className="text-lg font-bold">{eur(r.totalCostEur)}</p></div>
      <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Résultat net · marge</p><p className={`text-lg font-bold ${r.netEur < 0 ? "text-red-300" : "text-emerald-300"}`}>{eur(r.netEur)} · {r.marginPct === null ? "—" : r.marginPct.toFixed(1) + " %"}</p></div>
      <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Coût de revient d'une minute de vidéo</p><p className="text-lg font-bold">{eur(r.costPerVideoMinuteEur)}</p></div>
      <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Coût de revient d'une image</p><p className="text-lg font-bold">{eur(r.costPerImageEur)}</p></div>
      <div className="rounded-xl border border-zinc-800 p-3"><p className="text-xs text-zinc-500">Seuil de rentabilité</p><p className="text-lg font-bold">{r.breakEvenVideoMinutesPerMonth === null ? "—" : Math.ceil(r.breakEvenVideoMinutesPerMonth) + " min vidéo / mois"}</p></div>
    </div>
    <div className="space-y-2"><h3 className="font-bold">Propositions du conseiller</h3>
      {d.recommendations.filter((x: any) => x.status === "pending").length === 0 && <p className="text-sm text-zinc-500">Aucune proposition en attente.</p>}
      {d.recommendations.filter((x: any) => x.status === "pending").map((x: any) => <div key={x.id} className="space-y-2 rounded-xl border border-amber-500/30 p-3 text-sm"><p className="font-semibold">{x.title}</p><p className="text-zinc-400">{x.details}</p>
        <div className="flex gap-2"><button className="btn btn-primary btn-sm" disabled={busy} onClick={() => void run(async () => { const o = await api("POST", { action: "validate", id: x.id }); return o.applied; })}>Valider</button><button className="btn btn-secondary btn-sm" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "dismiss", id: x.id }); })}>Ignorer</button></div></div>)}
    </div>
    <div className="space-y-3"><h3 className="font-bold">Réglages du calcul</h3>
      <div className="grid gap-2 sm:grid-cols-2">{FIELDS.map(([k, l, step]) => <label key={k} className="text-xs text-zinc-400">{l}<input className="input mt-1 w-full" type="number" step={step} min={0} value={s[k]} onChange={(e) => setS({ ...s, [k]: Number(e.target.value) })} /></label>)}</div>
      <button className="btn btn-primary" disabled={busy} onClick={() => void run(async () => { await api("POST", { action: "save_settings", settings: s }); return "Réglages enregistrés."; })}>Enregistrer</button>
    </div>
  </section>;
}
