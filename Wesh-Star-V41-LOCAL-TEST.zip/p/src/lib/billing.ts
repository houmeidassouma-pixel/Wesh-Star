import { query } from "@/lib/db/pool";
import { quotaPeriodKey } from "@/lib/quota-period";

// Réglages de facturation modifiables dans l'admin : essais gratuits (vidéo / image) et coût d'une image en secondes de crédit.
export type BillingConfig = { freeTrialVideoUses: number; freeTrialImageUses: number; imageCostSeconds: number; lowBalanceSeconds: number };
export const DEFAULT_BILLING: BillingConfig = { freeTrialVideoUses: 2, freeTrialImageUses: 0, imageCostSeconds: 5, lowBalanceSeconds: 60 };

const clampInt = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Number(v);
  return Number.isInteger(n) && n >= min && n <= max ? n : fallback;
};

export function normalizeBilling(raw: any): BillingConfig {
  return {
    freeTrialVideoUses: clampInt(raw?.free_trial_video_uses ?? raw?.freeTrialVideoUses, 0, 1000, DEFAULT_BILLING.freeTrialVideoUses),
    freeTrialImageUses: clampInt(raw?.free_trial_image_uses ?? raw?.freeTrialImageUses, 0, 1000, DEFAULT_BILLING.freeTrialImageUses),
    imageCostSeconds: clampInt(raw?.image_cost_seconds ?? raw?.imageCostSeconds, 1, 3600, DEFAULT_BILLING.imageCostSeconds),
    lowBalanceSeconds: clampInt(raw?.low_balance_seconds ?? raw?.lowBalanceSeconds, 0, 86400, DEFAULT_BILLING.lowBalanceSeconds)
  };
}

export async function getBillingConfig(): Promise<BillingConfig> {
  try {
    const r = await query("select * from public.billing_config where id = true");
    return normalizeBilling(r.rows[0]);
  } catch { return DEFAULT_BILLING; }
}

export type ImageSource = "trial" | "plan" | "credits" | "free_staff";
export type ImageChargeResult =
  | { ok: true; chargeId: string; source: ImageSource; seconds: number }
  | { ok: false; error: "FREE_TRIAL_EXHAUSTED_IMAGE" | "QUOTA_LIMIT"; status: number; requiredSeconds: number };

/**
 * Débite UNE image avant de lancer le GPU : essai gratuit (si le forfait est gratuit), sinon quota du forfait,
 * sinon crédits achetés. Admin/modérateur : gratuit. Le débit est atomique (fonctions SQL avec verrou).
 */
export async function chargeImage(a: { userId: string; isStaff: boolean; planKey: string; profile: any; limits: any; chargeId: string }): Promise<ImageChargeResult> {
  const cfg = await getBillingConfig();
  const seconds = cfg.imageCostSeconds;
  const month = quotaPeriodKey(a.profile);
  const day = new Date().toISOString().slice(0, 10);
  const record = (source: ImageSource, secs: number) =>
    query("insert into public.image_charges (job_id,user_id,source,seconds,month,day) values ($1,$2,$3,$4,$5,$6)", [a.chargeId, a.userId, source, secs, month, day]);

  if (a.isStaff) { await record("free_staff", 0); return { ok: true, chargeId: a.chargeId, source: "free_staff", seconds: 0 }; }

  if (a.planKey === "free") {
    const t = await query("select public.consume_free_image_trial($1,$2) as ok", [a.userId, cfg.freeTrialImageUses]);
    if (t.rows[0]?.ok) { await record("trial", 0); return { ok: true, chargeId: a.chargeId, source: "trial", seconds: 0 }; }
  } else {
    const q = await query("select public.consume_generation_time_quota($1,$2,$3,$4,$5,$6,$7,$8) as ok", [a.userId, month, day, seconds, a.limits.monthlySeconds, a.limits.dailySeconds, a.limits.monthlyJobs, a.limits.dailyJobs]);
    if (q.rows[0]?.ok) { await record("plan", seconds); return { ok: true, chargeId: a.chargeId, source: "plan", seconds }; }
  }
  const c = await query("select public.consume_hour_credits($1,$2) as ok", [a.userId, seconds]);
  if (c.rows[0]?.ok) { await record("credits", seconds); return { ok: true, chargeId: a.chargeId, source: "credits", seconds }; }
  return a.planKey === "free"
    ? { ok: false, error: "FREE_TRIAL_EXHAUSTED_IMAGE", status: 402, requiredSeconds: seconds }
    : { ok: false, error: "QUOTA_LIMIT", status: 429, requiredSeconds: seconds };
}

/** Associe le débit à l'identifiant du job GPU (pour rembourser si le job échoue ensuite). */
export async function attachImageJob(chargeId: string, jobId: string) {
  await query("update public.image_charges set job_id=$2 where job_id=$1", [chargeId, jobId]);
}

/** Rembourse un débit d'image une seule fois (idempotent grâce au drapeau refunded). */
export async function refundImage(jobId: string, onlyUserId?: string): Promise<boolean> {
  const r = await query("update public.image_charges set refunded=true where job_id=$1 and refunded=false and ($2::uuid is null or user_id=$2::uuid) returning user_id,source,seconds,month,day", [jobId, onlyUserId || null]);
  const c = r.rows[0];
  if (!c) return false;
  if (c.source === "trial") await query("select public.refund_free_image_trial($1)", [c.user_id]);
  else if (c.source === "plan") await query("select public.refund_generation_time_quota($1,$2,$3,$4)", [c.user_id, c.month, c.day, c.seconds]);
  else if (c.source === "credits") await query("select public.refund_hour_credits($1,$2)", [c.user_id, c.seconds]);
  return true;
}
