// Logique pure (sans base de données) de la place de marché : commissions, blocage des fonds,
// écritures comptables. Tout est en unités mineures entières (centimes) pour éviter les erreurs d'arrondi.

export const SHOP_CURRENCIES = ["EUR", "XOF", "USD", "GBP"] as const;
export type ShopCurrency = (typeof SHOP_CURRENCIES)[number];

export type ShopSettings = {
  escrowEnabled: boolean;
  commissionPct: number;
  categoryCommissionPct: Record<string, number>;
  countryCommissionPct: Record<string, number>;
  fixedFeeMinor: Record<string, number>;
  holdHours: number;
  postShipHoldHours: number;
  newSellerHoldHours: number;
  newSellerOrdersThreshold: number;
  shipDeadlineDays: number;
  releaseRequiresShipping: boolean;
  promoMinPct: number;
  promoMaxPct: number;
  payoutRequiresVerification: boolean;
  minPayoutMinor: Record<string, number>;
};

export const DEFAULT_SHOP_SETTINGS: ShopSettings = {
  escrowEnabled: true,
  commissionPct: 8,
  categoryCommissionPct: {},
  countryCommissionPct: {},
  fixedFeeMinor: {},
  holdHours: 48,
  postShipHoldHours: 0,
  newSellerHoldHours: 168,
  newSellerOrdersThreshold: 3,
  shipDeadlineDays: 7,
  releaseRequiresShipping: true,
  promoMinPct: 1,
  promoMaxPct: 30,
  payoutRequiresVerification: true,
  minPayoutMinor: {}
};

const clampNum = (v: unknown, min: number, max: number, fallback: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};
const clampInt = (v: unknown, min: number, max: number, fallback: number) => Math.floor(clampNum(v, min, max, fallback));
const round2 = (n: number) => Math.round(n * 100) / 100;

function pctMap(raw: unknown, keyRe: RegExp, upper: boolean): Record<string, number> {
  const out: Record<string, number> = {};
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return out;
  for (const [k, v] of Object.entries(raw as Record<string, unknown>).slice(0, 100)) {
    const key = upper ? k.trim().toUpperCase() : k.trim().toLowerCase();
    if (!keyRe.test(key)) continue;
    const n = Number(v);
    if (Number.isFinite(n)) out[key] = round2(Math.min(50, Math.max(0, n)));
  }
  return out;
}
function minorMap(raw: unknown, max: number): Record<string, number> {
  const out: Record<string, number> = {};
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return out;
  for (const c of SHOP_CURRENCIES) {
    const n = Number((raw as any)[c]);
    if (Number.isFinite(n) && n > 0) out[c] = Math.min(max, Math.floor(n));
  }
  return out;
}

/** Valide et borne les réglages envoyés par l'admin (ou lus en base). */
export function normalizeShopSettings(raw: any): ShopSettings {
  const d = DEFAULT_SHOP_SETTINGS;
  const promoMin = round2(clampNum(raw?.promoMinPct, 0, 50, d.promoMinPct));
  const promoMax = round2(clampNum(raw?.promoMaxPct, 0, 50, d.promoMaxPct));
  return {
    escrowEnabled: raw?.escrowEnabled !== false,
    commissionPct: round2(clampNum(raw?.commissionPct, 0, 50, d.commissionPct)),
    categoryCommissionPct: pctMap(raw?.categoryCommissionPct, /^[a-z0-9_-]{1,60}$/, false),
    countryCommissionPct: pctMap(raw?.countryCommissionPct, /^[A-Z]{2}$/, true),
    fixedFeeMinor: minorMap(raw?.fixedFeeMinor, 10_000_000),
    holdHours: clampInt(raw?.holdHours, 0, 720, d.holdHours),
    postShipHoldHours: clampInt(raw?.postShipHoldHours, 0, 720, d.postShipHoldHours),
    newSellerHoldHours: clampInt(raw?.newSellerHoldHours, 0, 1440, d.newSellerHoldHours),
    newSellerOrdersThreshold: clampInt(raw?.newSellerOrdersThreshold, 0, 1000, d.newSellerOrdersThreshold),
    shipDeadlineDays: clampInt(raw?.shipDeadlineDays, 1, 60, d.shipDeadlineDays),
    releaseRequiresShipping: raw?.releaseRequiresShipping !== false,
    promoMinPct: Math.min(promoMin, promoMax),
    promoMaxPct: Math.max(promoMin, promoMax),
    payoutRequiresVerification: raw?.payoutRequiresVerification !== false,
    minPayoutMinor: minorMap(raw?.minPayoutMinor, 1_000_000_000)
  };
}

/** Convertit une ligne SQL shop_settings en réglages. */
export function shopSettingsFromRow(row: any): ShopSettings {
  if (!row) return DEFAULT_SHOP_SETTINGS;
  return normalizeShopSettings({
    escrowEnabled: row.escrow_enabled, commissionPct: row.commission_pct,
    categoryCommissionPct: row.category_commission_pct, countryCommissionPct: row.country_commission_pct,
    fixedFeeMinor: row.fixed_fee_minor, holdHours: row.hold_hours, postShipHoldHours: row.post_ship_hold_hours,
    newSellerHoldHours: row.new_seller_hold_hours, newSellerOrdersThreshold: row.new_seller_orders_threshold,
    shipDeadlineDays: row.ship_deadline_days, releaseRequiresShipping: row.release_requires_shipping,
    promoMinPct: row.promo_min_pct, promoMaxPct: row.promo_max_pct,
    payoutRequiresVerification: row.payout_requires_verification, minPayoutMinor: row.min_payout_minor
  });
}

/** Pourcentage de commission applicable : catégorie > pays du vendeur > global. */
export function commissionPctFor(s: ShopSettings, category: string, sellerCountry: string): number {
  const cat = s.categoryCommissionPct[String(category || "").toLowerCase()];
  if (cat !== undefined) return cat;
  const ctry = s.countryCommissionPct[String(sellerCountry || "").toUpperCase()];
  if (ctry !== undefined) return ctry;
  return s.commissionPct;
}

/** Pourcentage de promotion réellement appliqué (0 si le vendeur n'a pas activé la promotion). */
export function effectivePromoPct(s: ShopSettings, promoEnabled: boolean, promoPct: number): number {
  if (!promoEnabled) return 0;
  const n = Number(promoPct);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return round2(Math.min(s.promoMaxPct, Math.max(s.promoMinPct, n)));
}

const pctOf = (amount: number, pct: number) => Math.floor((amount * Math.round(pct * 100)) / 10000);

export type Fees = { commission: number; fixed: number; promo: number; net: number };

/** Calcule la répartition d'une vente. Le net vendeur n'est jamais négatif. */
export function computeFees(subtotal: number, commissionPct: number, fixedFee: number, promoPct: number): Fees {
  if (!Number.isInteger(subtotal) || subtotal <= 0) throw new Error("INVALID_SUBTOTAL");
  const commission = pctOf(subtotal, commissionPct);
  const promo = pctOf(subtotal, promoPct);
  const fixed = Math.max(0, Math.min(Math.floor(fixedFee), subtotal - commission - promo));
  const net = subtotal - commission - promo - fixed;
  return { commission, fixed, promo, net };
}

/** Heures de blocage : plus longues pour un nouveau vendeur. */
export function holdHoursFor(s: ShopSettings, sellerCompletedOrders: number): number {
  return sellerCompletedOrders < s.newSellerOrdersThreshold ? Math.max(s.holdHours, s.newSellerHoldHours) : s.holdHours;
}

const H = 3_600_000;
export function computeShipBy(paidAt: Date, s: ShopSettings): Date {
  return new Date(paidAt.getTime() + s.shipDeadlineDays * 24 * H);
}
export function computeReleaseAt(paidAt: Date, holdHours: number): Date {
  return new Date(paidAt.getTime() + holdHours * H);
}

export type OrderLike = {
  status: string; release_at: Date | string; shipped_at: Date | string | null;
  delivered_at?: Date | string | null; ship_by?: Date | string;
};

/** Une commande est libérable quand le blocage est écoulé, qu'aucun litige n'est ouvert et (si réglé) qu'elle est expédiée. */
export function isReleasable(o: OrderLike, now: Date, s: ShopSettings): boolean {
  if (!["paid", "shipped", "delivered"].includes(o.status)) return false;
  const releaseAt = new Date(o.release_at).getTime();
  if (now.getTime() < releaseAt) return false;
  if (s.releaseRequiresShipping) {
    if (!o.shipped_at) return false;
    if (now.getTime() < new Date(o.shipped_at).getTime() + s.postShipHoldHours * H) return false;
  }
  return true;
}

/** Remise à l'acheteur : si l'acheteur confirme la réception, le blocage restant est levé. */
export function isReleasableAfterBuyerConfirmation(o: OrderLike): boolean {
  return ["shipped", "delivered"].includes(o.status) && !!o.shipped_at;
}

export function isUnshippedPastDeadline(o: OrderLike, now: Date): boolean {
  return o.status === "paid" && !o.shipped_at && !!o.ship_by && now.getTime() >= new Date(o.ship_by).getTime();
}

// ---------- Écritures du grand livre (double entrée, somme = 0) ----------
export type LedgerEntry = {
  account: "available" | "escrow" | "platform" | "payout_hold" | "external";
  userId: string | null; currency: string; amount: number; kind: string; orderId?: string | null; refId?: string | null; idemKey: string; note?: string;
};

export function entriesForTopup(p: { userId: string; currency: string; amount: number; reference: string }): LedgerEntry[] {
  return [
    { account: "external", userId: null, currency: p.currency, amount: -p.amount, kind: "topup", refId: null, idemKey: `topup:${p.reference}:ext`, note: "Recharge du solde boutique" },
    { account: "available", userId: p.userId, currency: p.currency, amount: p.amount, kind: "topup", idemKey: `topup:${p.reference}:usr`, note: "Recharge du solde boutique" }
  ];
}
export function entriesForPurchase(o: { id: string; buyerId: string; currency: string; total: number }): LedgerEntry[] {
  return [
    { account: "available", userId: o.buyerId, currency: o.currency, amount: -o.total, kind: "order_payment", orderId: o.id, idemKey: `order:${o.id}:pay:buyer`, note: "Paiement de la commande" },
    { account: "escrow", userId: null, currency: o.currency, amount: o.total, kind: "order_payment", orderId: o.id, idemKey: `order:${o.id}:pay:escrow`, note: "Fonds bloqués en séquestre" }
  ];
}
/** Libère `amount` (le reste du séquestre) : vendeur, commission, part promotion. */
export function entriesForRelease(o: { id: string; sellerId: string; currency: string; escrowAmount: number; fees: Fees }): LedgerEntry[] {
  const { commission, fixed, promo, net } = o.fees;
  if (net + commission + fixed + promo !== o.escrowAmount) throw new Error("RELEASE_AMOUNT_MISMATCH");
  const e: LedgerEntry[] = [{ account: "escrow", userId: null, currency: o.currency, amount: -o.escrowAmount, kind: "order_release", orderId: o.id, idemKey: `order:${o.id}:rel:escrow`, note: "Séquestre libéré" }];
  if (net > 0) e.push({ account: "available", userId: o.sellerId, currency: o.currency, amount: net, kind: "order_release", orderId: o.id, idemKey: `order:${o.id}:rel:seller`, note: "Vente libérée" });
  if (commission + fixed > 0) e.push({ account: "platform", userId: null, currency: o.currency, amount: commission + fixed, kind: "commission", orderId: o.id, idemKey: `order:${o.id}:rel:commission`, note: "Commission de la plateforme" });
  if (promo > 0) e.push({ account: "platform", userId: null, currency: o.currency, amount: promo, kind: "promo_share", orderId: o.id, idemKey: `order:${o.id}:rel:promo`, note: "Part promotion" });
  return e;
}
export function entriesForRefund(o: { id: string; buyerId: string; currency: string; amount: number; step: string }): LedgerEntry[] {
  return [
    { account: "escrow", userId: null, currency: o.currency, amount: -o.amount, kind: "order_refund", orderId: o.id, idemKey: `order:${o.id}:ref:${o.step}:escrow`, note: "Remboursement depuis le séquestre" },
    { account: "available", userId: o.buyerId, currency: o.currency, amount: o.amount, kind: "order_refund", orderId: o.id, idemKey: `order:${o.id}:ref:${o.step}:buyer`, note: "Remboursement de la commande" }
  ];
}
export function entriesForPayoutRequest(p: { id: string; userId: string; currency: string; amount: number }): LedgerEntry[] {
  return [
    { account: "available", userId: p.userId, currency: p.currency, amount: -p.amount, kind: "payout_request", refId: p.id, idemKey: `payout:${p.id}:req:avail`, note: "Retrait demandé" },
    { account: "payout_hold", userId: p.userId, currency: p.currency, amount: p.amount, kind: "payout_request", refId: p.id, idemKey: `payout:${p.id}:req:hold`, note: "Retrait en attente" }
  ];
}
export function entriesForPayoutPaid(p: { id: string; userId: string; currency: string; amount: number }): LedgerEntry[] {
  return [
    { account: "payout_hold", userId: p.userId, currency: p.currency, amount: -p.amount, kind: "payout_paid", refId: p.id, idemKey: `payout:${p.id}:paid:hold`, note: "Retrait versé" },
    { account: "external", userId: null, currency: p.currency, amount: p.amount, kind: "payout_paid", refId: p.id, idemKey: `payout:${p.id}:paid:ext`, note: "Argent versé au vendeur" }
  ];
}
export function entriesForPayoutRejected(p: { id: string; userId: string; currency: string; amount: number }): LedgerEntry[] {
  return [
    { account: "payout_hold", userId: p.userId, currency: p.currency, amount: -p.amount, kind: "payout_rejected", refId: p.id, idemKey: `payout:${p.id}:rej:hold`, note: "Retrait refusé" },
    { account: "available", userId: p.userId, currency: p.currency, amount: p.amount, kind: "payout_rejected", refId: p.id, idemKey: `payout:${p.id}:rej:avail`, note: "Retrait refusé : fonds rendus" }
  ];
}

/** Répartition après remboursement partiel : les frais sont recalculés sur le reste. */
export function feesAfterPartialRefund(o: { subtotal: number; refunded: number; commissionPct: number; fixedFee: number; promoPct: number }): { remainder: number; fees: Fees } {
  const remainder = o.subtotal - o.refunded;
  if (!Number.isInteger(o.refunded) || o.refunded < 0 || remainder < 0) throw new Error("INVALID_REFUND");
  if (remainder === 0) return { remainder: 0, fees: { commission: 0, fixed: 0, promo: 0, net: 0 } };
  return { remainder, fees: computeFees(remainder, o.commissionPct, o.fixedFee, o.promoPct) };
}

export const sumEntries = (entries: LedgerEntry[]) => entries.reduce((a, e) => a + e.amount, 0);

// ---------- Règles d'actions (qui peut faire quoi, à quel statut) ----------
export function canShip(o: { status: string; seller_id: string }, userId: string) { return o.seller_id === userId && o.status === "paid"; }
export function canBuyerCancel(o: { status: string; buyer_id: string; shipped_at: unknown }, userId: string) { return o.buyer_id === userId && o.status === "paid" && !o.shipped_at; }
export function canSellerCancel(o: { status: string; seller_id: string }, userId: string) { return o.seller_id === userId && ["paid", "shipped"].includes(o.status); }
export function canConfirmReceipt(o: { status: string; buyer_id: string }, userId: string) { return o.buyer_id === userId && ["shipped", "delivered"].includes(o.status); }
export function canOpenDispute(o: { status: string; buyer_id: string }, userId: string) { return o.buyer_id === userId && ["paid", "shipped", "delivered"].includes(o.status); }
export function canReview(o: { status: string; buyer_id: string }, userId: string) { return o.buyer_id === userId && o.status === "completed"; }

export const toMinor = (major: number, currency: string): number => {
  const n = Number(major);
  if (!Number.isFinite(n) || n <= 0) throw new Error("INVALID_AMOUNT");
  if (currency === "XOF" && !Number.isInteger(n)) throw new Error("INVALID_AMOUNT");
  return Math.round(n * 100);
};
