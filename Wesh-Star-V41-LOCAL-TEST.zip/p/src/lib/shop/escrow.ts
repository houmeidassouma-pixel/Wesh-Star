import { query, withTransaction } from "@/lib/db/pool";
import {
  type Fees, type LedgerEntry, type ShopSettings, SHOP_CURRENCIES,
  canBuyerCancel, canConfirmReceipt, canOpenDispute, canSellerCancel, canShip, commissionPctFor, computeFees, computeReleaseAt, computeShipBy,
  effectivePromoPct, entriesForPayoutPaid, entriesForPayoutRejected, entriesForPayoutRequest, entriesForPurchase, entriesForRefund,
  entriesForRelease, entriesForTopup, feesAfterPartialRefund, holdHoursFor, isReleasable, isReleasableAfterBuyerConfirmation,
  isUnshippedPastDeadline, shopSettingsFromRow, sumEntries
} from "@/lib/shop/fees";

// Moteur de la place de marché : tout se passe sur le site (séquestre local, commissions, litiges, retraits).
// L'argent réel entre et sort uniquement par les recharges (Flutterwave ou confirmation manuelle admin) et les
// retraits validés par l'admin ; le reste n'est que de la comptabilité interne, protégée par transaction + verrous.

export type Db = { query: (text: string, params?: any[]) => Promise<{ rows: any[]; rowCount: number | null }> };
export class ShopError extends Error {
  status: number;
  constructor(code: string, status = 400) { super(code); this.status = status; }
}

export async function getShopSettings(c: Db = { query }): Promise<ShopSettings> {
  const r = await c.query("select * from public.shop_settings where id = true");
  return shopSettingsFromRow(r.rows[0]);
}

/** Écrit des écritures équilibrées. Retourne false si elles existent déjà (idempotence). */
export async function postEntries(c: Db, entries: LedgerEntry[]): Promise<boolean> {
  if (sumEntries(entries) !== 0) throw new ShopError("LEDGER_UNBALANCED", 500);
  let first = true;
  for (const e of entries) {
    const r = await c.query(
      `insert into public.shop_ledger (account,user_id,currency,amount_minor,kind,order_id,ref_id,idem_key,note)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9) on conflict (idem_key) do nothing`,
      [e.account, e.userId, e.currency, e.amount, e.kind, e.orderId || null, e.refId || null, e.idemKey, e.note || ""]);
    if (first && !r.rowCount) return false;
    first = false;
  }
  return true;
}

export async function availableBalance(c: Db, userId: string, currency: string): Promise<number> {
  const r = await c.query("select coalesce(sum(amount_minor),0)::bigint as t from public.shop_ledger where account='available' and user_id=$1 and currency=$2", [userId, currency]);
  return Number(r.rows[0]?.t || 0);
}
const lockUser = (c: Db, userId: string) => c.query("select id from public.profiles where id=$1 for update", [userId]);

// ---------- Recharges ----------
export async function createTopup(userId: string, currency: string, amountMinor: number, method: "flutterwave" | "manual", reference: string) {
  if (!(SHOP_CURRENCIES as readonly string[]).includes(currency) || !Number.isInteger(amountMinor) || amountMinor <= 0 || amountMinor > 100_000_000_00) throw new ShopError("INVALID_TOPUP");
  const r = await query(
    `insert into public.shop_topups (user_id,currency,amount_minor,method,reference) values ($1,$2,$3,$4,$5) returning id,reference,currency,amount_minor,method,status,created_at`,
    [userId, currency, amountMinor, method, reference]);
  return r.rows[0];
}

/** Crédite le solde boutique une seule fois (retour Flutterwave vérifié ou confirmation manuelle admin). */
export async function confirmTopup(c: Db, reference: string, opts: { providerTx?: string; adminId?: string; expectedUserId?: string; paidMinor?: number; paidCurrency?: string }) {
  const f = await c.query("select * from public.shop_topups where reference=$1 for update", [reference]);
  const t = f.rows[0];
  if (!t) throw new ShopError("TOPUP_NOT_FOUND", 404);
  if (opts.expectedUserId && String(t.user_id) !== opts.expectedUserId) throw new ShopError("USER_MISMATCH", 403);
  if (t.status === "confirmed") return { ok: true, already: true };
  if (t.status !== "pending") throw new ShopError("TOPUP_NOT_PENDING", 409);
  if (opts.paidMinor !== undefined && (Number(opts.paidMinor) !== Number(t.amount_minor) || String(opts.paidCurrency || "").toUpperCase() !== t.currency)) throw new ShopError("AMOUNT_MISMATCH", 409);
  await postEntries(c, entriesForTopup({ userId: t.user_id, currency: t.currency, amount: Number(t.amount_minor), reference }));
  await c.query("update public.shop_topups set status='confirmed', confirmed_at=now(), confirmed_by=$2, provider_tx=coalesce($3,provider_tx) where id=$1", [t.id, opts.adminId || null, opts.providerTx || null]);
  return { ok: true, userId: t.user_id as string, currency: t.currency as string, amountMinor: Number(t.amount_minor) };
}
export async function rejectTopup(c: Db, reference: string, adminId: string) {
  const r = await c.query("update public.shop_topups set status='rejected', confirmed_at=now(), confirmed_by=$2 where reference=$1 and status='pending' returning id", [reference, adminId]);
  if (!r.rowCount) throw new ShopError("TOPUP_NOT_PENDING", 409);
}

// ---------- Achat ----------
export async function purchase(c: Db, p: { buyerId: string; productId: string; quantity: number; shippingCountry: string; message: string; now?: Date }) {
  const settings = await getShopSettings(c);
  if (!settings.escrowEnabled) throw new ShopError("SHOP_PAYMENTS_DISABLED", 503);
  await lockUser(c, p.buyerId);
  const pr = await c.query("select * from public.shop_products where id=$1 and status='active' for update", [p.productId]);
  const prod = pr.rows[0];
  if (!prod) throw new ShopError("PRODUCT_NOT_FOUND", 404);
  if (prod.seller_id === p.buyerId) throw new ShopError("CANNOT_BUY_OWN_PRODUCT");
  if (p.quantity > Number(prod.stock_quantity)) throw new ShopError("INSUFFICIENT_STOCK", 409);
  if (prod.country_code !== p.shippingCountry && !(prod.shipping_countries || []).includes(p.shippingCountry)) throw new ShopError("SELLER_DOES_NOT_SHIP_TO_COUNTRY");
  const unit = Number(prod.price_minor);
  const subtotal = unit * p.quantity;
  const pct = commissionPctFor(settings, prod.category, prod.country_code);
  const promoPct = effectivePromoPct(settings, !!prod.promo_enabled, Number(prod.promo_pct));
  const fixed = settings.fixedFeeMinor[prod.currency] || 0;
  let fees: Fees;
  try { fees = computeFees(subtotal, pct, fixed, promoPct); } catch { throw new ShopError("INVALID_ORDER_FIELDS"); }
  if (fees.net <= 0) throw new ShopError("PRICE_TOO_LOW");
  const balance = await availableBalance(c, p.buyerId, prod.currency);
  if (balance < subtotal) throw Object.assign(new ShopError("INSUFFICIENT_FUNDS", 402), { needed: subtotal - balance });
  const done = await c.query("select count(*)::int as n from public.shop_orders where seller_id=$1 and status='completed'", [prod.seller_id]);
  const hold = holdHoursFor(settings, Number(done.rows[0]?.n || 0));
  const now = p.now || new Date();
  const dec = await c.query(
    "update public.shop_products set stock_quantity=stock_quantity-$2, status=case when stock_quantity-$2=0 then 'paused' else status end, updated_at=now() where id=$1 and stock_quantity >= $2 returning id", [prod.id, p.quantity]);
  if (!dec.rowCount) throw new ShopError("INSUFFICIENT_STOCK", 409);
  const ins = await c.query(
    `insert into public.shop_orders (product_id,buyer_id,seller_id,quantity,unit_price_minor,currency,subtotal_minor,commission_pct,commission_minor,fixed_fee_minor,promo_pct,promo_minor,seller_net_minor,shipping_country,buyer_message,status,paid_at,ship_by,release_at)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,'paid',$16,$17,$18) returning *`,
    [prod.id, p.buyerId, prod.seller_id, p.quantity, unit, prod.currency, subtotal, pct, fees.commission, fees.fixed, promoPct, fees.promo, fees.net, p.shippingCountry, p.message, now, computeShipBy(now, settings), computeReleaseAt(now, hold)]);
  const order = ins.rows[0];
  await postEntries(c, entriesForPurchase({ id: order.id, buyerId: p.buyerId, currency: prod.currency, total: subtotal }));
  return order;
}

const lockOrder = async (c: Db, id: string) => {
  const r = await c.query("select * from public.shop_orders where id=$1 for update", [id]);
  if (!r.rows[0]) throw new ShopError("ORDER_NOT_FOUND", 404);
  return r.rows[0];
};
const restock = (c: Db, o: any) => c.query(
  "update public.shop_products set status=case when status='paused' and stock_quantity=0 then 'active' else status end, stock_quantity=least(100000,stock_quantity+$2), updated_at=now() where id=$1", [o.product_id, o.quantity]);

/** Libère ce qui reste dans le séquestre vers le vendeur, après déduction des frais. Commande déjà verrouillée. */
async function releaseRemaining(c: Db, o: any) {
  const escrowAmount = Number(o.subtotal_minor) - Number(o.refunded_minor);
  let fees: Fees;
  if (Number(o.refunded_minor) === 0) fees = { commission: Number(o.commission_minor), fixed: Number(o.fixed_fee_minor), promo: Number(o.promo_minor), net: Number(o.seller_net_minor) };
  else fees = feesAfterPartialRefund({ subtotal: Number(o.subtotal_minor), refunded: Number(o.refunded_minor), commissionPct: Number(o.commission_pct), fixedFee: Number(o.fixed_fee_minor), promoPct: Number(o.promo_pct) }).fees;
  if (escrowAmount > 0) await postEntries(c, entriesForRelease({ id: o.id, sellerId: o.seller_id, currency: o.currency, escrowAmount, fees }));
  await c.query("update public.shop_orders set status='completed', released_at=now(), updated_at=now() where id=$1", [o.id]);
}

/** Rembourse `amount` depuis le séquestre vers l'acheteur. Commande déjà verrouillée. */
async function refundFromEscrow(c: Db, o: any, amount: number, step: string) {
  const remaining = Number(o.subtotal_minor) - Number(o.refunded_minor);
  if (!Number.isInteger(amount) || amount <= 0 || amount > remaining) throw new ShopError("INVALID_REFUND_AMOUNT");
  await postEntries(c, entriesForRefund({ id: o.id, buyerId: o.buyer_id, currency: o.currency, amount, step }));
  await c.query("update public.shop_orders set refunded_minor=refunded_minor+$2, updated_at=now() where id=$1", [o.id, amount]);
}

export async function releaseOrder(c: Db, orderId: string, mode: "auto" | "buyer", now = new Date()) {
  const o = await lockOrder(c, orderId);
  if (o.status === "completed") return { already: true };
  const settings = await getShopSettings(c);
  if (mode === "auto" ? !isReleasable(o, now, settings) : !isReleasableAfterBuyerConfirmation(o)) throw new ShopError("ORDER_NOT_RELEASABLE", 409);
  if (mode === "buyer") await c.query("update public.shop_orders set delivered_at=coalesce(delivered_at, now()) where id=$1", [o.id]);
  await releaseRemaining(c, o);
  return { released: true };
}

export async function shipOrder(c: Db, orderId: string, userId: string, carrier: string, tracking: string) {
  const o = await lockOrder(c, orderId);
  if (!canShip(o, userId)) throw new ShopError("NOT_ALLOWED", 403);
  await c.query("update public.shop_orders set status='shipped', shipped_at=now(), tracking_carrier=$2, tracking_number=$3, updated_at=now() where id=$1", [o.id, carrier.slice(0, 60), tracking.slice(0, 80)]);
}

export async function confirmReceipt(c: Db, orderId: string, userId: string) {
  const o = await lockOrder(c, orderId);
  if (!canConfirmReceipt(o, userId)) throw new ShopError("NOT_ALLOWED", 403);
  return releaseOrder(c, orderId, "buyer");
}

export async function cancelOrder(c: Db, orderId: string, userId: string) {
  const o = await lockOrder(c, orderId);
  const byBuyer = canBuyerCancel(o, userId), bySeller = canSellerCancel(o, userId);
  if (!byBuyer && !bySeller) throw new ShopError("NOT_ALLOWED", 403);
  const remaining = Number(o.subtotal_minor) - Number(o.refunded_minor);
  if (remaining > 0) await refundFromEscrow(c, o, remaining, "cancel");
  await c.query("update public.shop_orders set status='cancelled', updated_at=now() where id=$1", [o.id]);
  if (!o.shipped_at) await restock(c, o);
}

// ---------- Litiges ----------
export async function openDispute(c: Db, orderId: string, userId: string, reason: string, details: string) {
  const o = await lockOrder(c, orderId);
  if (!canOpenDispute(o, userId)) throw new ShopError("NOT_ALLOWED", 403);
  if (!["not_received", "not_as_described", "damaged", "other"].includes(reason)) throw new ShopError("INVALID_REASON");
  const d = await c.query("insert into public.shop_disputes (order_id,opened_by,reason,details) values ($1,$2,$3,$4) on conflict (order_id) do nothing returning id", [o.id, userId, reason, details.slice(0, 2000)]);
  if (!d.rowCount) throw new ShopError("DISPUTE_ALREADY_EXISTS", 409);
  if (details.trim()) await c.query("insert into public.shop_dispute_messages (dispute_id,author_id,author_role,body) values ($1,$2,'buyer',$3)", [d.rows[0].id, userId, details.slice(0, 2000)]);
  await c.query("update public.shop_orders set status='disputed', updated_at=now() where id=$1", [o.id]);
  return d.rows[0].id as string;
}

export async function addDisputeMessage(c: Db, orderId: string, userId: string, isAdmin: boolean, body: string, imageUrl: string | null) {
  const o = await lockOrder(c, orderId);
  const role = isAdmin ? "admin" : o.buyer_id === userId ? "buyer" : o.seller_id === userId ? "seller" : null;
  if (!role) throw new ShopError("NOT_ALLOWED", 403);
  const d = (await c.query("select * from public.shop_disputes where order_id=$1 for update", [o.id])).rows[0];
  if (!d) throw new ShopError("DISPUTE_NOT_FOUND", 404);
  if (d.status === "resolved") throw new ShopError("DISPUTE_RESOLVED", 409);
  const text = body.trim().slice(0, 2000);
  if (!text) throw new ShopError("EMPTY_MESSAGE");
  await c.query("insert into public.shop_dispute_messages (dispute_id,author_id,author_role,body,image_url) values ($1,$2,$3,$4,$5)", [d.id, userId, role, text, imageUrl]);
  if (role === "seller" && d.status === "open") await c.query("update public.shop_disputes set status='seller_responded' where id=$1", [d.id]);
}

export async function resolveDispute(c: Db, orderId: string, adminId: string, resolution: "refund_buyer" | "pay_seller" | "partial_refund", refundMinor: number, note: string) {
  const o = await lockOrder(c, orderId);
  if (o.status !== "disputed") throw new ShopError("ORDER_NOT_DISPUTED", 409);
  const d = (await c.query("select * from public.shop_disputes where order_id=$1 for update", [o.id])).rows[0];
  if (!d || d.status === "resolved") throw new ShopError("DISPUTE_NOT_OPEN", 409);
  const remaining = Number(o.subtotal_minor) - Number(o.refunded_minor);
  let refunded = 0;
  if (resolution === "refund_buyer") {
    refunded = remaining;
    await refundFromEscrow(c, o, remaining, "dispute");
    await c.query("update public.shop_orders set status='refunded', updated_at=now() where id=$1", [o.id]);
    if (!o.shipped_at) await restock(c, o);
  } else if (resolution === "partial_refund") {
    if (!Number.isInteger(refundMinor) || refundMinor <= 0 || refundMinor >= remaining) throw new ShopError("INVALID_REFUND_AMOUNT");
    refunded = refundMinor;
    await refundFromEscrow(c, o, refundMinor, "dispute");
    const fresh = await lockOrder(c, o.id);
    await releaseRemaining(c, fresh);
  } else if (resolution === "pay_seller") {
    await releaseRemaining(c, o);
  } else throw new ShopError("INVALID_RESOLUTION");
  await c.query("update public.shop_disputes set status='resolved', resolution=$2, refund_minor=$3, resolution_note=$4, resolved_by=$5, resolved_at=now() where id=$1", [d.id, resolution, refunded, note.slice(0, 1000), adminId]);
}

// ---------- Retraits vendeurs ----------
export async function requestPayout(c: Db, p: { userId: string; currency: string; amountMinor: number; method: string; details: string }) {
  if (!(SHOP_CURRENCIES as readonly string[]).includes(p.currency) || !Number.isInteger(p.amountMinor) || p.amountMinor <= 0) throw new ShopError("INVALID_PAYOUT");
  if (!["mobile_money", "bank", "paypal"].includes(p.method) || p.details.trim().length < 3 || p.details.length > 500) throw new ShopError("INVALID_PAYOUT_DETAILS");
  const settings = await getShopSettings(c);
  await lockUser(c, p.userId);
  if (settings.payoutRequiresVerification) {
    const v = await c.query("select shop_seller_verified from public.profiles where id=$1", [p.userId]);
    if (!v.rows[0]?.shop_seller_verified) throw new ShopError("SELLER_NOT_VERIFIED", 403);
  }
  const min = settings.minPayoutMinor[p.currency] || 0;
  if (p.amountMinor < min) throw Object.assign(new ShopError("BELOW_MIN_PAYOUT"), { min });
  if ((await availableBalance(c, p.userId, p.currency)) < p.amountMinor) throw new ShopError("INSUFFICIENT_FUNDS", 402);
  const r = await c.query("insert into public.shop_payouts (user_id,currency,amount_minor,method,details) values ($1,$2,$3,$4,$5) returning *", [p.userId, p.currency, p.amountMinor, p.method, p.details.trim()]);
  await postEntries(c, entriesForPayoutRequest({ id: r.rows[0].id, userId: p.userId, currency: p.currency, amount: p.amountMinor }));
  return r.rows[0];
}
export async function settlePayout(c: Db, payoutId: string, adminId: string, outcome: "paid" | "rejected", note: string) {
  const f = await c.query("select * from public.shop_payouts where id=$1 for update", [payoutId]);
  const p = f.rows[0];
  if (!p) throw new ShopError("PAYOUT_NOT_FOUND", 404);
  if (p.status !== "requested") throw new ShopError("PAYOUT_ALREADY_PROCESSED", 409);
  const args = { id: p.id, userId: p.user_id, currency: p.currency, amount: Number(p.amount_minor) };
  await postEntries(c, outcome === "paid" ? entriesForPayoutPaid(args) : entriesForPayoutRejected(args));
  await c.query("update public.shop_payouts set status=$2, admin_note=$3, processed_at=now(), processed_by=$4 where id=$1", [p.id, outcome, note.slice(0, 500), adminId]);
}

// ---------- Tâche planifiée : libération automatique et remboursement des commandes non expédiées ----------
export async function processDueOrders(now = new Date()) {
  const result = { released: 0, autoRefunded: 0, errors: 0 };
  const due = await query("select id from public.shop_orders where status in ('paid','shipped','delivered') and release_at <= $1 order by release_at limit 200", [now]);
  for (const row of due.rows) {
    try {
      const r: any = await withTransaction((c) => releaseOrder(c, row.id, "auto", now).catch((e) => { if (e instanceof ShopError && e.message === "ORDER_NOT_RELEASABLE") return { skipped: true }; throw e; }));
      if (r.released) result.released++;
    } catch { result.errors++; }
  }
  const late = await query("select id from public.shop_orders where status='paid' and shipped_at is null and ship_by <= $1 limit 200", [now]);
  for (const row of late.rows) {
    try {
      const did = await withTransaction(async (c) => {
        const o = await lockOrder(c, row.id);
        if (!isUnshippedPastDeadline(o, now)) return false;
        const remaining = Number(o.subtotal_minor) - Number(o.refunded_minor);
        if (remaining > 0) await refundFromEscrow(c, o, remaining, "noship");
        await c.query("update public.shop_orders set status='cancelled', updated_at=now() where id=$1", [o.id]);
        await restock(c, o);
        return true;
      });
      if (did) result.autoRefunded++;
    } catch { result.errors++; }
  }
  return result;
}
