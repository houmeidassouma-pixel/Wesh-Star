import { createAdminClient } from "./account/admin";
import { getBillingConfig } from "./billing";

/** Essais vidéo gratuits à vie : le nombre est réglé dans l'admin (0 = tout est payant dès le début). */
export async function consumeFreeTrial(userId: string): Promise<boolean> {
  const { freeTrialVideoUses } = await getBillingConfig();
  const { data } = await createAdminClient().rpc("consume_free_trial_limited", { p_user_id: userId, p_max: freeTrialVideoUses });
  return data === true;
}

export async function refundFreeTrial(userId: string): Promise<void> {
  await createAdminClient().rpc("refund_free_trial", { p_user_id: userId });
}
