import { query } from "@/lib/db/pool";
import { getVapid, sendPush } from "@/lib/webpush";

/** Crée une notification (à utiliser depuis le code serveur ; les cas principaux sont déjà couverts par des triggers SQL). */
export async function notifyUser(userId: string, n: { kind: string; title: string; body?: string; url?: string; dedupeKey?: string }) {
  try {
    await query("select public.notify_user($1,$2,$3,$4,$5,$6)", [userId, n.kind, n.title, n.body || "", n.url || "/", n.dedupeKey || null]);
  } catch { /* une notification ne doit jamais faire échouer l'action principale */ }
}

/** Envoie les notifications en attente par Web Push (file d'attente Postgres, appelée par le cron toutes les minutes). */
export async function processPendingPushes(limit = 100): Promise<{ sent: number; skipped: number; failed: number }> {
  const out = { sent: 0, skipped: 0, failed: 0 };
  const vapid = getVapid();
  // Réserve un lot sans bloquer les autres workers.
  const claimed = await query(
    `update public.notifications set push_status='sending' where id in (
       select id from public.notifications where push_status in ('pending') and created_at > now() - interval '2 days' order by created_at limit $1 for update skip locked)
     returning id,user_id,title,body,url,push_attempts`, [limit]);
  for (const n of claimed.rows) {
    if (!vapid) { await query("update public.notifications set push_status='skipped' where id=$1", [n.id]); out.skipped++; continue; }
    const subs = await query("select id,endpoint,p256dh,auth from public.push_subscriptions where user_id=$1", [n.user_id]);
    if (!subs.rows.length) { await query("update public.notifications set push_status='skipped' where id=$1", [n.id]); out.skipped++; continue; }
    let anyOk = false;
    for (const s of subs.rows) {
      const r = await sendPush({ endpoint: s.endpoint, p256dh: s.p256dh, auth: s.auth }, { title: n.title, body: n.body, url: n.url }, vapid);
      if (r.ok) { anyOk = true; await query("update public.push_subscriptions set last_success_at=now() where id=$1", [s.id]); }
      else if (r.gone) await query("delete from public.push_subscriptions where id=$1", [s.id]);
    }
    if (anyOk) { await query("update public.notifications set push_status='sent' where id=$1", [n.id]); out.sent++; }
    else if (n.push_attempts + 1 >= 3) { await query("update public.notifications set push_status='failed', push_attempts=push_attempts+1 where id=$1", [n.id]); out.failed++; }
    else { await query("update public.notifications set push_status='pending', push_attempts=push_attempts+1 where id=$1", [n.id]); out.failed++; }
  }
  // Un lot resté « en cours » plus de 10 minutes (worker interrompu) repart dans la file.
  await query("update public.notifications set push_status='pending' where push_status='sending' and created_at < now() - interval '10 minutes'");
  return out;
}
