// Calculs purs du module de coûts / rentabilité (testables sans base de données).
export type CostSettings = {
  electricityEurPerKwh: number; gpuWatts: number; systemWatts: number; gpuSecondsPerVideoSecond: number; gpuSecondsPerImage: number;
  overheadPct: number; hardwareCostEur: number; hardwareLifetimeMonths: number; fixedMonthlyEur: number; manualMonthlyRevenueEur: number; targetMarginPct: number;
};
export const DEFAULT_COST_SETTINGS: CostSettings = {
  electricityEurPerKwh: 0.25, gpuWatts: 350, systemWatts: 120, gpuSecondsPerVideoSecond: 90, gpuSecondsPerImage: 8, overheadPct: 15,
  hardwareCostEur: 2500, hardwareLifetimeMonths: 36, fixedMonthlyEur: 40, manualMonthlyRevenueEur: 0, targetMarginPct: 40
};
const num = (v: unknown, min: number, max: number, d: number) => { const n = Number(v); return Number.isFinite(n) && n >= min && n <= max ? n : d; };

export function normalizeCostSettings(raw: any): CostSettings {
  const d = DEFAULT_COST_SETTINGS, g = (a: string, b: string) => raw?.[a] ?? raw?.[b];
  return {
    electricityEurPerKwh: num(g("electricity_eur_per_kwh", "electricityEurPerKwh"), 0, 10, d.electricityEurPerKwh),
    gpuWatts: num(g("gpu_watts", "gpuWatts"), 0, 5000, d.gpuWatts),
    systemWatts: num(g("system_watts", "systemWatts"), 0, 5000, d.systemWatts),
    gpuSecondsPerVideoSecond: num(g("gpu_seconds_per_video_second", "gpuSecondsPerVideoSecond"), 0, 100000, d.gpuSecondsPerVideoSecond),
    gpuSecondsPerImage: num(g("gpu_seconds_per_image", "gpuSecondsPerImage"), 0, 100000, d.gpuSecondsPerImage),
    overheadPct: num(g("overhead_pct", "overheadPct"), 0, 500, d.overheadPct),
    hardwareCostEur: num(g("hardware_cost_eur", "hardwareCostEur"), 0, 10_000_000, d.hardwareCostEur),
    hardwareLifetimeMonths: Math.round(num(g("hardware_lifetime_months", "hardwareLifetimeMonths"), 1, 240, d.hardwareLifetimeMonths)),
    fixedMonthlyEur: num(g("fixed_monthly_eur", "fixedMonthlyEur"), 0, 10_000_000, d.fixedMonthlyEur),
    manualMonthlyRevenueEur: num(g("manual_monthly_revenue_eur", "manualMonthlyRevenueEur"), 0, 100_000_000, d.manualMonthlyRevenueEur),
    targetMarginPct: num(g("target_margin_pct", "targetMarginPct"), 0, 95, d.targetMarginPct)
  };
}

/** Énergie consommée (kWh) pour un temps GPU donné : (GPU + machine) × temps × (1 + surcoût CPU/LLM/TTS). */
export function kwhFor(gpuSeconds: number, s: CostSettings): number {
  return (gpuSeconds / 3600) * ((s.gpuWatts + s.systemWatts) / 1000) * (1 + s.overheadPct / 100);
}

export type Report = {
  days: number; videoSeconds: number; imageCount: number; energyEur: number; hardwareEur: number; fixedEur: number; totalCostEur: number;
  revenueEur: number; netEur: number; marginPct: number | null; costPerVideoMinuteEur: number | null; costPerImageEur: number | null;
  revenuePerVideoMinuteEur: number | null; breakEvenVideoMinutesPerMonth: number | null;
};

export function computeReport(a: { settings: CostSettings; days: number; videoSeconds: number; videoEnergyEur: number; imageCount: number; revenueEur: number }): Report {
  const s = a.settings, scale = a.days / 30;
  const imageEnergy = a.imageCount * kwhFor(s.gpuSecondsPerImage, s) * s.electricityEurPerKwh;
  const energyEur = a.videoEnergyEur + imageEnergy;
  const hardwareEur = (s.hardwareCostEur / s.hardwareLifetimeMonths) * scale;
  const fixedEur = s.fixedMonthlyEur * scale;
  const totalCostEur = energyEur + hardwareEur + fixedEur;
  const netEur = a.revenueEur - totalCostEur;
  const marginPct = a.revenueEur > 0 ? (netEur / a.revenueEur) * 100 : null;
  // Charges fixes et amortissement répartis au prorata du temps GPU utilisé.
  const gpuVideo = a.videoSeconds * s.gpuSecondsPerVideoSecond, gpuImg = a.imageCount * s.gpuSecondsPerImage, gpuTotal = gpuVideo + gpuImg;
  const shared = hardwareEur + fixedEur;
  const videoMin = a.videoSeconds / 60;
  const costPerVideoMinuteEur = videoMin > 0 ? (a.videoEnergyEur + (gpuTotal > 0 ? shared * (gpuVideo / gpuTotal) : 0)) / videoMin : null;
  const costPerImageEur = a.imageCount > 0 ? (imageEnergy + (gpuTotal > 0 ? shared * (gpuImg / gpuTotal) : 0)) / a.imageCount : null;
  const revenuePerVideoMinuteEur = videoMin > 0 && a.revenueEur > 0 ? a.revenueEur / videoMin : null;
  // Seuil de rentabilité : minutes vidéo par mois pour couvrir les charges fixes + l'amortissement.
  const variablePerMin = videoMin > 0 ? a.videoEnergyEur / videoMin : 0;
  const contribution = revenuePerVideoMinuteEur !== null ? revenuePerVideoMinuteEur - variablePerMin : 0;
  const breakEvenVideoMinutesPerMonth = contribution > 0 ? (s.fixedMonthlyEur + s.hardwareCostEur / s.hardwareLifetimeMonths) / contribution : null;
  return { days: a.days, videoSeconds: a.videoSeconds, imageCount: a.imageCount, energyEur, hardwareEur, fixedEur, totalCostEur, revenueEur: a.revenueEur, netEur, marginPct, costPerVideoMinuteEur, costPerImageEur, revenuePerVideoMinuteEur, breakEvenVideoMinutesPerMonth };
}

export type RecommendationDraft = { kind: "scale_tier_prices" | "set_image_cost_seconds" | "no_revenue"; title: string; details: string; action: Record<string, unknown> };
const eur = (n: number) => n.toFixed(2).replace(".", ",") + " €";

/** Propositions stratégiques automatiques. Rien n'est appliqué sans que l'administrateur clique sur « Valider ». */
export function buildRecommendations(r: Report, s: CostSettings, imageCostSeconds: number): RecommendationDraft[] {
  const out: RecommendationDraft[] = [];
  if (r.revenueEur <= 0 && r.totalCostEur > 0) {
    out.push({ kind: "no_revenue", title: "Aucun revenu sur la période", details: `Les coûts estimés sont de ${eur(r.totalCostEur)} (électricité ${eur(r.energyEur)}, amortissement ${eur(r.hardwareEur)}, charges fixes ${eur(r.fixedEur)}) sans revenu enregistré. Vérifie que les paiements sont bien confirmés, ou renseigne le revenu mensuel manuel (abonnements).`, action: {} });
    return out;
  }
  if (r.marginPct !== null && r.marginPct < s.targetMarginPct && r.revenueEur > 0) {
    const needed = r.totalCostEur / (1 - s.targetMarginPct / 100);
    const rawPct = Math.max(1, Math.ceil((needed / r.revenueEur - 1) * 100));
    const pct = Math.min(100, rawPct);
    const newRevenue = r.revenueEur * (1 + pct / 100);
    const projected = ((newRevenue - r.totalCostEur) / newRevenue) * 100;
    const base = `Marge nette actuelle : ${r.marginPct.toFixed(1)} % (objectif ${s.targetMarginPct} %). Revenu ${eur(r.revenueEur)} pour ${eur(r.totalCostEur)} de coûts sur ${r.days} jours.`;
    const details = rawPct <= 100
      ? `${base} Augmenter les abonnements d'environ ${pct} % (arrondi au 0,50 € supérieur) ramène la marge nette à l'objectif, après paiement de l'électricité, de l'amortissement du matériel et des charges fixes.`
      : `${base} Atteindre l'objectif demanderait +${rawPct} %, ce qui est trop pour une seule hausse. Une hausse de ${pct} % (plafond) porterait la marge à ${projected.toFixed(1)} % : il faut aussi plus de ventes ou moins de charges (matériel, charges fixes).`;
    out.push({ kind: "scale_tier_prices", title: `Augmenter les tarifs d'environ ${pct} %`, details, action: { type: "scale_tier_prices", pct } });
  }
  if (r.costPerImageEur !== null && r.revenuePerVideoMinuteEur !== null) {
    const revPerSec = r.revenuePerVideoMinuteEur / 60;
    const minSeconds = Math.ceil(r.costPerImageEur / ((1 - s.targetMarginPct / 100) * revPerSec));
    if (minSeconds > imageCostSeconds) out.push({ kind: "set_image_cost_seconds", title: `Passer le coût d'une image à ${minSeconds} s de crédit`, details: `Une image coûte environ ${eur(r.costPerImageEur)} à produire. Au coût actuel (${imageCostSeconds} s de crédit), elle ne garantit pas ${s.targetMarginPct} % de marge. Passer à ${minSeconds} s la rend rentable.`, action: { type: "set_image_cost_seconds", seconds: minSeconds } });
  }
  return out;
}

/** Applique un pourcentage à un prix mensuel, arrondi au 0,50 € supérieur. */
export function scalePrice(price: number, pct: number): number {
  if (!(price > 0)) return price;
  return Math.ceil((price * (1 + pct / 100)) * 2) / 2;
}
