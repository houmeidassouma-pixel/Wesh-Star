import { createCipheriv, createECDH, createPrivateKey, hkdfSync, randomBytes, sign } from "node:crypto";

// Web Push natif (RFC 8030 + VAPID RFC 8292 + chiffrement aes128gcm RFC 8291), sans dépendance externe.
const b64u = (b: Uint8Array | Buffer | string) => Buffer.from(b as any).toString("base64url");
const fromB64u = (s: string) => Buffer.from(s, "base64url");
const pad32 = (b: Buffer) => (b.length >= 32 ? b : Buffer.concat([Buffer.alloc(32 - b.length), b]));

export type PushSubscriptionData = { endpoint: string; p256dh: string; auth: string };
export type VapidConfig = { publicKey: string; privateKey: string; subject: string };

export function generateVapidKeys() {
  const e = createECDH("prime256v1"); e.generateKeys();
  return { publicKey: b64u(e.getPublicKey()), privateKey: b64u(pad32(e.getPrivateKey())) };
}

export function getVapid(): VapidConfig | null {
  const publicKey = process.env.VAPID_PUBLIC_KEY || "", privateKey = process.env.VAPID_PRIVATE_KEY || "";
  if (!publicKey || !privateKey) return null;
  return { publicKey, privateKey, subject: process.env.VAPID_SUBJECT || "mailto:admin@example.com" };
}

export function vapidAuthorization(endpoint: string, v: VapidConfig, nowSeconds = Math.floor(Date.now() / 1000)) {
  const pub = fromB64u(v.publicKey);
  const header = b64u(JSON.stringify({ typ: "JWT", alg: "ES256" }));
  const payload = b64u(JSON.stringify({ aud: new URL(endpoint).origin, exp: nowSeconds + 12 * 3600, sub: v.subject }));
  const input = `${header}.${payload}`;
  const key = createPrivateKey({ key: { kty: "EC", crv: "P-256", d: v.privateKey, x: b64u(pub.subarray(1, 33)), y: b64u(pub.subarray(33, 65)) } as any, format: "jwk" });
  const sig = sign("sha256", Buffer.from(input), { key, dsaEncoding: "ieee-p1363" });
  return `vapid t=${input}.${b64u(sig)}, k=${v.publicKey}`;
}

function deriveKeys(secret: Buffer, authSecret: Buffer, uaPublic: Buffer, asPublic: Buffer, salt: Buffer) {
  const ikm = Buffer.from(hkdfSync("sha256", secret, authSecret, Buffer.concat([Buffer.from("WebPush: info\0"), uaPublic, asPublic]), 32));
  const cek = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: aes128gcm\0"), 16));
  const nonce = Buffer.from(hkdfSync("sha256", ikm, salt, Buffer.from("Content-Encoding: nonce\0"), 12));
  return { cek, nonce };
}

/** Chiffre le message pour un navigateur (clés p256dh / auth de l'abonnement). */
export function encryptPayload(payload: Buffer, p256dh: string, auth: string): Buffer {
  const uaPublic = fromB64u(p256dh), authSecret = fromB64u(auth);
  const as = createECDH("prime256v1"); as.generateKeys();
  const asPublic = as.getPublicKey();
  const salt = randomBytes(16);
  const { cek, nonce } = deriveKeys(as.computeSecret(uaPublic), authSecret, uaPublic, asPublic, salt);
  const cipher = createCipheriv("aes-128-gcm", cek, nonce);
  const ct = Buffer.concat([cipher.update(Buffer.concat([payload, Buffer.from([2])])), cipher.final(), cipher.getAuthTag()]);
  return Buffer.concat([salt, Buffer.from([0, 0, 0x10, 0]), Buffer.from([asPublic.length]), asPublic, ct]);
}

export type PushResult = { ok: boolean; gone: boolean; status: number };

export async function sendPush(sub: PushSubscriptionData, message: { title: string; body: string; url: string }, v: VapidConfig): Promise<PushResult> {
  try {
    const body = encryptPayload(Buffer.from(JSON.stringify(message)), sub.p256dh, sub.auth);
    const r = await fetch(sub.endpoint, {
      method: "POST",
      headers: { "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream", TTL: "86400", Urgency: "normal", Authorization: vapidAuthorization(sub.endpoint, v) },
      body: new Uint8Array(body)
    });
    return { ok: r.status >= 200 && r.status < 300, gone: r.status === 404 || r.status === 410, status: r.status };
  } catch { return { ok: false, gone: false, status: 0 }; }
}
