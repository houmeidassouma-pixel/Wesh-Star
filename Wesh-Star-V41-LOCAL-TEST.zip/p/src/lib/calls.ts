import { query } from "@/lib/db/pool";

export type CallsSettings = { callsEnabled: boolean; callsAccess: "all" | "subscribers" | "verified" };

/** Les appels sont actifs si COMMUNICATIONS_ENABLED=true (interrupteur serveur) ET si l'admin ne les a pas coupés. */
export async function getCallsSettings(): Promise<CallsSettings> {
  try {
    const r = await query("select calls_enabled, calls_access from public.communication_settings where id=true");
    const row = r.rows[0];
    return { callsEnabled: row ? !!row.calls_enabled : true, callsAccess: (["all", "subscribers", "verified"].includes(row?.calls_access) ? row.calls_access : "all") };
  } catch { return { callsEnabled: true, callsAccess: "all" }; }
}

export function callsServerEnabled() { return process.env.COMMUNICATIONS_ENABLED === "true"; }

/** Vrai si l'un des deux a bloqué l'autre. */
export async function isBlockedPair(a: string, b: string): Promise<boolean> {
  const r = await query("select 1 from public.user_blocks where (blocker_id=$1 and blocked_id=$2) or (blocker_id=$2 and blocked_id=$1) limit 1", [a, b]);
  return !!r.rows[0];
}

export function mayUseCalls(s: CallsSettings, a: { isStaff: boolean; planKey: string; profile: any }): boolean {
  if (a.isStaff) return true;
  if (s.callsAccess === "all") return true;
  if (s.callsAccess === "subscribers") return a.planKey !== "free";
  return !!(a.profile?.verified || a.profile?.is_verified || a.profile?.verified_badge);
}
