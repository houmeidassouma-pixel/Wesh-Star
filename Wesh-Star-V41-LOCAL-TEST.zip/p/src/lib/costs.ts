import { query } from "@/lib/db/pool";
import { getBillingConfig } from "@/lib/billing";
import { notifyUser } from "@/lib/notify";
import { buildRecommendations, computeReport, normalizeCostSettings, scalePrice, type CostSettings, type Report } from "@/lib/costs-core";

export async function getCostSettings(): Promise<CostSettings> {
  try { return normalizeCostSettings((await query("select * from public.cost_settings where id = true")).rows[0]); } catch { return normalizeCostSettings({}); }
}

/** Revenus réels confirmés sur la période : paiements confirmés (EUR) + packs de pièces payés, plus le revenu mensuel saisi à la main (abonnements Stripe). */
export async function loadReport(days = 30): Promise<{ report: Report; settings: CostSettings }> {
  const settings = await getCostSettings();
  const d = Math.min(365, Math.max(1, Math.round(days)));
  const [v, img, pay, coins] = await Promise.all([
    query("select coalesce(sum(video_seconds),0) as secs, coalesce(sum(energy_eur),0) as eur from public.job_costs where kind='video' and created_at > now() - make_interval(days => $1)", [d]),
    query("select count(*)::int as n from public.image_charges where refunded=false and created_at > now() - make_interval(days => $1)", [d]),
    query("select coalesce(sum(amount),0) as s from public.payment_requests where status='confirmed' and currency='EUR' and coalesce(reviewed_at, created_at) > now() - make_interval(days => $1)", [d]),
    query("select coalesce(sum(price_eur),0) as s from public.coin_purchases where status='paid' and currency='EUR' and coalesce(paid_at, created_at) > now() - make_interval(days => $1)", [d])
  ]);
  const revenueEur = Number(pay.rows[0].s) + Number(coins.rows[0].s) + settings.manualMonthlyRevenueEur * (d / 30);
  const report = computeReport({ settings, days: d, videoSeconds: Number(v.rows[0].secs), videoEnergyEur: Number(v.rows[0].eur), imageCount: img.rows[0].n, revenueEur });
  return { report, settings };
}

/** Génère les propositions et les enregistre (une seule proposition en attente par type). Appelée par le cron et à l'ouverture du tableau de bord. */
export async function refreshRecommendations(): Promise<number> {
  const { report, settings } = await loadReport(30);
  const { imageCostSeconds } = await getBillingConfig();
  let created = 0;
  for (const rec of buildRecommendations(report, settings, imageCostSeconds)) {
    const exists = await query("select 1 from public.cost_recommendations where kind=$1 and status='pending' limit 1", [rec.kind]);
    if (exists.rows[0]) continue;
    const saved = await query("insert into public.cost_recommendations (kind,title,details,action) values ($1,$2,$3,$4::jsonb) returning id", [rec.kind, rec.title, rec.details, JSON.stringify(rec.action)]);
    created++;
    // Notifie les administrateurs quand une nouvelle recommandation financière arrive ; les décisions restent manuelles.
    const admins = await query("select id from public.profiles where role='admin' limit 20");
    for (const admin of admins.rows) {
      await notifyUser(String(admin.id), { kind: "financial_advice", title: "Conseiller financier : nouvelle proposition", body: rec.title, url: "/admin#cost-advisor", dedupeKey: `cost-rec:${saved.rows[0]?.id}:${admin.id}` });
    }
  }
  return created;
}

/** Applique une proposition validée par l'administrateur. */
export async function applyRecommendation(id: string, adminId: string): Promise<{ applied: string }> {
  const r = await query("select id,kind,action,status from public.cost_recommendations where id=$1 for update", [id]);
  const rec = r.rows[0];
  if (!rec || rec.status !== "pending") throw new Error("RECOMMENDATION_NOT_PENDING");
  let applied = "Proposition prise en compte.";
  if (rec.action?.type === "scale_tier_prices") {
    const pct = Number(rec.action.pct);
    if (!(pct > 0 && pct <= 100)) throw new Error("INVALID_ACTION");
    const { getSettings, saveSettings } = await import("@/lib/settings");
    const settings = await getSettings();
    const tiers = (settings.plans.monthlyTiers || []).map((t: any) => ({ ...t, price: scalePrice(Number(t.price), pct) }));
    await saveSettings({ ...settings, plans: { ...settings.plans, monthlyTiers: tiers } });
    applied = `Prix des abonnements augmentés d'environ ${pct} %.`;
  } else if (rec.action?.type === "set_image_cost_seconds") {
    const seconds = Math.round(Number(rec.action.seconds));
    if (!(seconds >= 1 && seconds <= 3600)) throw new Error("INVALID_ACTION");
    await query("update public.billing_config set image_cost_seconds=$1, updated_at=now(), updated_by=$2 where id=true", [seconds, adminId]);
    applied = `Coût d'une image réglé à ${seconds} s de crédit.`;
  }
  await query("update public.cost_recommendations set status='applied', decided_at=now(), decided_by=$2 where id=$1", [id, adminId]);
  return { applied };
}
