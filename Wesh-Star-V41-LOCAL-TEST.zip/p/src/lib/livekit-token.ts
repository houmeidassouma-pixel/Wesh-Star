import { createHmac } from "node:crypto";

const b64url = (value: string) => Buffer.from(value).toString("base64url");

/** Jeton LiveKit (JWT HS256) pour une salle ; utilisé par les lives et les appels privés. */
export function makeLiveKitToken(apiKey: string, secret: string, userId: string, name: string, room: string, canPublish: boolean, ttlSeconds = 3600) {
  const now = Math.floor(Date.now() / 1000);
  const header = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const payload = b64url(JSON.stringify({
    iss: apiKey, sub: userId, name: name.slice(0, 80), nbf: now - 5, iat: now, exp: now + ttlSeconds,
    video: { room, roomJoin: true, canPublish, canSubscribe: true, canPublishData: canPublish }
  }));
  const input = `${header}.${payload}`;
  return `${input}.${createHmac("sha256", secret).update(input).digest("base64url")}`;
}
