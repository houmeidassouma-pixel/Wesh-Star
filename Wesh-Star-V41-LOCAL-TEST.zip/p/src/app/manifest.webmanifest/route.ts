import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

// Manifeste PWA dynamique : nom de l'appli, couleurs et description sont réglés par l'admin (Réglages → Application).
export async function GET() {
  const { site } = await getSettings();
  const name = site.appName || site.name || "Wesh Star";
  const short = (site.appShortName || site.name || "Wesh Star").slice(0, 12);
  const body = {
    name, short_name: short, description: site.appDescription || site.tagline || "",
    id: "/", start_url: "/", scope: "/", display: "standalone", orientation: "portrait-primary",
    background_color: site.appBackgroundColor, theme_color: site.appThemeColor,
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any maskable" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any maskable" }
    ]
  };
  return new Response(JSON.stringify(body), { headers: { "Content-Type": "application/manifest+json", "Cache-Control": "public, max-age=300" } });
}
