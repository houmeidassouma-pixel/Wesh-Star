import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query, withTransaction } from "@/lib/db/pool";
import { rateLimit, clientKey } from "@/lib/ratelimit";
import { auditLog } from "@/lib/audit";
import { addDisputeMessage, confirmTopup, getShopSettings, rejectTopup, resolveDispute, settlePayout, ShopError } from "@/lib/shop/escrow";
import { normalizeShopSettings } from "@/lib/shop/fees";
import { getBillingConfig, normalizeBilling } from "@/lib/billing";

const uuid = /^[0-9a-f-]{36}$/i;
const staff = (a: Awaited<ReturnType<typeof getAccess>>) => a.role === "admin" || (a.isModerator && !!a.user);

// Tableau de bord admin de la boutique : réglages, commissions encaissées, litiges, retraits, recharges, vendeurs.
export async function GET() {
  const access = await getAccess();
  if (!staff(access)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const [settings, billing, platform, escrow, disputes, payouts, topups, orders, reports] = await Promise.all([
    getShopSettings(), getBillingConfig(),
    query("select currency, coalesce(sum(amount_minor),0)::bigint as total from public.shop_ledger where account='platform' group by currency"),
    query("select currency, coalesce(sum(amount_minor),0)::bigint as total from public.shop_ledger where account='escrow' group by currency"),
    query(`select d.id,d.order_id,d.reason,d.details,d.status,d.created_at,o.subtotal_minor,o.refunded_minor,o.currency,p.title,
                  coalesce(b.username,b.email) as buyer,coalesce(s.username,s.email) as seller
             from public.shop_disputes d join public.shop_orders o on o.id=d.order_id join public.shop_products p on p.id=o.product_id
             left join public.profiles b on b.id=o.buyer_id left join public.profiles s on s.id=o.seller_id
            where d.status <> 'resolved' order by d.created_at limit 100`),
    query(`select x.id,x.user_id,x.currency,x.amount_minor,x.method,x.details,x.created_at,coalesce(u.username,u.email) as user_label,u.shop_seller_verified as verified
             from public.shop_payouts x left join public.profiles u on u.id=x.user_id where x.status='requested' order by x.created_at limit 100`),
    query("select t.reference,t.user_id,t.currency,t.amount_minor,t.created_at,coalesce(u.username,u.email) as user_label from public.shop_topups t left join public.profiles u on u.id=t.user_id where t.status='pending' and t.method='manual' order by t.created_at limit 100"),
    query("select o.id,o.status,o.currency,o.subtotal_minor,o.commission_minor,o.fixed_fee_minor,o.promo_minor,o.seller_net_minor,o.refunded_minor,o.paid_at,o.release_at,p.title from public.shop_orders o join public.shop_products p on p.id=o.product_id order by o.created_at desc limit 50"),
    query("select r.id,r.product_id,r.reason,r.created_at,p.title from public.shop_reports r join public.shop_products p on p.id=r.product_id where r.status='open' order by r.created_at limit 50")
  ]);
  return NextResponse.json({
    settings, billing,
    platformEarnings: platform.rows.map((r) => ({ currency: r.currency, total: Number(r.total) })),
    escrowHeld: escrow.rows.map((r) => ({ currency: r.currency, total: Number(r.total) })),
    // Coordonnées de retrait et recharges : visibles par l'admin uniquement.
    disputes: disputes.rows, payouts: access.role === "admin" ? payouts.rows : [], topups: access.role === "admin" ? topups.rows : [], orders: orders.rows, reports: reports.rows
  });
}

export async function POST(req: Request) {
  const access = await getAccess();
  if (!staff(access)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  if (!rateLimit("admin-shop:" + clientKey(req, access.user!.id), 40, 60_000)) return NextResponse.json({ error: "RATE_LIMIT" }, { status: 429 });
  const body = await req.json().catch(() => ({}));
  const adminId = access.user!.id;
  const isAdmin = access.role === "admin";
  const action = String(body.action || "");
  // Réglages d'argent : réservés à l'admin ; la modération (litiges, signalements) est ouverte aux modérateurs.
  const adminOnly = ["save_settings", "save_billing", "settle_payout", "confirm_topup", "reject_topup", "verify_seller"];
  if (adminOnly.includes(action) && !isAdmin) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  try {
    if (action === "save_settings") {
      const s = normalizeShopSettings(body.settings);
      await query(
        `update public.shop_settings set escrow_enabled=$1,commission_pct=$2,category_commission_pct=$3,country_commission_pct=$4,fixed_fee_minor=$5,hold_hours=$6,post_ship_hold_hours=$7,
           new_seller_hold_hours=$8,new_seller_orders_threshold=$9,ship_deadline_days=$10,release_requires_shipping=$11,promo_min_pct=$12,promo_max_pct=$13,payout_requires_verification=$14,min_payout_minor=$15,
           updated_at=now(),updated_by=$16 where id=true`,
        [s.escrowEnabled, s.commissionPct, JSON.stringify(s.categoryCommissionPct), JSON.stringify(s.countryCommissionPct), JSON.stringify(s.fixedFeeMinor), s.holdHours, s.postShipHoldHours,
         s.newSellerHoldHours, s.newSellerOrdersThreshold, s.shipDeadlineDays, s.releaseRequiresShipping, s.promoMinPct, s.promoMaxPct, s.payoutRequiresVerification, JSON.stringify(s.minPayoutMinor), adminId]);
      await auditLog({ actorId: adminId, actorRole: access.role, action: "shop.settings_saved", details: { commissionPct: s.commissionPct, holdHours: s.holdHours } });
      return NextResponse.json({ ok: true, settings: s });
    }
    if (action === "save_billing") {
      const b = normalizeBilling(body.billing);
      await query("update public.billing_config set free_trial_video_uses=$1,free_trial_image_uses=$2,image_cost_seconds=$3,low_balance_seconds=$5,updated_at=now(),updated_by=$4 where id=true", [b.freeTrialVideoUses, b.freeTrialImageUses, b.imageCostSeconds, adminId, b.lowBalanceSeconds]);
      await auditLog({ actorId: adminId, actorRole: access.role, action: "billing.config_saved", details: b });
      return NextResponse.json({ ok: true, billing: b });
    }
    if (action === "resolve_dispute") {
      const orderId = String(body.orderId || ""), resolution = String(body.resolution || "");
      if (!uuid.test(orderId) || !["refund_buyer", "pay_seller", "partial_refund"].includes(resolution)) return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
      const note = String(body.note || "").trim();
      const refundMinor = Math.round(Number(body.refundAmount || 0) * 100);
      await withTransaction(async (c) => {
        if (note) await addDisputeMessage(c, orderId, adminId, true, note, null);
        await resolveDispute(c, orderId, adminId, resolution as any, refundMinor, note);
      });
      await auditLog({ actorId: adminId, actorRole: access.role, action: "shop.dispute_resolved", targetType: "shop_order", targetId: orderId, details: { resolution } });
      return NextResponse.json({ ok: true });
    }
    if (action === "dispute_message") {
      const orderId = String(body.orderId || ""), text = String(body.body || "").trim();
      if (!uuid.test(orderId) || !text) return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
      await withTransaction((c) => addDisputeMessage(c, orderId, adminId, true, text, null));
      return NextResponse.json({ ok: true });
    }
    if (action === "settle_payout") {
      const id = String(body.payoutId || ""), outcome = String(body.outcome || "");
      if (!uuid.test(id) || !["paid", "rejected"].includes(outcome)) return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
      await withTransaction((c) => settlePayout(c, id, adminId, outcome as any, String(body.note || "")));
      await auditLog({ actorId: adminId, actorRole: access.role, action: "shop.payout_" + outcome, targetType: "shop_payout", targetId: id });
      return NextResponse.json({ ok: true });
    }
    if (action === "confirm_topup" || action === "reject_topup") {
      const ref = String(body.reference || "");
      if (!/^WS-SHM-[A-Z0-9-]{4,40}$/.test(ref)) return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
      if (action === "confirm_topup") await withTransaction((c) => confirmTopup(c, ref, { adminId }));
      else await withTransaction((c) => rejectTopup(c, ref, adminId));
      await auditLog({ actorId: adminId, actorRole: access.role, action: "shop." + action, targetType: "shop_topup", targetId: ref });
      return NextResponse.json({ ok: true });
    }
    if (action === "verify_seller") {
      const userId = String(body.userId || "");
      if (!uuid.test(userId)) return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
      await query("update public.profiles set shop_seller_verified=$2 where id=$1", [userId, body.verified !== false]);
      await auditLog({ actorId: adminId, actorRole: access.role, action: "shop.seller_verified", targetType: "profile", targetId: userId, details: { verified: body.verified !== false } });
      return NextResponse.json({ ok: true });
    }
    if (action === "report_status") {
      const id = String(body.reportId || ""), status = String(body.status || "");
      if (!uuid.test(id) || !["dismissed", "actioned"].includes(status)) return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
      await query("update public.shop_reports set status=$2 where id=$1", [id, status]);
      if (status === "actioned" && body.pauseProduct === true) await query("update public.shop_products set status='paused' where id=(select product_id from public.shop_reports where id=$1)", [id]);
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
  } catch (e: any) {
    const status = e instanceof ShopError ? e.status : 500;
    return NextResponse.json({ error: status === 500 ? "ADMIN_SHOP_FAILED" : e.message }, { status });
  }
}
