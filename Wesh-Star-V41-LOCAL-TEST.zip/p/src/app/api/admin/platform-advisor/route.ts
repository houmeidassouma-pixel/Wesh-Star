import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query } from "@/lib/db/pool";
import { auditLog } from "@/lib/audit";
import { buildPlatformRecommendations, type AdvisorMetrics } from "@/lib/platform-advisor";

// Admin-only advisor. Metrics are explicitly submitted by an admin until each
// module has a verified automatic aggregation; the API never invents live data.
export async function GET() {
  const access = await getAccess();
  if (access.role !== "admin") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  try {
    const [snapshot, recs] = await Promise.all([
      query("select metrics, updated_at, updated_by from public.platform_advisor_snapshot where id=true"),
      query("select id, priority, area, title, reason, proposed_action, impact, status, created_at, decided_at, decided_by from public.platform_advisor_recommendations order by case priority when 'urgent' then 0 when 'high' then 1 else 2 end, created_at desc limit 100")
    ]);
    const metrics = (snapshot.rows[0]?.metrics || {}) as AdvisorMetrics;
    return NextResponse.json({ metrics, metricsMode: "admin-entered-until-automated", updatedAt: snapshot.rows[0]?.updated_at || null, recommendations: recs.rows });
  } catch (error: any) {
    return NextResponse.json({ error: "ADVISOR_NOT_MIGRATED", detail: error?.message || "Run database migrations first." }, { status: 503 });
  }
}

export async function POST(req: Request) {
  const access = await getAccess();
  if (access.role !== "admin" || !access.user?.id) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  try {
    if (body.action === "save_metrics") {
      if (!body.metrics || typeof body.metrics !== "object" || Array.isArray(body.metrics)) return NextResponse.json({ error: "INVALID_METRICS" }, { status: 400 });
      // Bound input size and reject non-finite numbers; metrics remain a snapshot, not proof of bank cash.
      const raw = JSON.stringify(body.metrics);
      if (raw.length > 20000) return NextResponse.json({ error: "METRICS_TOO_LARGE" }, { status: 413 });
      const clean = JSON.parse(raw, (_k, v) => typeof v === "number" && !Number.isFinite(v) ? 0 : v) as AdvisorMetrics;
      const recommendations = buildPlatformRecommendations(clean);
      await query("insert into public.platform_advisor_snapshot(id,metrics,updated_at,updated_by) values(true,$1::jsonb,now(),$2) on conflict(id) do update set metrics=excluded.metrics,updated_at=now(),updated_by=excluded.updated_by", [JSON.stringify(clean), access.user.id]);
      for (const r of recommendations) {
        await query(`insert into public.platform_advisor_recommendations(id,priority,area,title,reason,proposed_action,impact,status,created_at)
          values($1,$2,$3,$4,$5,$6,$7,'pending',now()) on conflict(id) do update set priority=excluded.priority,reason=excluded.reason,proposed_action=excluded.proposed_action,impact=excluded.impact where public.platform_advisor_recommendations.status='pending'`,
          [r.id, r.priority, r.area, r.title, r.reason, r.proposedAction, r.impact]);
      }
      await auditLog({ actorId: access.user.id, actorRole: access.role, action: "platform_advisor.metrics_saved", details: { areas: Object.keys(clean), recommendationCount: recommendations.length } });
      return NextResponse.json({ ok: true, recommendationCount: recommendations.length, recommendations });
    }
    if (body.action === "approve" || body.action === "dismiss") {
      const id = String(body.id || "");
      if (!id || id.length > 120) return NextResponse.json({ error: "INVALID_ID" }, { status: 400 });
      const status = body.action === "approve" ? "approved" : "dismissed";
      const result = await query("update public.platform_advisor_recommendations set status=$2,decided_at=now(),decided_by=$3 where id=$1 and status='pending' returning id", [id, status, access.user.id]);
      if (!result.rowCount) return NextResponse.json({ error: "NOT_PENDING_OR_NOT_FOUND" }, { status: 409 });
      await auditLog({ actorId: access.user.id, actorRole: access.role, action: `platform_advisor.${status}`, targetType: "platform_advisor_recommendation", targetId: id });
      return NextResponse.json({ ok: true, status });
    }
    return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: "ADVISOR_NOT_MIGRATED_OR_FAILED", detail: error?.message || "Run migrations and verify database connectivity." }, { status: 503 });
  }
}
