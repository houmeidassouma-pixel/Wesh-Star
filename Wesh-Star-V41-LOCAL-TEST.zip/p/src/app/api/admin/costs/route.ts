import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query } from "@/lib/db/pool";
import { auditLog } from "@/lib/audit";
import { applyRecommendation, loadReport, refreshRecommendations } from "@/lib/costs";
import { normalizeCostSettings } from "@/lib/costs-core";

// Conseiller financier (admin uniquement) : coûts réels, marges, seuil de rentabilité, propositions à valider.
export async function GET(req: Request) {
  const access = await getAccess();
  if (access.role !== "admin") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const days = Number(new URL(req.url).searchParams.get("days") || 30);
  await refreshRecommendations().catch(() => 0);
  const [{ report, settings }, recs] = await Promise.all([loadReport(days), query("select id,kind,title,details,status,created_at from public.cost_recommendations order by (status='pending') desc, created_at desc limit 20")]);
  return NextResponse.json({ report, settings, recommendations: recs.rows });
}

export async function POST(req: Request) {
  const access = await getAccess();
  if (access.role !== "admin") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const adminId = access.user!.id;
  try {
    if (body.action === "save_settings") {
      const s = normalizeCostSettings(body.settings);
      await query(`update public.cost_settings set electricity_eur_per_kwh=$1,gpu_watts=$2,system_watts=$3,gpu_seconds_per_video_second=$4,gpu_seconds_per_image=$5,overhead_pct=$6,
        hardware_cost_eur=$7,hardware_lifetime_months=$8,fixed_monthly_eur=$9,manual_monthly_revenue_eur=$10,target_margin_pct=$11,updated_at=now(),updated_by=$12 where id=true`,
        [s.electricityEurPerKwh, s.gpuWatts, s.systemWatts, s.gpuSecondsPerVideoSecond, s.gpuSecondsPerImage, s.overheadPct, s.hardwareCostEur, s.hardwareLifetimeMonths, s.fixedMonthlyEur, s.manualMonthlyRevenueEur, s.targetMarginPct, adminId]);
      await auditLog({ actorId: adminId, actorRole: access.role, action: "costs.settings_saved", details: s });
      return NextResponse.json({ ok: true });
    }
    if (body.action === "validate" || body.action === "dismiss") {
      const id = String(body.id || "");
      if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
      if (body.action === "validate") {
        const r = await applyRecommendation(id, adminId);
        await auditLog({ actorId: adminId, actorRole: access.role, action: "costs.recommendation_applied", targetType: "cost_recommendation", targetId: id, details: r });
        return NextResponse.json({ ok: true, ...r });
      }
      await query("update public.cost_recommendations set status='dismissed', decided_at=now(), decided_by=$2 where id=$1 and status='pending'", [id, adminId]);
      return NextResponse.json({ ok: true });
    }
    return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
  } catch (e: any) { return NextResponse.json({ error: e?.message || "COSTS_FAILED" }, { status: 400 }); }
}
