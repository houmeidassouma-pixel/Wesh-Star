import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query } from "@/lib/db/pool";
import { auditLog } from "@/lib/audit";
import { callsServerEnabled, getCallsSettings } from "@/lib/calls";

// Réglages des appels privés (admin) : activer/couper et choisir qui peut appeler.
export async function GET() {
  const access = await getAccess();
  if (access.role !== "admin") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const r = await query("select count(*)::int as n from public.call_reports");
  return NextResponse.json({ ...(await getCallsSettings()), serverEnabled: callsServerEnabled(), livekitConfigured: !!(process.env.LIVEKIT_API_KEY && process.env.LIVEKIT_API_SECRET && process.env.LIVEKIT_PUBLIC_URL), reports: r.rows[0]?.n || 0 });
}
export async function POST(req: Request) {
  const access = await getAccess();
  if (access.role !== "admin") return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const enabled = body.callsEnabled !== false;
  const accessMode = ["all", "subscribers", "verified"].includes(body.callsAccess) ? body.callsAccess : "all";
  await query("update public.communication_settings set calls_enabled=$1, calls_access=$2, updated_at=now() where id=true", [enabled, accessMode]);
  await auditLog({ actorId: access.user!.id, actorRole: access.role, action: "communication.settings_saved", details: { enabled, accessMode } });
  return NextResponse.json({ ok: true });
}
