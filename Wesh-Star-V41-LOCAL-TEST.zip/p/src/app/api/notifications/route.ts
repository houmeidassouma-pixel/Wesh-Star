import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query } from "@/lib/db/pool";

// Liste des notifications de l'utilisateur connecté + nombre de non lues.
export async function GET() {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const [list, unread] = await Promise.all([
    query("select id,kind,title,body,url,read_at,created_at from public.notifications where user_id=$1 order by created_at desc limit 30", [access.user.id]),
    query("select count(*)::int as n from public.notifications where user_id=$1 and read_at is null", [access.user.id])
  ]);
  return NextResponse.json({ notifications: list.rows, unread: unread.rows[0]?.n || 0 });
}

// Marquer comme lues : une notification (id) ou toutes (all=true).
export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  if (body.all === true) await query("update public.notifications set read_at=now() where user_id=$1 and read_at is null", [access.user.id]);
  else if (/^[0-9a-f-]{36}$/i.test(String(body.id || ""))) await query("update public.notifications set read_at=now() where id=$1 and user_id=$2 and read_at is null", [body.id, access.user.id]);
  else return NextResponse.json({ error: "INVALID_REQUEST" }, { status: 400 });
  return NextResponse.json({ ok: true });
}
