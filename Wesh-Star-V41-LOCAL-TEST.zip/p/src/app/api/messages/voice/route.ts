import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { getAccess } from "@/lib/access";
import { getPool } from "@/lib/db/pool";
import { isBlockedPair } from "@/lib/calls";
import { rateLimit, clientKey } from "@/lib/ratelimit";
import { uploadVideo } from "@/lib/storage";

export const runtime = "nodejs";
const MAX_BYTES = 3 * 1024 * 1024;

// Reconnaît le vrai format audio d'après les premiers octets (on ne fait pas confiance au type annoncé par le navigateur).
function sniff(b: Uint8Array): "webm" | "ogg" | "mp4" | "wav" | "mp3" | null {
  if (b.length < 12) return null;
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return "webm";
  if (b[0] === 0x4f && b[1] === 0x67 && b[2] === 0x67 && b[3] === 0x53) return "ogg";
  if (b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70) return "mp4";
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x41) return "wav";
  if ((b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)) return "mp3";
  return null;
}

export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  if (access.profile?.blocked) return NextResponse.json({ error: "ACCOUNT_BLOCKED" }, { status: 403 });
  if (!rateLimit("voice:" + clientKey(req, access.user.id), 10, 60_000)) return NextResponse.json({ error: "RATE_LIMITED" }, { status: 429 });
  let form: FormData;
  try { form = await req.formData(); } catch { return NextResponse.json({ error: "INVALID_MESSAGE" }, { status: 400 }); }
  const recipientId = String(form.get("recipientId") || "");
  const seconds = Math.round(Number(form.get("seconds")));
  const file = form.get("audio");
  if (!/^[0-9a-f-]{36}$/i.test(recipientId) || recipientId === access.user.id || !(file instanceof File) || !Number.isFinite(seconds) || seconds < 1 || seconds > 180) return NextResponse.json({ error: "INVALID_MESSAGE" }, { status: 400 });
  if (file.size < 200 || file.size > MAX_BYTES) return NextResponse.json({ error: "AUDIO_TOO_LARGE" }, { status: 413 });
  const buf = Buffer.from(await file.arrayBuffer());
  const kind = sniff(buf);
  if (!kind) return NextResponse.json({ error: "UNSUPPORTED_AUDIO" }, { status: 415 });
  const db = getPool();
  const recipient = await db.query(`SELECT id FROM profiles WHERE id=$1`, [recipientId]);
  if (!recipient.rows[0]) return NextResponse.json({ error: "RECIPIENT_NOT_FOUND" }, { status: 404 });
  if (await isBlockedPair(access.user.id, recipientId)) return NextResponse.json({ error: "USER_BLOCKED" }, { status: 403 });
  const path = `voice/${access.user.id}/${randomUUID()}.${kind}`;
  await uploadVideo(path, buf);
  const inserted = await db.query(
    `INSERT INTO private_messages(sender_id,recipient_id,body,kind,audio_path,audio_seconds) VALUES($1,$2,'🎤 Message vocal','voice',$3,$4) RETURNING id,sender_id,recipient_id,body,kind,audio_seconds,created_at,read_at`,
    [access.user.id, recipientId, path, seconds]);
  return NextResponse.json({ message: inserted.rows[0] }, { status: 201 });
}
