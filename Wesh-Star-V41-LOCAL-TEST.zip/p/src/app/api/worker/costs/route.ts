import { NextResponse } from "next/server";
import { isCronAuthorized } from "@/lib/cron-auth";
import { refreshRecommendations } from "@/lib/costs";

// Appelée par le planificateur plusieurs fois par jour : recalcule les coûts et prépare les propositions pour l'admin.
export async function GET(req: Request) { return run(req); }
export async function POST(req: Request) { return run(req); }
async function run(req: Request) {
  if (!isCronAuthorized(req)) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  return NextResponse.json({ ok: true, created: await refreshRecommendations() });
}
