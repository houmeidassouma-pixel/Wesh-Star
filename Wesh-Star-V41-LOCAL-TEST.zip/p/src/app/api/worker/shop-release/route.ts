import { NextResponse } from "next/server";
import { isCronAuthorized } from "@/lib/cron-auth";
import { processDueOrders } from "@/lib/shop/escrow";

// Appelée par le planificateur : libère les fonds dont le blocage est écoulé et rembourse les commandes jamais expédiées.
export async function GET(req: Request) { return run(req); }
export async function POST(req: Request) { return run(req); }
async function run(req: Request) {
  if (!isCronAuthorized(req)) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  const result = await processDueOrders();
  return NextResponse.json({ ok: true, ...result });
}
