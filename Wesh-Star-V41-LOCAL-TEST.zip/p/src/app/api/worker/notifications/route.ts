import { NextResponse } from "next/server";
import { isCronAuthorized } from "@/lib/cron-auth";
import { processPendingPushes } from "@/lib/notify";

// Appelée par le planificateur chaque minute : envoie les notifications Push en attente (sans intervention humaine).
export async function GET(req: Request) { return run(req); }
export async function POST(req: Request) { return run(req); }
async function run(req: Request) {
  if (!isCronAuthorized(req)) return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  return NextResponse.json({ ok: true, ...(await processPendingPushes()) });
}
