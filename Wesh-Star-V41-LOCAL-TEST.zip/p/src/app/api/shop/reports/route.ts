import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query } from "@/lib/db/pool";
import { rateLimit, clientKey } from "@/lib/ratelimit";

// Signalement d'une annonce par un utilisateur (un signalement par produit et par personne).
export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  if (!rateLimit("shop-report:" + clientKey(req, access.user.id), 10, 60_000)) return NextResponse.json({ error: "RATE_LIMIT" }, { status: 429 });
  const body = await req.json().catch(() => ({}));
  const productId = String(body.productId || ""), reason = String(body.reason || "").trim().slice(0, 500);
  if (!/^[0-9a-f-]{36}$/i.test(productId) || reason.length < 3) return NextResponse.json({ error: "INVALID_REPORT" }, { status: 400 });
  const r = await query("insert into public.shop_reports (product_id,reporter_id,reason) select id,$2,$3 from public.shop_products where id=$1 on conflict (product_id,reporter_id) do nothing returning id", [productId, access.user.id, reason]);
  return NextResponse.json({ ok: true, alreadyReported: !r.rowCount });
}
