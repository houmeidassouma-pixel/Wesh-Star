import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query, withTransaction } from "@/lib/db/pool";
import { rateLimit, clientKey } from "@/lib/ratelimit";
import { moderateText } from "@/lib/moderation";
import { auditLog } from "@/lib/audit";
import { addDisputeMessage, cancelOrder, confirmReceipt, openDispute, purchase, shipOrder, ShopError } from "@/lib/shop/escrow";
import { canReview } from "@/lib/shop/fees";

const uuid = /^[0-9a-f-]{36}$/i;
const country = /^[A-Z]{2}$/;
const fail = (e: any) => {
  const status = Number(e?.status) || 500;
  return NextResponse.json({ error: status === 500 ? "SHOP_OPERATION_FAILED" : e.message, ...(e?.needed ? { needed: e.needed } : {}), ...(e?.min ? { min: e.min } : {}) }, { status });
};
const safeImage = (v: unknown) => {
  if (!v) return null;
  if (typeof v !== "string" || v.length > 2000) return undefined;
  try { const u = new URL(v); return u.protocol === "https:" ? u.toString() : undefined; } catch { return undefined; }
};

// Mes commandes (acheteur et vendeur) avec litige et avis.
export async function GET() {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const uid = access.user.id;
  const r = await query(
    `select o.id,o.product_id,o.buyer_id,o.seller_id,o.quantity,o.unit_price_minor,o.currency,o.subtotal_minor,o.commission_minor,o.fixed_fee_minor,o.promo_minor,o.seller_net_minor,o.refunded_minor,
            o.shipping_country,o.status,o.paid_at,o.ship_by,o.release_at,o.shipped_at,o.tracking_carrier,o.tracking_number,o.released_at,p.title,
            case when o.buyer_id=$1 then coalesce(s.username,s.email,'Vendeur') else coalesce(b.username,b.email,'Acheteur') end as other_party,
            d.id as dispute_id,d.status as dispute_status,d.reason as dispute_reason,d.resolution as dispute_resolution,
            (select rating from public.shop_reviews rv where rv.order_id=o.id) as review_rating
       from public.shop_orders o join public.shop_products p on p.id=o.product_id
       left join public.profiles s on s.id=o.seller_id left join public.profiles b on b.id=o.buyer_id
       left join public.shop_disputes d on d.order_id=o.id
      where o.buyer_id=$1 or o.seller_id=$1 order by o.created_at desc limit 100`, [uid]);
  const disputeIds = r.rows.filter((x) => x.dispute_id).map((x) => x.dispute_id);
  const msgs = disputeIds.length
    ? (await query("select dispute_id,author_role,body,image_url,created_at from public.shop_dispute_messages where dispute_id = any($1::uuid[]) order by created_at", [disputeIds])).rows : [];
  const orders = r.rows.map((o) => ({ ...o, role: o.buyer_id === uid ? "buyer" : "seller", messages: msgs.filter((m) => m.dispute_id === o.dispute_id) }));
  return NextResponse.json({ orders, currentUserId: uid });
}

// Achat : le montant est débité du solde boutique de l'acheteur et bloqué en séquestre.
export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  if (access.profile?.blocked) return NextResponse.json({ error: "ACCOUNT_BLOCKED" }, { status: 403 });
  if (!rateLimit("shop-checkout:" + clientKey(req, access.user.id), 8, 60_000)) return NextResponse.json({ error: "RATE_LIMIT" }, { status: 429 });
  const body = await req.json().catch(() => ({}));
  const productId = String(body.productId || "");
  const quantity = Number(body.quantity || 1);
  const shippingCountry = String(body.shippingCountry || "").toUpperCase();
  const message = String(body.message || "").trim().slice(0, 1000);
  if (!uuid.test(productId) || !Number.isInteger(quantity) || quantity < 1 || quantity > 100000 || !country.test(shippingCountry)) return NextResponse.json({ error: "INVALID_ORDER_FIELDS" }, { status: 400 });
  try {
    const order = await withTransaction((c) => purchase(c, { buyerId: access.user!.id, productId, quantity, shippingCountry, message }));
    await auditLog({ actorId: access.user.id, action: "shop.order_paid", targetType: "shop_order", targetId: order.id, details: { total: order.subtotal_minor, currency: order.currency } });
    return NextResponse.json({ order: { id: order.id, status: order.status, subtotal_minor: order.subtotal_minor, currency: order.currency, release_at: order.release_at } }, { status: 201 });
  } catch (e) { return fail(e); }
}

// Actions sur une commande : expédier, confirmer la réception, annuler, ouvrir un litige, écrire dans un litige, noter.
export async function PATCH(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  if (access.profile?.blocked) return NextResponse.json({ error: "ACCOUNT_BLOCKED" }, { status: 403 });
  if (!rateLimit("shop-order-action:" + clientKey(req, access.user.id), 30, 60_000)) return NextResponse.json({ error: "RATE_LIMIT" }, { status: 429 });
  const body = await req.json().catch(() => ({}));
  const id = String(body.id || ""), action = String(body.action || "");
  if (!uuid.test(id)) return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
  const uid = access.user.id;
  try {
    if (action === "ship") {
      const carrier = String(body.carrier || "").trim(), tracking = String(body.tracking || "").trim();
      if (carrier.length < 2 || tracking.length < 3) return NextResponse.json({ error: "TRACKING_REQUIRED" }, { status: 400 });
      await withTransaction((c) => shipOrder(c, id, uid, carrier, tracking));
    } else if (action === "confirm_received") {
      await withTransaction((c) => confirmReceipt(c, id, uid));
    } else if (action === "cancel") {
      await withTransaction((c) => cancelOrder(c, id, uid));
    } else if (action === "open_dispute") {
      const details = String(body.details || "").trim();
      if (moderateText(details).blocked) return NextResponse.json({ error: "CONTENT_NOT_ALLOWED" }, { status: 400 });
      await withTransaction((c) => openDispute(c, id, uid, String(body.reason || ""), details));
    } else if (action === "dispute_message") {
      const text = String(body.body || "");
      if (moderateText(text).blocked) return NextResponse.json({ error: "CONTENT_NOT_ALLOWED" }, { status: 400 });
      const img = safeImage(body.imageUrl);
      if (img === undefined) return NextResponse.json({ error: "INVALID_IMAGE_URL" }, { status: 400 });
      await withTransaction((c) => addDisputeMessage(c, id, uid, false, text, img));
    } else if (action === "review") {
      const rating = Number(body.rating), comment = String(body.comment || "").trim().slice(0, 1000);
      if (!Number.isInteger(rating) || rating < 1 || rating > 5 || moderateText(comment).blocked) return NextResponse.json({ error: "INVALID_REVIEW" }, { status: 400 });
      await withTransaction(async (c) => {
        const o = (await c.query("select * from public.shop_orders where id=$1", [id])).rows[0];
        if (!o) throw new ShopError("ORDER_NOT_FOUND", 404);
        if (!canReview(o, uid)) throw new ShopError("NOT_ALLOWED", 403);
        const r = await c.query("insert into public.shop_reviews (order_id,buyer_id,seller_id,rating,comment) values ($1,$2,$3,$4,$5) on conflict (order_id) do nothing returning id", [id, uid, o.seller_id, rating, comment]);
        if (!r.rowCount) throw new ShopError("ALREADY_REVIEWED", 409);
      });
    } else return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
    await auditLog({ actorId: uid, action: "shop.order_" + action, targetType: "shop_order", targetId: id });
    return NextResponse.json({ ok: true });
  } catch (e) { return fail(e); }
}
