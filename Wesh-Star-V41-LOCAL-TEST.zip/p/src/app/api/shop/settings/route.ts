import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { getShopSettings } from "@/lib/shop/escrow";

// Partie publique des réglages (pour afficher commission, blocage et bornes de promotion avant la publication).
export async function GET() {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const s = await getShopSettings();
  return NextResponse.json({
    escrowEnabled: s.escrowEnabled, commissionPct: s.commissionPct, categoryCommissionPct: s.categoryCommissionPct, countryCommissionPct: s.countryCommissionPct,
    fixedFeeMinor: s.fixedFeeMinor, holdHours: s.holdHours, newSellerHoldHours: s.newSellerHoldHours, shipDeadlineDays: s.shipDeadlineDays, promoMinPct: s.promoMinPct, promoMaxPct: s.promoMaxPct
  });
}
