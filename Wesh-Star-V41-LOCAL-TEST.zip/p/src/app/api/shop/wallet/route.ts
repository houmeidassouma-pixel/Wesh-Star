import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query, withTransaction } from "@/lib/db/pool";
import { rateLimit, clientKey } from "@/lib/ratelimit";
import { createTopup, getShopSettings, requestPayout, ShopError } from "@/lib/shop/escrow";
import { SHOP_CURRENCIES, toMinor } from "@/lib/shop/fees";
import { newRef } from "@/lib/payments/flutterwave";

const fail = (e: any) => {
  const status = Number(e?.status) || 500;
  return NextResponse.json({ error: status === 500 ? "WALLET_OPERATION_FAILED" : e.message, ...(e?.min ? { min: e.min } : {}) }, { status });
};

// Solde boutique : disponible, en séquestre côté vendeur (à venir), retraits, recharges, dernières écritures.
export async function GET() {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const uid = access.user.id;
  const [bal, pending, payouts, topups, entries, verified, settings] = await Promise.all([
    query("select currency, coalesce(sum(case when account='available' then amount_minor else 0 end),0)::bigint as available, coalesce(sum(case when account='payout_hold' then amount_minor else 0 end),0)::bigint as payout_hold from public.shop_ledger where user_id=$1 group by currency", [uid]),
    query("select currency, coalesce(sum(seller_net_minor),0)::bigint as pending from public.shop_orders where seller_id=$1 and status in ('paid','shipped','delivered','disputed') group by currency", [uid]),
    query("select id,currency,amount_minor,method,status,admin_note,created_at from public.shop_payouts where user_id=$1 order by created_at desc limit 20", [uid]),
    query("select reference,currency,amount_minor,method,status,created_at from public.shop_topups where user_id=$1 order by created_at desc limit 20", [uid]),
    query("select kind,currency,account,amount_minor,note,created_at from public.shop_ledger where user_id=$1 order by id desc limit 30", [uid]),
    query("select shop_seller_verified from public.profiles where id=$1", [uid]),
    getShopSettings()
  ]);
  const byCur: Record<string, any> = {};
  for (const c of SHOP_CURRENCIES) byCur[c] = { currency: c, available: 0, payoutHold: 0, pendingSales: 0 };
  for (const r of bal.rows) byCur[r.currency] = { ...byCur[r.currency], available: Number(r.available), payoutHold: Number(r.payout_hold) };
  for (const r of pending.rows) byCur[r.currency] = { ...byCur[r.currency], pendingSales: Number(r.pending) };
  return NextResponse.json({
    balances: Object.values(byCur), payouts: payouts.rows, topups: topups.rows, entries: entries.rows,
    sellerVerified: !!verified.rows[0]?.shop_seller_verified,
    rules: { holdHours: settings.holdHours, newSellerHoldHours: settings.newSellerHoldHours, payoutRequiresVerification: settings.payoutRequiresVerification, minPayoutMinor: settings.minPayoutMinor, flutterwave: !!process.env.FLUTTERWAVE_SECRET_KEY }
  });
}

// Recharge (Flutterwave en FCFA, ou demande confirmée à la main par l'admin) ou demande de retrait.
export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  if (access.profile?.blocked) return NextResponse.json({ error: "ACCOUNT_BLOCKED" }, { status: 403 });
  if (!rateLimit("shop-wallet:" + clientKey(req, access.user.id), 6, 60_000)) return NextResponse.json({ error: "RATE_LIMIT" }, { status: 429 });
  const body = await req.json().catch(() => ({}));
  const action = String(body.action || "");
  const currency = String(body.currency || "").toUpperCase();
  if (!(SHOP_CURRENCIES as readonly string[]).includes(currency)) return NextResponse.json({ error: "INVALID_CURRENCY" }, { status: 400 });
  try {
    const minor = toMinor(Number(body.amount), currency);
    if (action === "topup_manual") {
      const t = await createTopup(access.user.id, currency, minor, "manual", newRef("WS-SHM-"));
      return NextResponse.json({ topup: t }, { status: 201 });
    }
    if (action === "payout") {
      const p = await withTransaction((c) => requestPayout(c, { userId: access.user!.id, currency, amountMinor: minor, method: String(body.method || ""), details: String(body.details || "") }));
      return NextResponse.json({ payout: { id: p.id, status: p.status } }, { status: 201 });
    }
    return NextResponse.json({ error: "INVALID_ACTION" }, { status: 400 });
  } catch (e: any) {
    if (e?.message === "INVALID_AMOUNT") return NextResponse.json({ error: "INVALID_AMOUNT" }, { status: 400 });
    return fail(e instanceof ShopError ? e : e);
  }
}
