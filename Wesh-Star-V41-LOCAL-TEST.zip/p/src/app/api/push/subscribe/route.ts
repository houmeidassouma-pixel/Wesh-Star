import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query } from "@/lib/db/pool";
import { getVapid } from "@/lib/webpush";

// Clé publique VAPID (nécessaire au navigateur pour s'abonner).
export async function GET() {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const v = getVapid();
  return NextResponse.json({ enabled: !!v, publicKey: v?.publicKey || null });
}

export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const endpoint = String(b?.endpoint || ""), p256dh = String(b?.keys?.p256dh || ""), auth = String(b?.keys?.auth || "");
  if (!/^https:\/\/.{10,500}$/.test(endpoint) || p256dh.length < 40 || p256dh.length > 200 || auth.length < 8 || auth.length > 100) return NextResponse.json({ error: "INVALID_SUBSCRIPTION" }, { status: 400 });
  await query(
    "insert into public.push_subscriptions (user_id,endpoint,p256dh,auth,user_agent) values ($1,$2,$3,$4,$5) on conflict (endpoint) do update set user_id=excluded.user_id,p256dh=excluded.p256dh,auth=excluded.auth",
    [access.user.id, endpoint, p256dh, auth, (req.headers.get("user-agent") || "").slice(0, 200)]);
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  await query("delete from public.push_subscriptions where user_id=$1 and endpoint=$2", [access.user.id, String(b?.endpoint || "")]);
  return NextResponse.json({ ok: true });
}
