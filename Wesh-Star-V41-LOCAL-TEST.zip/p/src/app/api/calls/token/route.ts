import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query } from "@/lib/db/pool";
import { callsServerEnabled, getCallsSettings } from "@/lib/calls";
import { makeLiveKitToken } from "@/lib/livekit-token";

// Jeton LiveKit pour rejoindre la salle d'un appel privé : seuls l'appelant et l'appelé, tant que l'appel est en cours.
export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  if (!callsServerEnabled() || !(await getCallsSettings()).callsEnabled) return NextResponse.json({ error: "COMMUNICATIONS_DISABLED" }, { status: 503 });
  const apiKey = process.env.LIVEKIT_API_KEY || "", secret = process.env.LIVEKIT_API_SECRET || "", url = process.env.LIVEKIT_PUBLIC_URL || "";
  if (!apiKey || !secret || !/^wss?:\/\//i.test(url)) return NextResponse.json({ error: "LIVE_STREAM_NOT_CONFIGURED", message: "Le serveur LiveKit n'est pas configuré (LIVEKIT_API_KEY, LIVEKIT_API_SECRET, LIVEKIT_PUBLIC_URL)." }, { status: 503 });
  const body = await req.json().catch(() => ({}));
  const callId = String(body.callId || "");
  if (!/^[0-9a-f-]{36}$/i.test(callId)) return NextResponse.json({ error: "CALL_NOT_FOUND" }, { status: 404 });
  const r = await query("select id,caller_id,callee_id,call_type,status from public.communication_calls where id=$1 and (caller_id=$2 or callee_id=$2)", [callId, access.user.id]);
  const c = r.rows[0];
  if (!c) return NextResponse.json({ error: "CALL_NOT_FOUND" }, { status: 404 });
  // L'appelé ne peut entrer dans la salle qu'après avoir accepté ; l'appelant peut attendre dedans pendant la sonnerie.
  const allowed = c.caller_id === access.user.id ? ["ringing", "accepted"].includes(c.status) : c.status === "accepted";
  if (!allowed) return NextResponse.json({ error: "CALL_NOT_ACTIVE" }, { status: 409 });
  const token = makeLiveKitToken(apiKey, secret, access.user.id, String(access.user.email || "Wesh user").split("@")[0], `call-${c.id}`, true, 2 * 3600);
  return NextResponse.json({ ok: true, url, token, room: `call-${c.id}`, callType: c.call_type });
}
