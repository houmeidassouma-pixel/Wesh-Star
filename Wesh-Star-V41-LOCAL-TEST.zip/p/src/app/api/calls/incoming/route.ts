import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { getPool } from "@/lib/db/pool";
import { callsServerEnabled, getCallsSettings } from "@/lib/calls";

const RING_SECONDS = 45;

// Appels en cours pour l'utilisateur (sonnerie entrante ou appel accepté), avec le nom de l'autre personne.
export async function GET() {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  if (!callsServerEnabled() || !(await getCallsSettings()).callsEnabled) return NextResponse.json({ error: "COMMUNICATIONS_DISABLED" }, { status: 503 });
  const db = getPool();
  await db.query(`UPDATE communication_calls SET status='missed', ended_at=now() WHERE status='ringing' AND created_at < now() - ($1 || ' seconds')::interval`, [String(RING_SECONDS)]);
  const r = await db.query(
    `SELECT c.id,c.caller_id,c.callee_id,c.call_type,c.status,c.created_at,
            coalesce(nullif(p.username,''), split_part(p.email,'@',1)) AS other_label,
            (c.callee_id=$1) AS incoming
       FROM communication_calls c JOIN profiles p ON p.id = CASE WHEN c.caller_id=$1 THEN c.callee_id ELSE c.caller_id END
      WHERE (c.callee_id=$1 OR c.caller_id=$1) AND c.status IN ('ringing','accepted') AND c.created_at > now() - interval '2 hours'
      ORDER BY c.created_at DESC LIMIT 5`, [access.user.id]);
  const missed = await db.query(
    `SELECT c.id, coalesce(nullif(p.username,''), split_part(p.email,'@',1)) AS other_label, c.call_type, c.created_at
       FROM communication_calls c JOIN profiles p ON p.id=c.caller_id
      WHERE c.callee_id=$1 AND c.status='missed' AND c.created_at > now() - interval '1 day' ORDER BY c.created_at DESC LIMIT 5`, [access.user.id]);
  return NextResponse.json({ calls: r.rows, missed: missed.rows });
}
