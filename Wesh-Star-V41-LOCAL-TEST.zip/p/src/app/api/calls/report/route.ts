import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query } from "@/lib/db/pool";

// Signalement d'un appel par l'un des deux participants (revu ensuite par la modération).
export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const callId = String(body.callId || ""), reason = String(body.reason || "").trim().slice(0, 500);
  if (!/^[0-9a-f-]{36}$/i.test(callId) || reason.length < 3) return NextResponse.json({ error: "INVALID_REPORT" }, { status: 400 });
  const r = await query("insert into public.call_reports (call_id,reporter_id,reason) select id,$2,$3 from public.communication_calls where id=$1 and (caller_id=$2 or callee_id=$2) on conflict (call_id,reporter_id) do nothing returning id", [callId, access.user.id, reason]);
  return NextResponse.json({ ok: true, alreadyReported: !r.rowCount });
}
