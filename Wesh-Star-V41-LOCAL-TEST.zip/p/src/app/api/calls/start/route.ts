import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { getPool } from "@/lib/db/pool";
import { rateLimit, clientKey } from "@/lib/ratelimit";
import { callsServerEnabled, getCallsSettings, isBlockedPair, mayUseCalls } from "@/lib/calls";

const RING_SECONDS = 45;

// Lance un appel audio ou vidéo privé. La salle média est créée côté LiveKit au moment où chacun récupère son jeton.
export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  if (access.profile?.blocked) return NextResponse.json({ error: "ACCOUNT_BLOCKED" }, { status: 403 });
  if (!callsServerEnabled()) return NextResponse.json({ error: "COMMUNICATIONS_DISABLED" }, { status: 503 });
  const settings = await getCallsSettings();
  if (!settings.callsEnabled) return NextResponse.json({ error: "COMMUNICATIONS_DISABLED" }, { status: 503 });
  if (!mayUseCalls(settings, { isStaff: access.isAdmin || access.isModerator, planKey: access.planKey, profile: access.profile })) return NextResponse.json({ error: "CALLS_NOT_ALLOWED_FOR_PLAN" }, { status: 403 });
  if (!rateLimit("call-start:" + clientKey(req, access.user.id), 6, 60_000)) return NextResponse.json({ error: "RATE_LIMIT" }, { status: 429 });
  const body = await req.json().catch(() => ({}));
  const calleeId = String(body.calleeId || "");
  const callType = body.callType === "video" ? "video" : body.callType === "audio" ? "audio" : "";
  if (!/^[0-9a-f-]{36}$/i.test(calleeId) || calleeId === access.user.id || !callType) return NextResponse.json({ error: "INVALID_CALL" }, { status: 400 });
  const db = getPool();
  const recipient = await db.query(`SELECT id, blocked FROM profiles WHERE id=$1`, [calleeId]);
  if (!recipient.rows[0] || recipient.rows[0].blocked) return NextResponse.json({ error: "RECIPIENT_NOT_FOUND" }, { status: 404 });
  if (await isBlockedPair(access.user.id, calleeId)) return NextResponse.json({ error: "USER_BLOCKED" }, { status: 403 });
  // Les appels restés en sonnerie trop longtemps passent en « manqué » avant de vérifier qu'aucun appel n'est actif.
  await db.query(`UPDATE communication_calls SET status='missed', ended_at=now() WHERE status='ringing' AND created_at < now() - ($1 || ' seconds')::interval`, [String(RING_SECONDS)]);
  const active = await db.query(`SELECT id FROM communication_calls WHERE (caller_id=$1 OR callee_id=$1 OR caller_id=$2 OR callee_id=$2) AND status IN ('ringing','accepted') AND created_at > now() - interval '2 hours' LIMIT 1`, [access.user.id, calleeId]);
  if (active.rows[0]) return NextResponse.json({ error: "CALL_ALREADY_ACTIVE" }, { status: 409 });
  const created = await db.query(`INSERT INTO communication_calls(caller_id,callee_id,call_type) VALUES($1,$2,$3) RETURNING id,caller_id,callee_id,call_type,status,created_at`, [access.user.id, calleeId, callType]);
  return NextResponse.json({ call: created.rows[0] }, { status: 201 });
}
