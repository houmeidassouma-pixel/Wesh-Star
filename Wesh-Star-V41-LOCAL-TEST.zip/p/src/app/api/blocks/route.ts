import { NextResponse } from "next/server";
import { getAccess } from "@/lib/access";
import { query } from "@/lib/db/pool";

// Bloquer / débloquer un utilisateur : plus de messages privés ni d'appels dans les deux sens.
export async function GET() {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const r = await query("select b.blocked_id as id, coalesce(nullif(p.username,''), split_part(p.email,'@',1)) as label from public.user_blocks b join public.profiles p on p.id=b.blocked_id where b.blocker_id=$1 order by b.created_at desc limit 200", [access.user.id]);
  return NextResponse.json({ blocks: r.rows });
}
export async function POST(req: Request) {
  const access = await getAccess();
  if (!access.user) return NextResponse.json({ error: "AUTH_REQUIRED" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const userId = String(body.userId || "");
  if (!/^[0-9a-f-]{36}$/i.test(userId) || userId === access.user.id) return NextResponse.json({ error: "INVALID_USER" }, { status: 400 });
  if (body.blocked === false) await query("delete from public.user_blocks where blocker_id=$1 and blocked_id=$2", [access.user.id, userId]);
  else await query("insert into public.user_blocks (blocker_id,blocked_id) select $1,id from public.profiles where id=$2 on conflict do nothing", [access.user.id, userId]);
  return NextResponse.json({ ok: true });
}
