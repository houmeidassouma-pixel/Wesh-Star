# V40 — changements

V40 part du ZIP V39 sans supprimer les fichiers existants. Il ajoute une API admin pour le conseiller global, une migration SQL pour stocker les métriques et recommandations, ainsi qu'un guide de test local avant achat de matériel.

**À ne pas confondre avec un lancement prêt en production :** les métriques globales restent saisies manuellement jusqu'à ce que les agrégations de chaque module soient connectées. Les actions approuvées sont auditées, mais l'approbation ne déclenche aucun changement financier automatique. Les transporteurs réels et le portail annonceur restent des intégrations à finaliser.
