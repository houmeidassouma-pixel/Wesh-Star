# Contenu du ZIP Wesh Star V39

Base : archive V38 `Wesh-Star-V38-SHOP-CONSEILLER-FINANCIER-PUBLICITE.zip`.

## Nouveautés V39
- `src/lib/platform-advisor.ts` : moteur pur de recommandations multi-domaines (Shop, Ads, Studio IA, LIVE, trésorerie), avec priorité, motif, proposition et impact. Chaque recommandation exige une validation humaine.
- `tests/platform-advisor.test.ts` : tests du moteur global.
- `docs/CONSEILLER_GLOBAL_V39.md` : plan consolidé et critères de réalisation de tous les modules.
- Conservation des fichiers V38, des fonctions existantes, de la configuration locale et des tests antérieurs.

## Important
Le moteur V39 est une brique de règles, pas encore un conseiller global connecté à toutes les données réelles. La collecte des métriques, la persistance, les notifications de chaque domaine et l’interface globale de validation restent à intégrer. Les connexions transporteurs, le portail annonceur autonome et les tests de paiements réels restent à réaliser.

## Vérification
Depuis `p/`, installer les dépendances puis lancer `npm test`. Lancer `npm run build` avec la configuration d’environnement documentée. Ne pas déployer publiquement sans tests d’intégration, de sécurité, de paiement et de restauration.
