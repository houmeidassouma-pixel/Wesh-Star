# Wesh Star V40 — test local avant achat de matériel

## Ce que V40 ajoute
- API administrateur `/api/admin/platform-advisor` pour enregistrer un instantané de métriques, générer des recommandations, les consulter et les approuver/refuser.
- Stockage PostgreSQL des instantanés et recommandations via `20261103_platform_advisor_v40.sql`.
- Journalisation des actions sensibles dans `audit_log`.
- Une recommandation approuvée est seulement marquée comme approuvée : **aucun prix, taux de commission, paiement, retrait ou solde n'est modifié automatiquement**.

## Limite importante
Jusqu'à ce que chaque module ait une agrégation de données vérifiée, les métriques du conseiller sont saisies par l'administrateur. L'API le signale avec `metricsMode: admin-entered-until-automated`. Ne présentez pas les soldes internes comme de l'argent bancaire détenu et ne saisissez pas de données estimées comme si elles étaient confirmées.

## Test sur ordinateur existant
1. Installer Node.js 20+ et Docker Desktop.
2. Extraire le ZIP et ouvrir un terminal dans le dossier `p`.
3. Copier `.env.example` vers `.env.local`, remplacer les secrets d'exemple et vérifier `DATABASE_URL`.
4. Démarrer PostgreSQL avec `docker compose up -d postgres` si le service `postgres` est défini dans `docker-compose.yml`.
5. Installer les dépendances : `npm install`.
6. Appliquer les migrations : `npm run db:migrate`.
7. Lancer les tests : `npm test`.
8. Vérifier la compilation : `npm run build`.
9. Lancer le site : `npm run dev`, puis ouvrir `http://localhost:3000`.

Si l'étape Docker ne correspond pas au service de votre compose, lisez `docker-compose.yml` avant de lancer la commande. Ne mettez pas le site en production avant d'avoir configuré les secrets, les sauvegardes, les e-mails, le stockage et les prestataires de paiement.

## Test de l'API conseiller
Avec une session administrateur authentifiée, `GET /api/admin/platform-advisor` renvoie l'instantané et les recommandations. `POST` accepte `action: "save_metrics"` avec un objet `metrics`, ou `action: "approve"` / `"dismiss"` avec un identifiant de recommandation. Les requêtes non administrateur sont refusées.

## Avant le lancement public
- Connecter le conseiller à des agrégations réelles et testées pour Shop, publicités, Studio, LIVE et trésorerie.
- Ajouter l'interface admin pour saisir/visualiser les métriques et gérer les recommandations.
- Intégrer puis tester les transporteurs, tarifs, étiquettes et webhooks de suivi.
- Finaliser le portail annonceur, les paiements réels, factures, remboursements et rapprochements.
- Configurer sécurité, politiques de confidentialité, conditions de vente, fiscalité, gestion des litiges, sauvegarde/restauration et surveillance.
- Tester les parcours avec des comptes de test et des paiements en mode sandbox avant toute transaction réelle.
