# Wesh Star — Consolidation fonctionnelle V38

Date : 29 octobre 2026
Base de travail : `wesh-star-ia-v3-notifications-couts(2).zip` (701 entrées).

## Objectif
Regrouper les règles convenues pour rendre le produit plus simple à utiliser, en donnant la priorité au Shop, à la trésorerie, au conseiller financier et à la publicité des marques. Ce document distingue les fonctions visibles dans le code de celles qui nécessitent encore une intégration ou un test réel.

## Navigation recommandée
- **Accueil** : contenu recommandé, raccourcis et notifications utiles.
- **Studio** : génération vidéo/image, modèles, voix, créations et crédits.
- **Social** : fil, profils, commentaires, abonnements, LIVE, cadeaux, messages et appels.
- **Shop** : produits, commandes, expédition, suivi, retours, litiges, portefeuille boutique.
- **Profil** : compte, abonnements, portefeuille, pièces/cadeaux, gains et retraits.
- **Administration uniquement** : trésorerie, modération, paramètres de commission, coûts, conseiller financier, publicités, campagnes et journaux.

Les fonctions avancées ne doivent pas encombrer les écrans des utilisateurs ordinaires. Les actions destructives ou financières demandent confirmation et sont consignées dans les journaux d'audit.

## Shop — flux cible
1. Le vendeur publie un produit avec prix, devise, stock, pays d'expédition et délai de préparation.
2. L'acheteur vérifie le prix total, la destination et les conditions de retour avant de payer.
3. La commande crée des écritures comptables idempotentes et équilibrées ; le stock est réservé dans la même transaction.
4. Le vendeur reçoit une notification de commande et expédie dans le délai configuré.
5. Le vendeur renseigne transporteur et numéro de suivi. Une intégration transporteur pourra ensuite proposer les tarifs, acheter l'étiquette et synchroniser les statuts.
6. L'acheteur suit les statuts, confirme la réception ou ouvre un litige. Le versement au vendeur reste soumis aux règles de blocage et aux litiges.
7. Un parcours de retour doit recueillir le motif, les preuves, la réponse du vendeur, le suivi retour et la décision de remboursement. Le remboursement doit respecter le solde encore bloqué ou utiliser un mécanisme de reversement autorisé ; ne jamais créer de solde artificiel.
8. Notifications prévues : commande payée, commande à expédier, suivi ajouté, colis livré, délai dépassé, demande de retour, nouveau message de litige, remboursement décidé et retrait traité.

### État constaté dans la base fournie
Le code comporte déjà une place de marché, une commande payée via solde boutique, un grand livre interne, des règles de commission configurables, un blocage des fonds, un champ transporteur/suivi, la confirmation de réception, les litiges et les avis. Le formulaire de commande ne doit pas être considéré comme un paiement par carte universel : les paiements réels dépendent des recharges et du fournisseur configuré. L'intégration transporteur automatique et l'achat d'étiquettes ne sont pas activés par le code vérifié.

## Conseiller financier
Le conseiller doit afficher :
- revenus par source et par devise ;
- frais de paiement, énergie, amortissement du matériel et charges fixes ;
- marge estimée, coût par minute vidéo/image et seuil de rentabilité ;
- commissions Shop brutes, frais fixes, promotions, remboursements, montants bloqués et nets vendeurs ;
- alertes en cas de marge faible, commandes en retard, litiges, frais inhabituels ou trésorerie insuffisante ;
- recommandations datées, justification, impact estimé et boutons **Valider** / **Ignorer**.

Le code V38 envoie maintenant une notification aux administrateurs lorsqu'une nouvelle recommandation de coûts est créée. Aucune recommandation de prix, de commission ou de dépense ne doit être appliquée sans validation explicite de l'administrateur. Les estimations doivent distinguer la commission brute, le revenu net estimé et le bénéfice réellement confirmé.

### Politique de commission suggérée pour le lancement
- **8 %** : point de départ raisonnable pour tester l'adoption et la compétitivité.
- **10 %** : à tester lorsque les données montrent que le support, les paiements et la protection acheteur justifient le niveau.
- **12 %** : uniquement si des services réels supplémentaires sont fournis et si les conversions vendeurs/acheteurs restent bonnes.

Ces taux sont des hypothèses de gestion, pas des tarifs universels ni une promesse de rentabilité. L'administrateur peut définir des taux par catégorie ou pays. Les frais fixes, les promotions et le coût de paiement doivent être visibles séparément. Les taxes, les remboursements, les impayés et les coûts de support sont nécessaires pour calculer un vrai bénéfice net.

## Publicité des marques — flux cible
1. Un annonceur crée un compte professionnel et soumet les coordonnées de l'entreprise.
2. Il crée une campagne : format (bannière, vidéo sponsorisée, produit sponsorisé), contenu, URL, audience, dates, budget et mode de facturation (forfait, CPM ou CPC).
3. La campagne reste **en attente** tant que la marque, le contenu et le paiement ne sont pas validés.
4. L'administration approuve/refuse, choisit les emplacements et peut suspendre la campagne.
5. Le système enregistre les impressions et clics avec protections anti-fraude ; le rapport annonceur montre budget dépensé et résultats.
6. La facture, le paiement réel, les remboursements et les revenus comptables doivent être rapprochés. Une campagne enregistrée dans les paramètres n'est pas, à elle seule, une preuve d'argent reçu.
7. Les revenus d'une régie comme AdSense restent distincts des contrats directs avec les marques. Le partage créateur/plateforme ne s'applique qu'aux revenus admissibles et effectivement encaissés selon une règle explicite.

### État constaté dans la base fournie
Le panneau admin permet de configurer des annonces et des campagnes internes, et la base contient les événements d'impression/clic. Un portail annonceur autonome avec facturation, paiement, factures et rapprochement comptable doit encore être implémenté et testé avant d'être présenté comme opérationnel.

## Paramètres opérationnels et sécurité
- Environnement local/self-hosted : PostgreSQL, sauvegarde/restauration, secrets dans `.env`, workers séparés et journaux.
- Utiliser des transactions SQL et des clés d'idempotence pour les mouvements financiers.
- Les soldes internes sont un registre comptable, pas un compte bancaire ni un service d'entiercement réglementé.
- Les paiements, remboursements et retraits réels exigent des comptes marchands approuvés, des webhooks signés, des tests d'échec et une réconciliation.
- Les livraisons exigent un transporteur réellement connecté pour les prix, étiquettes et événements automatiques.
- Avant ouverture publique : tests d'intégration multi-comptes, sécurité RBAC, test de paiement, test de remboursement, test de litige, restauration de sauvegarde et revue juridique adaptée aux pays ciblés.

## État des tests et limites de cette livraison
Cette archive est un complément de consolidation documentaire et d'interface admin du conseiller Shop. Elle n'active pas de transporteur, ne crée pas de compte marchand, ne facture pas de marque et ne prouve pas que les paiements réels fonctionnent. Le rapport d'audit V11 présent dans la bibliothèque signale déjà que les webhooks et certains flux de bout en bout nécessitent des essais avec des secrets et comptes marchands réels.
