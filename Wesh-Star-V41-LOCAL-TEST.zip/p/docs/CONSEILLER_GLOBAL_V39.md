# Wesh Star — Conseiller global V39

## Mission
Le conseiller analyse les indicateurs disponibles du site et prépare des recommandations à l’administrateur. Il couvre Shop, publicité des marques, Studio IA, LIVE/cadeaux et trésorerie. Il ne doit jamais modifier seul un prix, un taux, un budget, une campagne, un retrait ou un solde.

## Règle de fonctionnement
1. Collecter des agrégats vérifiés depuis PostgreSQL et les prestataires connectés.
2. Distinguer données confirmées, estimations et données manquantes.
3. Créer une recommandation avec priorité, motif, action proposée et impact attendu.
4. Notifier l’administrateur, avec lien vers le tableau de bord.
5. L’administrateur valide, ignore ou demande une analyse complémentaire.
6. Journaliser la décision, l’auteur, la date et les valeurs avant/après.

Le moteur `src/lib/platform-advisor.ts` fournit les règles pures de recommandation V39. Il n’est pas encore relié à une collecte globale de toutes les tables, ni à un worker de notifications pour chaque type : ne pas le présenter comme un conseiller entièrement autonome tant que cette intégration n’est pas faite.

## Shop — parcours à finaliser
- Fiche produit : prix, stock, poids/dimensions, pays d’expédition, délai de préparation, politique de retour.
- Panier et paiement : total détaillé avant confirmation, devise, frais, taxes éventuelles et prestataire réellement configuré.
- Commande : réservation atomique du stock, référence unique et journal comptable idempotent.
- Expédition : choix du transporteur, estimation tarifaire, génération d’étiquette, saisie/import du suivi et notifications.
- Livraison : synchronisation transporteur, preuve de livraison et procédure « colis non reçu ».
- Retours : demande avec motif/preuves, approbation, étiquette retour, suivi retour, inspection et remboursement via prestataire.
- Litiges : fonds concernés maintenus en attente, preuves des deux parties, décision auditée.
- Vendeur : solde brut, commission, frais, remboursements, solde bloqué et montant réellement disponible, séparés.

Les intégrations transporteur doivent être réalisées avec des API réelles (tarifs, étiquettes, tracking/webhooks). Le numéro saisi manuellement ne constitue pas une confirmation de livraison.

## Commission Shop — proposition de départ
- 8 % du prix du produit hors frais de livraison : hypothèse de départ à tester.
- 10 % : essai ultérieur si les coûts de support, paiements, acquisition et protection le justifient.
- 12 % : uniquement si la plateforme fournit une valeur supplémentaire mesurable et reste compétitive.
- Frais de paiement, livraison, taxes, remboursements et frais fixes doivent apparaître séparément.
- Ne pas appliquer automatiquement les recommandations. Mesurer conversion, marge contributive, rétention vendeurs et coût des litiges par catégorie/pays.

Exemple indicatif : produit 100 €, commission 8 % = 8 € brut avant frais de paiement, taxes, remboursements, support et autres charges. Ce n’est pas 8 € de bénéfice net.

## Publicité des marques
Portail annonceur à terminer : inscription professionnelle et vérification, dépôt de campagne, formats bannière/vidéo/produit sponsorisé, audience, dates, budget, CPM/CPC/forfait, paiement, validation humaine, diffusion, statistiques anti-fraude, facture et rapprochement. Une campagne en base ou une impression comptée ne prouve pas que l’argent a été encaissé.

## Conseiller par domaine
- Shop : retards, litiges, retours, stock, taux de commission, marge nette et conversion.
- Publicité : campagnes en attente, budget dépensé, paiements rapprochés, impressions/clics valides, CTR et revenu net.
- Studio IA : coût GPU/électricité/amortissement par image et seconde vidéo, échecs, files d’attente, quotas et marge.
- LIVE : cadeaux encaissés, part créateur/plateforme, retraits en attente, remboursements et fraude.
- Trésorerie : liquidités réellement disponibles chez le prestataire, obligations de remboursement, rétrofacturations, charges fixes et réserve.

## Notifications
Créer des alertes pour : nouvelle recommandation, commande à expédier, retard, suivi ajouté, colis livré/non reçu, retour demandé, litige, remboursement, campagne annonceur à valider, budget épuisé, paiement refusé, coût GPU anormal, marge négative, retrait à vérifier et réserve insuffisante. Déduplication, préférences, historique et lien vers l’écran concerné obligatoires.

## Navigation simplifiée
Accueil · Studio · Social · Shop · Profil. Administration séparée : tableau de bord, conseiller global, Shop, trésorerie, publicités, modération, Autopilot, paramètres et journaux.

## Critères avant production
- Tests PostgreSQL d’intégration et migrations propres.
- Paiements, remboursements et webhooks signés/idempotents testés en sandbox.
- Transporteur réel testé sur création d’étiquette, suivi et retour.
- Vérification RBAC et journal d’audit.
- Tests multi-comptes, mobile, sauvegarde/restauration et charge.
- Vérification juridique/comptable pour les pays et devises activés. Les soldes internes ne sont pas un compte bancaire ni un service d’entiercement réglementé.

## Limites V39
V39 ajoute le moteur de règles global et ses tests unitaires, ainsi que ce plan de mise en œuvre. La collecte réelle de toutes les métriques, le stockage des recommandations globales, leur notification persistante et l’interface de validation globale restent à intégrer. Les transporteurs et le portail annonceur restent des intégrations à réaliser. Cette archive ne certifie pas les paiements réels ni une mise en production.
