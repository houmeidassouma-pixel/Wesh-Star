// Génère une paire de clés VAPID pour les notifications Push : node scripts/generate-vapid.mjs
import { createECDH } from "node:crypto";
const e = createECDH("prime256v1"); e.generateKeys();
const pad = (b) => (b.length >= 32 ? b : Buffer.concat([Buffer.alloc(32 - b.length), b]));
console.log("VAPID_PUBLIC_KEY=" + e.getPublicKey().toString("base64url"));
console.log("VAPID_PRIVATE_KEY=" + pad(e.getPrivateKey()).toString("base64url"));
console.log("VAPID_SUBJECT=mailto:contact@ton-domaine.com");
